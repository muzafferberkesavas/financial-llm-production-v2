import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'ui/providers/app_state.dart';
import 'ui/screens/home_screen.dart';
import 'ui/screens/analyses_screen.dart';
import 'ui/screens/portfolio_screen.dart';
import 'ui/screens/settings_screen.dart';
import 'services/background_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeBackgroundService();
  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState()..init(),
      child: const BorsaAnalizApp(),
    ),
  );
}

class BorsaAnalizApp extends StatelessWidget {
  const BorsaAnalizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Borsa Analiz',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.indigo,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const MainNavigation(),
    );
  }
}

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 0;

  final _screens = const [
    HomeScreen(),
    AnalysesScreen(),
    PortfolioScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Borsa Analiz'),
        actions: [
          if (state.isLoading && state.progressMessage != null)
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 180),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Text(
                  state.progressMessage!,
                  style: const TextStyle(fontSize: 11, color: Colors.grey),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          if (state.isLoading)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: SizedBox(
                width: 20,
                height: 20,
                child: state.progressTotal > 0
                    ? CircularProgressIndicator(
                        strokeWidth: 2,
                        value: state.progressCurrent / state.progressTotal,
                      )
                    : const CircularProgressIndicator(strokeWidth: 2),
              ),
            ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: state.isLoading ? null : () => state.fetchAllData(),
            tooltip: 'Verileri Guncelle',
          ),
        ],
      ),
      body: _screens[_currentIndex.clamp(0, _screens.length - 1)],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex.clamp(0, _screens.length - 1),
        onDestinationSelected: (index) =>
            setState(() => _currentIndex = index),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.trending_up), label: 'Takip'),
          NavigationDestination(
              icon: Icon(Icons.auto_awesome), label: 'Analizler'),
          NavigationDestination(
              icon: Icon(Icons.account_balance_wallet), label: 'Portfoy'),
          NavigationDestination(
              icon: Icon(Icons.settings), label: 'Ayarlar'),
        ],
      ),
    );
  }
}
