import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'package:intl/intl.dart';

import '../config/app_config.dart';
import '../data/models/stock.dart';
import '../data/models/daily_price.dart';
import '../data/models/indicator.dart';
import '../data/models/ai_analysis.dart';
import '../data/models/analysis_session.dart';
import '../data/repositories/stock_repository.dart';
import '../data/repositories/price_repository.dart';
import '../data/repositories/analysis_repository.dart';
import '../domain/analysis/indicator_calculator.dart';
import '../ai/gemini_client.dart';
import '../ai/prompt_builder.dart';
import '../ai/response_parser.dart';
import '../ai/news_translation_service.dart';
import '../data/remote/yahoo_finance_api.dart';
import '../data/remote/rss_news_service.dart';
import '../data/remote/kap_service.dart';
import '../data/models/market_agenda.dart';
import '../services/connectivity_service.dart';
import '../services/notification_service.dart';

const String backgroundAnalysisTask = 'com.borsa.backgroundAnalysis';
const String _apiKeyPref = 'gemini_api_key';
const String _lastFilterDatePref = 'last_filter_date';
const String _lastUpdatedTimePref = 'last_updated_time';

/// WorkManager top-level callback - uygulama kapali olsa da calisir
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((taskName, inputData) async {
    debugPrint('[BACKGROUND] Gorev basladi: $taskName');

    try {
      // 1. Piyasa acik mi kontrol et
      if (!_isMarketOpen()) {
        debugPrint('[BACKGROUND] Piyasa kapali, gorev atlandi');
        return true;
      }

      // 2. Internet kontrol
      final isOnline = await ConnectivityService.checkConnectivity();
      if (!isOnline) {
        debugPrint('[BACKGROUND] Internet yok, gorev atlandi');
        return true;
      }

      // 3. API key kontrol
      final prefs = await SharedPreferences.getInstance();
      final apiKey = prefs.getString(_apiKeyPref);
      if (apiKey == null || apiKey.isEmpty) {
        debugPrint('[BACKGROUND] API key yok, gorev atlandi');
        return true;
      }

      // 4. Aktif + portfoy hisselerini al
      final stockRepo = StockRepository();
      final priceRepo = PriceRepository();
      final analysisRepo = AnalysisRepository();

      final activeStocks = await stockRepo.getActiveStocks();
      final portfolioStocks = await stockRepo.getPortfolioStocks();
      final commodityStocks = await stockRepo.getCommodityStocks();
      final stocksToAnalyze = <Stock>{...activeStocks, ...portfolioStocks};
      // Emtialari ayri tut — analiz icin eklenecek ama filtre/portfoy disinda
      final commoditySet = <Stock>{};
      for (final c in commodityStocks) {
        if (!stocksToAnalyze.any((s) => s.ticker == c.ticker)) {
          commoditySet.add(c);
        }
      }

      if (stocksToAnalyze.isEmpty && commoditySet.isEmpty) {
        debugPrint('[BACKGROUND] Analiz edilecek hisse yok');
        return true;
      }

      debugPrint('[BACKGROUND] ${stocksToAnalyze.length} hisse + ${commoditySet.length} emtia guncellenecek');

      // 5. Fiyatlari guncelle (hisseler + emtialar)
      for (final stock in {...stocksToAnalyze, ...commoditySet}) {
        try {
          if (AppConfig.isCommodityTicker(stock.ticker)) {
            await priceRepo.fetchAndSaveCommodityPrices(stock.ticker, stock.id!);
          } else {
            await priceRepo.fetchAndSaveDailyPrices(stock.ticker, stock.id!);
          }
        } catch (e) {
          debugPrint('[BACKGROUND] ${stock.ticker} fiyat hatasi: $e');
        }
      }

      // 6. AI analizi yap
      final indicatorCalc = IndicatorCalculator();
      final promptBuilder = PromptBuilder();
      final responseParser = ResponseParser();
      final client = GeminiClient(apiKey);

      final analysisDataList = <StockAnalysisData>[];
      final portfolioIds = portfolioStocks.map((s) => s.id).toSet();

      // Bugun gunluk filtre yapilmis mi kontrol et
      final lastFilterMs = prefs.getInt(_lastFilterDatePref);
      final now = DateTime.now();
      bool isFilterDoneToday = false;
      if (lastFilterMs != null) {
        final lastFilter = DateTime.fromMillisecondsSinceEpoch(lastFilterMs);
        isFilterDoneToday = lastFilter.year == now.year &&
            lastFilter.month == now.month &&
            lastFilter.day == now.day;
      }
      final analysisType = isFilterDoneToday ? 'SAATLIK' : 'GUNLUK';

      // BIST-100 endeks degisimi
      double? bist100Change;
      try {
        final yahooApi = YahooFinanceApi();
        final bist100Prices = await yahooApi.fetchPrices(
            AppConfig.bist100Ticker, 0, range: '5d');
        if (bist100Prices.length >= 2) {
          final last = bist100Prices.last;
          final prev = bist100Prices[bist100Prices.length - 2];
          bist100Change = ((last.close - prev.close) / prev.close) * 100;
          debugPrint('[BACKGROUND] BIST-100 degisim: ${bist100Change.toStringAsFixed(2)}%');
        }
      } catch (e) {
        debugPrint('[BACKGROUND] BIST-100 endeks verisi alinamadi: $e');
      }

      // Sektor ortalama degisimleri hesapla
      final sectorChanges = <String, List<double>>{};
      for (final stock in stocksToAnalyze) {
        final sector = stock.sector;
        if (sector == null) continue;
        final recentPrices = await priceRepo.getDailyPrices(stock.id!, limit: 2);
        if (recentPrices.length >= 2) {
          final change = ((recentPrices[0].close - recentPrices[1].close) / recentPrices[1].close) * 100;
          sectorChanges.putIfAbsent(sector, () => []).add(change);
        }
      }
      final sectorAvgChange = <String, double>{};
      for (final entry in sectorChanges.entries) {
        sectorAvgChange[entry.key] = entry.value.reduce((a, b) => a + b) / entry.value.length;
      }

      for (final stock in stocksToAnalyze) {
        try {
          final prices = await priceRepo.getDailyPrices(stock.id!);
          if (prices.length < AppConfig.minPricesForIndicator) continue;

          // Indikatorleri hesapla ve kaydet
          final indicators = indicatorCalc.calculate(prices, stock.id!);
          if (indicators.isNotEmpty) {
            await analysisRepo.saveIndicators(indicators);
          }

          final latestIndicator = await analysisRepo.getLatestIndicator(stock.id!);
          final latestPrice = prices.isNotEmpty ? prices.first : null;
          if (latestIndicator == null || latestPrice == null) continue;

          // Onceki analiz
          final AiAnalysis? prevAnalysis;
          if (analysisType == 'SAATLIK') {
            prevAnalysis = await analysisRepo.getTodayDailyAnalysis(stock.id!);
          } else {
            prevAnalysis = await analysisRepo.getLatestAiAnalysis(stock.id!);
          }
          final fib = await analysisRepo.getFibonacci(stock.id!);

          // Son 10 gunluk veriler
          final recentIndicators = await analysisRepo.getIndicatorsForStock(stock.id!);
          final recent10Ind = recentIndicators.take(10).toList();
          final recent10Prices = prices.take(10).toList();

          final isInPortfolio = portfolioIds.contains(stock.id);

          // Saatlik mumlar (gun ici analiz icin)
          List<HourlyCandle>? hourlyCandles;
          if (analysisType == 'SAATLIK') {
            try {
              final yahooApi = YahooFinanceApi();
              final hourlyPrices = await yahooApi.fetchPrices(
                  stock.ticker, stock.id!, interval: '60m', range: '1d');
              if (hourlyPrices.isNotEmpty) {
                hourlyCandles = hourlyPrices.map((p) => HourlyCandle(
                  timestamp: p.date,
                  open: p.open,
                  high: p.high,
                  low: p.low,
                  close: p.close,
                  volume: p.volume,
                )).toList();
              }
            } catch (e) {
              debugPrint('[BACKGROUND] ${stock.ticker} saatlik mum hatasi: $e');
            }
          }

          // Sabah notlari (gun ici analizde AI'in kendi notlari)
          String? morningPlan;
          if (analysisType == 'SAATLIK') {
            morningPlan = await analysisRepo.getMorningNotes(stock.id!);
          }

          // v3: Previous day ADX
          final adxPrev = recent10Ind.length > 1 ? recent10Ind[1].adx : null;

          // v3: Weekly indicators
          final weeklyData = _computeWeeklyIndicators(prices);

          // v3: Derived fields
          final derived = _computeDerivedFields(recentIndicators, prices);

          analysisDataList.add(StockAnalysisData(
            ticker: stock.ticker,
            name: stock.name,
            sector: stock.sector,
            close: latestPrice.close,
            changePercent: prices.length > 1
                ? ((prices[0].close - prices[1].close) / prices[1].close) * 100
                : 0,
            volume: latestPrice.volume,
            avgVolume20: prices.take(AppConfig.avgVolumePeriod).isEmpty
                ? 0
                : (prices
                        .take(AppConfig.avgVolumePeriod)
                        .map((p) => p.volume)
                        .reduce((a, b) => a + b) ~/
                    prices.take(AppConfig.avgVolumePeriod).length),
            rsi: latestIndicator.rsi,
            macd: latestIndicator.macd,
            macdSignal: latestIndicator.macdSignal,
            macdHistogram: latestIndicator.macdHistogram,
            bbUpper: latestIndicator.bbUpper,
            bbMiddle: latestIndicator.bbMiddle,
            bbLower: latestIndicator.bbLower,
            bbPercentB: latestIndicator.bbPercentB,
            obv: latestIndicator.obv,
            sma20: latestIndicator.sma20,
            sma50: latestIndicator.sma50,
            sma200: latestIndicator.sma200,
            atr: latestIndicator.atr,
            technicalScore: latestIndicator.technicalScore,
            fibHigh: fib?.swingHighPrice,
            fibLow: fib?.swingLowPrice,
            fib236: fib?.level236,
            fib382: fib?.level382,
            fib500: fib?.level500,
            fib618: fib?.level618,
            previousSummary: prevAnalysis?.summary,
            previousSignal: prevAnalysis?.signal,
            isInPortfolio: isInPortfolio,
            passedFilter: true,
            recentCloses: recent10Prices.map((p) => p.close).toList(),
            recentRsi: recent10Ind.map((i) => i.rsi).toList(),
            recentMacdHist: recent10Ind.map((i) => i.macdHistogram).toList(),
            recentVolumes: recent10Prices.map((p) => p.volume).toList(),
            // v3: ADX
            adx: latestIndicator.adx,
            adxPrev: adxPrev,
            plusDi: latestIndicator.plusDi,
            minusDi: latestIndicator.minusDi,
            // v3: Weekly
            weeklySma20: weeklyData['sma20'] as double?,
            weeklySma50: weeklyData['sma50'] as double?,
            weeklyRsi: weeklyData['rsi'] as double?,
            weeklyTrend: weeklyData['trend'] as String?,
            // v3: Derived
            obvMa20: derived['obvMa20'] as double?,
            obvTrend: derived['obvTrend'] as String?,
            obvDivergence: derived['obvDivergence'] as bool?,
            obvDivergenceType: derived['obvDivergenceType'] as String?,
            bbWidth: derived['bbWidth'] as double?,
            bbWidthTrend: derived['bbWidthTrend'] as String?,
            bbSqueeze: derived['bbSqueeze'] as bool?,
            ema9: derived['ema9'] as double?,
            ema21: derived['ema21'] as double?,
            swingHigh20: derived['swingHigh20'] as double?,
            swingLow20: derived['swingLow20'] as double?,
            bist100Change: bist100Change,
            sectorChange: stock.sector != null ? sectorAvgChange[stock.sector!] : null,
            hourlyCandles: hourlyCandles,
            morningPlan: morningPlan,
          ));
        } catch (e) {
          debugPrint('[BACKGROUND] ${stock.ticker} veri hazirlama hatasi: $e');
        }
      }

      // v4: Emtialari (altin, gumus) her zaman ekle
      for (final cStock in commoditySet) {
        try {
          final prices = await priceRepo.getDailyPrices(cStock.id!);
          if (prices.length < 10) continue;

          final indicators = indicatorCalc.calculate(prices, cStock.id!);
          if (indicators.isNotEmpty) {
            await analysisRepo.saveIndicators(indicators);
          }
          final latestIndicator = await analysisRepo.getLatestIndicator(cStock.id!);
          final latestPrice = prices.isNotEmpty ? prices.first : null;
          if (latestIndicator == null || latestPrice == null) {
            // Indikator yoksa temel veriyle ekle
            if (prices.isNotEmpty) {
              stocksToAnalyze.add(cStock);
              analysisDataList.add(StockAnalysisData(
                ticker: cStock.ticker,
                name: cStock.name,
                sector: cStock.sector,
                close: prices.first.close,
                changePercent: prices.length > 1
                    ? ((prices[0].close - prices[1].close) / prices[1].close) * 100
                    : 0,
                volume: prices.first.volume,
                avgVolume20: 0,
                isInPortfolio: false,
                passedFilter: false,
                isCommodity: true,
                recentCloses: prices.take(10).map((p) => p.close).toList(),
                recentVolumes: prices.take(10).map((p) => p.volume).toList(),
              ));
              debugPrint('[BACKGROUND] Emtia eklendi (temel): ${cStock.ticker}');
            }
            continue;
          }

          final recentIndicators = await analysisRepo.getIndicatorsForStock(cStock.id!);
          final recent10Ind = recentIndicators.take(10).toList();
          final recent10Prices = prices.take(10).toList();
          final adxPrevC = recent10Ind.length > 1 ? recent10Ind[1].adx : null;
          final weeklyDataC = _computeWeeklyIndicators(prices);
          final derivedC = _computeDerivedFields(recentIndicators, prices);
          final fibC = await analysisRepo.getFibonacci(cStock.id!);

          final AiAnalysis? prevAnalysisC;
          if (analysisType == 'SAATLIK') {
            prevAnalysisC = await analysisRepo.getTodayDailyAnalysis(cStock.id!);
          } else {
            prevAnalysisC = await analysisRepo.getLatestAiAnalysis(cStock.id!);
          }

          List<HourlyCandle>? hourlyCandlesC;
          if (analysisType == 'SAATLIK') {
            try {
              final yahooApi = YahooFinanceApi();
              final hourlyPrices = await yahooApi.fetchPrices(
                  cStock.ticker, cStock.id!, interval: '60m', range: '1d');
              if (hourlyPrices.isNotEmpty) {
                hourlyCandlesC = hourlyPrices.map((p) => HourlyCandle(
                  timestamp: p.date, open: p.open, high: p.high,
                  low: p.low, close: p.close, volume: p.volume,
                )).toList();
              }
            } catch (_) {}
          }

          // Emtia olarak isaretle
          stocksToAnalyze.add(cStock); // result parsing icin
          analysisDataList.add(StockAnalysisData(
            ticker: cStock.ticker,
            name: cStock.name,
            sector: cStock.sector,
            close: latestPrice.close,
            changePercent: prices.length > 1
                ? ((prices[0].close - prices[1].close) / prices[1].close) * 100
                : 0,
            volume: latestPrice.volume,
            avgVolume20: prices.take(AppConfig.avgVolumePeriod).isEmpty ? 0
                : (prices.take(AppConfig.avgVolumePeriod).map((p) => p.volume).reduce((a, b) => a + b) ~/
                    prices.take(AppConfig.avgVolumePeriod).length),
            rsi: latestIndicator.rsi,
            macd: latestIndicator.macd,
            macdSignal: latestIndicator.macdSignal,
            macdHistogram: latestIndicator.macdHistogram,
            bbUpper: latestIndicator.bbUpper,
            bbMiddle: latestIndicator.bbMiddle,
            bbLower: latestIndicator.bbLower,
            bbPercentB: latestIndicator.bbPercentB,
            obv: latestIndicator.obv,
            sma20: latestIndicator.sma20,
            sma50: latestIndicator.sma50,
            sma200: latestIndicator.sma200,
            atr: latestIndicator.atr,
            technicalScore: latestIndicator.technicalScore,
            fibHigh: fibC?.swingHighPrice,
            fibLow: fibC?.swingLowPrice,
            fib236: fibC?.level236,
            fib382: fibC?.level382,
            fib500: fibC?.level500,
            fib618: fibC?.level618,
            previousSummary: prevAnalysisC?.summary,
            previousSignal: prevAnalysisC?.signal,
            isInPortfolio: false,
            passedFilter: false,
            isCommodity: true,
            recentCloses: recent10Prices.map((p) => p.close).toList(),
            recentRsi: recent10Ind.map((i) => i.rsi).toList(),
            recentMacdHist: recent10Ind.map((i) => i.macdHistogram).toList(),
            recentVolumes: recent10Prices.map((p) => p.volume).toList(),
            adx: latestIndicator.adx,
            adxPrev: adxPrevC,
            plusDi: latestIndicator.plusDi,
            minusDi: latestIndicator.minusDi,
            weeklySma20: weeklyDataC['sma20'] as double?,
            weeklySma50: weeklyDataC['sma50'] as double?,
            weeklyRsi: weeklyDataC['rsi'] as double?,
            weeklyTrend: weeklyDataC['trend'] as String?,
            obvMa20: derivedC['obvMa20'] as double?,
            obvTrend: derivedC['obvTrend'] as String?,
            obvDivergence: derivedC['obvDivergence'] as bool?,
            obvDivergenceType: derivedC['obvDivergenceType'] as String?,
            bbWidth: derivedC['bbWidth'] as double?,
            bbWidthTrend: derivedC['bbWidthTrend'] as String?,
            bbSqueeze: derivedC['bbSqueeze'] as bool?,
            ema9: derivedC['ema9'] as double?,
            ema21: derivedC['ema21'] as double?,
            swingHigh20: derivedC['swingHigh20'] as double?,
            swingLow20: derivedC['swingLow20'] as double?,
            bist100Change: bist100Change,
            hourlyCandles: hourlyCandlesC,
          ));
          debugPrint('[BACKGROUND] Emtia eklendi: ${cStock.ticker}');
        } catch (e) {
          debugPrint('[BACKGROUND] Emtia veri hatasi (${cStock.ticker}): $e');
        }
      }

      if (analysisDataList.isEmpty) {
        debugPrint('[BACKGROUND] Analiz verisi hazirlanamadi');
        return true;
      }

      // 6.5 v4: Haber/gundem cek ve ozetle
      MarketAgenda? agenda;
      try {
        final watchlistTickers = analysisDataList.map((d) => d.ticker).toList();
        final newsItems = await fetchAllRssNews();
        final kapDisclosures = await fetchKapDisclosures(tickers: watchlistTickers);
        if (newsItems.isNotEmpty || kapDisclosures.isNotEmpty) {
          agenda = await fetchMarketAgenda(
            apiKey: apiKey,
            newsItems: newsItems,
            kapDisclosures: kapDisclosures,
            watchlistTickers: watchlistTickers,
          );
          debugPrint('[BACKGROUND] Gundem hazir: ${agenda?.formattedAgenda.length ?? 0} karakter');
        }
      } catch (e) {
        debugPrint('[BACKGROUND] Haber hatasi: $e');
      }

      // 7. Session olustur + Gemini'ye gonder (batch halinde)
      final sessionId = await analysisRepo.createSession(AnalysisSession(
        datetime: DateTime.now().millisecondsSinceEpoch,
        analysisType: analysisType,
        stockCount: analysisDataList.length,
      ));
      final allPrompts = StringBuffer();
      final allResponses = StringBuffer();
      final allSignals = <AnalysisSignalInfo>[];
      const batchSize = AppConfig.geminiBatchSize;
      int savedCount = 0;

      for (int batchStart = 0;
          batchStart < analysisDataList.length;
          batchStart += batchSize) {
        if (batchStart > 0) {
          debugPrint('[BACKGROUND] Rate limit bekleniyor: 12s');
          await Future.delayed(const Duration(seconds: 15));
        }

        final batchEnd = min(batchStart + batchSize, analysisDataList.length);
        final batch = analysisDataList.sublist(batchStart, batchEnd);

        final userPrompt = analysisType == 'GUNLUK'
            ? promptBuilder.buildMorningPrompt(batch, agenda: agenda)
            : promptBuilder.buildIntradayPrompt(batch, agenda: agenda);
        debugPrint('[BACKGROUND] Batch ${batchStart ~/ batchSize + 1}: '
            '${batch.length} hisse gonderiliyor');

        if (allPrompts.isNotEmpty) allPrompts.write('\n\n--- BATCH ${batchStart ~/ batchSize + 1} ---\n\n');
        allPrompts.write(userPrompt);

        final responseText =
            await client.generate(PromptBuilder.systemPrompt, userPrompt);

        if (responseText == null || responseText.isEmpty) {
          debugPrint('[BACKGROUND] Gemini bos yanit');
          if (allResponses.isNotEmpty) allResponses.write('\n\n');
          allResponses.write('[BATCH ${batchStart ~/ batchSize + 1}: BOS YANIT]');
          continue;
        }

        if (allResponses.isNotEmpty) allResponses.write('\n\n--- BATCH ${batchStart ~/ batchSize + 1} ---\n\n');
        allResponses.write(responseText);

        final results = responseParser.parse(responseText);
        debugPrint('[BACKGROUND] Parse: ${results.length} hisse');

        for (final result in results) {
          final stock = stocksToAnalyze
              .where((s) => s.ticker == result.ticker)
              .firstOrNull;
          if (stock == null) continue;

          await analysisRepo.saveAiAnalysis(AiAnalysis(
            stockId: stock.id!,
            datetime: DateTime.now().millisecondsSinceEpoch,
            analysisType: analysisType,
            summary: result.summary,
            signal: result.signal,
            confidence: result.confidence,
            riskReward: result.riskReward,
            scenarioStatus: result.scenarioStatus,
            sessionId: sessionId,
            intradayNotes: result.intradayPlan,
          ));
          savedCount++;
          allSignals.add(AnalysisSignalInfo(
            ticker: result.ticker,
            signal: result.signal,
            confidence: result.confidence,
          ));
        }
      }

      // Session guncelle
      await analysisRepo.updateSessionTexts(
          sessionId, allPrompts.toString(), allResponses.toString());
      await analysisRepo.updateSessionStockCount(sessionId, savedCount);
      debugPrint('[BACKGROUND] Toplam $savedCount analiz kaydedildi');

      // 8. Bildirim gonder
      if (allSignals.isNotEmpty) {
        await NotificationService.instance.init();
        if (analysisType == 'GUNLUK') {
          await NotificationService.instance.showDailyAnalysisNotification(
            signals: allSignals,
          );
        } else {
          await NotificationService.instance.showHourlyAnalysisNotification(
            signals: allSignals,
          );
        }
      }

      // 9. Son guncelleme zamanini kaydet
      await prefs.setString(
          _lastUpdatedTimePref, DateFormat('HH:mm').format(DateTime.now()));

      debugPrint('[BACKGROUND] Gorev basariyla tamamlandi');
      return true;
    } catch (e) {
      debugPrint('[BACKGROUND] HATA: $e');
      return false; // WorkManager yeniden deneyecek
    }
  });
}

Map<String, dynamic> _computeWeeklyIndicators(List<DailyPrice> dailyPrices) {
  if (dailyPrices.length < 60) {
    return {'sma20': null, 'sma50': null, 'rsi': null, 'trend': null};
  }
  final reversed = dailyPrices.reversed.toList();
  final weeklyCloses = <double>[];
  int? currentWeek;
  int? currentYear;
  double? lastClose;
  for (final p in reversed) {
    final date = DateTime.fromMillisecondsSinceEpoch(p.date);
    final dayOfYear = date.difference(DateTime(date.year, 1, 1)).inDays;
    final week = ((dayOfYear - date.weekday + 10) / 7).floor();
    final year = date.year;
    if (currentWeek != week || currentYear != year) {
      if (lastClose != null) weeklyCloses.add(lastClose);
      currentWeek = week;
      currentYear = year;
    }
    lastClose = p.close;
  }
  if (lastClose != null) weeklyCloses.add(lastClose);
  if (weeklyCloses.length < 50) {
    return {'sma20': null, 'sma50': null, 'rsi': null, 'trend': null};
  }
  double smaCalc(List<double> vals, int period) {
    double sum = 0;
    for (int i = vals.length - period; i < vals.length; i++) sum += vals[i];
    return sum / period;
  }
  final sma20 = smaCalc(weeklyCloses, 20);
  final sma50 = smaCalc(weeklyCloses, 50);
  double? rsi;
  if (weeklyCloses.length > 14) {
    double gainSum = 0, lossSum = 0;
    for (int i = weeklyCloses.length - 14; i < weeklyCloses.length; i++) {
      final change = weeklyCloses[i] - weeklyCloses[i - 1];
      if (change > 0) gainSum += change; else lossSum += change.abs();
    }
    final avgGain = gainSum / 14;
    final avgLoss = lossSum / 14;
    rsi = avgLoss == 0 ? 100.0 : 100.0 - (100.0 / (1.0 + avgGain / avgLoss));
  }
  String? trend;
  final price = weeklyCloses.last;
  if (price > sma20 && sma20 > sma50) trend = 'UPTREND';
  else if (price < sma20 && sma20 < sma50) trend = 'DOWNTREND';
  else if (price > sma20 && sma20 < sma50) trend = 'EARLY_RECOVERY';
  else if (price < sma20 && sma20 > sma50) trend = 'EARLY_WEAKNESS';
  else trend = 'SIDEWAYS';
  return {'sma20': sma20, 'sma50': sma50, 'rsi': rsi, 'trend': trend};
}

Map<String, dynamic> _computeDerivedFields(
    List<Indicator> indicators, List<DailyPrice> prices) {
  final result = <String, dynamic>{
    'obvMa20': null, 'obvTrend': null, 'obvDivergence': null,
    'obvDivergenceType': null, 'bbWidth': null, 'bbWidthTrend': null,
    'bbSqueeze': null, 'ema9': null, 'ema21': null,
    'swingHigh20': null, 'swingLow20': null,
  };
  if (indicators.isEmpty) return result;

  // OBV MA20
  if (indicators.length >= 20) {
    final obvValues = indicators.take(20).map((i) => i.obv).toList();
    if (obvValues.every((v) => v != null)) {
      result['obvMa20'] = obvValues.fold<double>(0, (sum, v) => sum + v!) / 20;
    }
  }
  final latestObv = indicators.first.obv;
  final prev5Obv = indicators.length > 5 ? indicators[5].obv : null;
  if (latestObv != null && prev5Obv != null) {
    result['obvTrend'] = latestObv > prev5Obv ? 'RISING' : 'FALLING';
  }
  if (prices.length >= 5 && indicators.length >= 5) {
    final priceRising = prices[0].close > prices[4].close;
    final obvRising = latestObv != null && prev5Obv != null && latestObv > prev5Obv;
    if (priceRising && !obvRising) {
      result['obvDivergence'] = true;
      result['obvDivergenceType'] = 'NEGATIVE';
    } else if (!priceRising && obvRising) {
      result['obvDivergence'] = true;
      result['obvDivergenceType'] = 'POSITIVE';
    } else {
      result['obvDivergence'] = false;
    }
  }

  // BB
  final latestInd = indicators.first;
  if (latestInd.bbUpper != null && latestInd.bbLower != null && latestInd.bbMiddle != null && latestInd.bbMiddle! > 0) {
    final width = (latestInd.bbUpper! - latestInd.bbLower!) / latestInd.bbMiddle!;
    result['bbWidth'] = width;
    if (indicators.length > 5 && indicators[5].bbUpper != null && indicators[5].bbLower != null && indicators[5].bbMiddle != null && indicators[5].bbMiddle! > 0) {
      final prevWidth = (indicators[5].bbUpper! - indicators[5].bbLower!) / indicators[5].bbMiddle!;
      if (width < prevWidth * 0.85) result['bbWidthTrend'] = 'NARROWING';
      else if (width > prevWidth * 1.15) result['bbWidthTrend'] = 'WIDENING';
      else result['bbWidthTrend'] = 'STABLE';
    }
    if (indicators.length >= 20) {
      final widths = <double>[];
      for (int i = 0; i < 20 && i < indicators.length; i++) {
        final ind = indicators[i];
        if (ind.bbUpper != null && ind.bbLower != null && ind.bbMiddle != null && ind.bbMiddle! > 0) {
          widths.add((ind.bbUpper! - ind.bbLower!) / ind.bbMiddle!);
        }
      }
      if (widths.length >= 10) {
        final sorted = List.of(widths)..sort();
        result['bbSqueeze'] = width <= sorted[(sorted.length * 0.2).floor()];
      }
    }
  }

  // EMA
  if (prices.length >= 21) {
    final closes = prices.reversed.map((p) => p.close).toList();
    result['ema9'] = _computeEma(closes, 9);
    result['ema21'] = _computeEma(closes, 21);
  }

  // Swing
  if (prices.length >= 20) {
    final recent20 = prices.take(20);
    result['swingHigh20'] = recent20.map((p) => p.high).reduce(max);
    result['swingLow20'] = recent20.map((p) => p.low).reduce(min);
  }

  return result;
}

double? _computeEma(List<double> values, int period) {
  if (values.length < period) return null;
  double sum = 0;
  for (int i = 0; i < period; i++) sum += values[i];
  double ema = sum / period;
  final mult = 2.0 / (period + 1);
  for (int i = period; i < values.length; i++) {
    ema = (values[i] - ema) * mult + ema;
  }
  return ema;
}

bool _isMarketOpen() {
  final now = DateTime.now();
  if (now.weekday == DateTime.saturday || now.weekday == DateTime.sunday) {
    return false;
  }
  final currentMinutes = now.hour * 60 + now.minute;
  final openMinutes =
      AppConfig.marketOpenHour * 60 + AppConfig.marketOpenMinute;
  final closeMinutes =
      AppConfig.marketCloseHour * 60 + AppConfig.marketCloseMinute;
  return currentMinutes >= openMinutes && currentMinutes <= closeMinutes;
}

/// WorkManager'i baslat ve periyodik gorevi kaydet
Future<void> initializeBackgroundService() async {
  await Workmanager().initialize(
    callbackDispatcher,
    // ignore: deprecated_member_use
    isInDebugMode: kDebugMode,
  );

  // Periyodik gorev: ~2 saatte bir (Android minimum 15dk)
  // Android WorkManager minimum 15dk, biz 2 saat istiyoruz
  await Workmanager().registerPeriodicTask(
    'borsa_background_analysis',
    backgroundAnalysisTask,
    frequency: const Duration(hours: 2),
    constraints: Constraints(
      networkType: NetworkType.connected,
    ),
    existingWorkPolicy: ExistingPeriodicWorkPolicy.replace,
    backoffPolicy: BackoffPolicy.exponential,
    backoffPolicyDelay: const Duration(minutes: 10),
    tag: 'borsa_analysis',
  );

  debugPrint('[BACKGROUND] Periyodik gorev kaydedildi (2 saat aralik)');
}
