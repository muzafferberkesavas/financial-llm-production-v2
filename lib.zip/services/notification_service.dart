import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class AnalysisSignalInfo {
  final String ticker;
  final String signal;
  final double confidence;

  AnalysisSignalInfo({
    required this.ticker,
    required this.signal,
    required this.confidence,
  });
}

class NotificationService {
  static final NotificationService instance = NotificationService._();
  NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  int _hourlyAnalysisCount = 0; // Saatlik analiz sayaci

  Future<void> init() async {
    if (_initialized) return;

    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _plugin.initialize(settings);
    _initialized = true;

    // Android 13+ (API 33) bildirim izni iste
    try {
      final androidImpl = _plugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();
      if (androidImpl != null) {
        final granted = await androidImpl.requestNotificationsPermission();
        debugPrint('[BILDIRIM] Android izin durumu: $granted');
      }
    } catch (e) {
      debugPrint('[BILDIRIM] Izin isteme hatasi: $e');
    }
  }

  /// Gunluk analiz bildirimi - her zaman gonder
  Future<void> showDailyAnalysisNotification({
    required List<AnalysisSignalInfo> signals,
  }) async {
    if (!_initialized) await init();
    _hourlyAnalysisCount = 0; // Yeni gun, sayaci sifirla
    await _showSummaryNotification(
      title: 'Gunluk Analiz Tamamlandi',
      signals: signals,
    );
  }

  /// Saatlik analiz bildirimi - her 2 analizde 1 gonder (2 saatte 1)
  Future<void> showHourlyAnalysisNotification({
    required List<AnalysisSignalInfo> signals,
  }) async {
    _hourlyAnalysisCount++;
    if (_hourlyAnalysisCount % 2 != 0) {
      debugPrint('[BILDIRIM] Saatlik analiz #$_hourlyAnalysisCount - bildirim atlanıyor');
      return;
    }
    if (!_initialized) await init();
    await _showSummaryNotification(
      title: 'Saatlik Analiz',
      signals: signals,
    );
  }

  Future<void> _showSummaryNotification({
    required String title,
    required List<AnalysisSignalInfo> signals,
  }) async {
    if (signals.isEmpty) return;

    // Kisa ozet: portfoy + onemli sinyaller
    final shortBody = _buildShortBody(signals);
    // Genisletilmis ozet: her hisse AL/SAT detayi
    final longBody = _buildLongBody(signals);

    final androidDetails = AndroidNotificationDetails(
      'borsa_analysis',
      'Analiz Bildirimleri',
      channelDescription: 'AI analiz tamamlanma bildirimleri',
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
      styleInformation: BigTextStyleInformation(
        longBody,
        contentTitle: title,
        summaryText: '${signals.length} hisse analiz edildi',
      ),
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: const DarwinNotificationDetails(),
    );

    await _plugin.show(
      'analysis_summary'.hashCode,
      title,
      shortBody,
      details,
    );
  }

  String _buildShortBody(List<AnalysisSignalInfo> signals) {
    final buys = signals.where((s) =>
        s.signal == 'AL' || s.signal == 'GUCLU_AL').toList();
    final sells = signals.where((s) =>
        s.signal == 'SAT' || s.signal == 'ACIL_SAT' || s.signal == 'GUCLU_SAT').toList();

    final parts = <String>[];
    if (buys.isNotEmpty) {
      parts.add('AL: ${buys.map((s) => s.ticker).join(", ")}');
    }
    if (sells.isNotEmpty) {
      parts.add('SAT: ${sells.map((s) => s.ticker).join(", ")}');
    }
    if (parts.isEmpty) {
      parts.add('${signals.length} hisse analiz edildi');
    }
    return parts.join(' | ');
  }

  String _buildLongBody(List<AnalysisSignalInfo> signals) {
    // Sinyale gore grupla, guven sirasina gore sirala
    final sorted = List<AnalysisSignalInfo>.from(signals)
      ..sort((a, b) => b.confidence.compareTo(a.confidence));

    final lines = <String>[];
    for (final s in sorted) {
      final label = _signalLabel(s.signal);
      final conf = (s.confidence * 100).toStringAsFixed(0);
      lines.add('${s.ticker}: $label (%$conf)');
    }
    return lines.join('\n');
  }

  String _signalLabel(String signal) {
    switch (signal.toUpperCase()) {
      case 'GUCLU_AL':
        return 'Guclu Al';
      case 'AL':
        return 'Al';
      case 'IZLE':
        return 'Izle';
      case 'TUT':
        return 'Tut';
      case 'KISMI_SAT':
        return 'Kismi Sat';
      case 'SAT':
        return 'Sat';
      case 'GUCLU_SAT':
        return 'Guclu Sat';
      case 'ACIL_SAT':
        return 'Acil Sat';
      default:
        return signal;
    }
  }
}
