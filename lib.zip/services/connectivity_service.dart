import 'dart:io';

class ConnectivityService {
  static Future<bool> checkConnectivity() async {
    // Birden fazla host dene (operatör/DNS engeli ihtimaline karsi)
    final hosts = ['google.com', 'cloudflare.com', '1.1.1.1'];
    for (final host in hosts) {
      try {
        final result = await InternetAddress.lookup(host)
            .timeout(const Duration(seconds: 5));
        if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
          return true;
        }
      } catch (_) {
        continue;
      }
    }
    return false;
  }
}
