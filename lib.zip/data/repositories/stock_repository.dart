import '../../config/app_config.dart';
import '../local/database_helper.dart';
import '../models/stock.dart';

class StockRepository {
  final DatabaseHelper _db = DatabaseHelper.instance;

  Future<List<Stock>> getAllStocks() async {
    final db = await _db.database;
    final maps = await db.query('stocks', orderBy: 'ticker ASC');
    return maps.map((m) => Stock.fromMap(m)).toList();
  }

  Future<List<Stock>> getActiveStocks() async {
    final db = await _db.database;
    final maps = await db.query('stocks',
        where: 'is_active = 1', orderBy: 'ticker ASC');
    return maps.map((m) => Stock.fromMap(m)).toList();
  }

  Future<List<Stock>> getPortfolioStocks() async {
    final db = await _db.database;
    final maps = await db.query('stocks',
        where: 'is_in_portfolio = 1', orderBy: 'ticker ASC');
    return maps.map((m) => Stock.fromMap(m)).toList();
  }

  Future<Stock?> getById(int id) async {
    final db = await _db.database;
    final maps = await db.query('stocks', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return Stock.fromMap(maps.first);
  }

  Future<void> setActive(int stockId, bool isActive) async {
    final db = await _db.database;
    await db.update('stocks', {'is_active': isActive ? 1 : 0},
        where: 'id = ?', whereArgs: [stockId]);
  }

  Future<void> clearAllActive() async {
    final db = await _db.database;
    await db.update('stocks', {'is_active': 0});
  }

  Future<void> setInPortfolio(int stockId, bool inPortfolio) async {
    final db = await _db.database;
    final data = <String, dynamic>{
      'is_in_portfolio': inPortfolio ? 1 : 0,
    };
    if (inPortfolio) {
      data['portfolio_since'] = DateTime.now().millisecondsSinceEpoch;
    } else {
      data['portfolio_since'] = null;
    }
    await db.update('stocks', data,
        where: 'id = ?', whereArgs: [stockId]);
  }

  Future<void> setInPortfolioWithDate(int stockId, bool inPortfolio, int? sinceMs) async {
    final db = await _db.database;
    await db.update('stocks', {
      'is_in_portfolio': inPortfolio ? 1 : 0,
      'portfolio_since': inPortfolio ? sinceMs : null,
    }, where: 'id = ?', whereArgs: [stockId]);
  }

  Future<void> clearAllPortfolio() async {
    final db = await _db.database;
    await db.update('stocks', {'is_in_portfolio': 0, 'portfolio_since': null});
  }

  Future<void> seedBist100IfEmpty() async {
    final db = await _db.database;
    final count = (await db.rawQuery('SELECT COUNT(*) as cnt FROM stocks'))
        .first['cnt'] as int;
    if (count > 0) return;

    final batch = db.batch();
    for (final s in _bist100Stocks) {
      batch.insert('stocks', s.toMap()..remove('id'));
    }
    await batch.commit(noResult: true);

    // Emtialari da ekle
    await seedCommoditiesIfMissing();
  }

  /// Emtia ticker'lari DB'de yoksa ekler, varsa ismini gunceller
  Future<void> seedCommoditiesIfMissing() async {
    final db = await _db.database;
    for (final entry in AppConfig.commodityTickers.entries) {
      final existing = await db.query('stocks',
          where: 'ticker = ?', whereArgs: [entry.key]);
      if (existing.isEmpty) {
        await db.insert('stocks', Stock(
          ticker: entry.key,
          name: entry.value,
          sector: AppConfig.commoditySector,
        ).toMap()..remove('id'));
      } else {
        // Isim degismisse guncelle
        final currentName = existing.first['name'] as String?;
        if (currentName != entry.value) {
          await db.update('stocks', {'name': entry.value},
              where: 'ticker = ?', whereArgs: [entry.key]);
        }
      }
    }
  }

  /// Emtia stock'larini getirir
  Future<List<Stock>> getCommodityStocks() async {
    final db = await _db.database;
    final maps = await db.query('stocks',
        where: 'sector = ?', whereArgs: [AppConfig.commoditySector]);
    return maps.map((m) => Stock.fromMap(m)).toList();
  }
}

final _bist100Stocks = [
  Stock(ticker: 'AEFES', name: 'Anadolu Efes', sector: 'Icecek'),
  Stock(ticker: 'AFYON', name: 'Afyon Cimento', sector: 'Cimento'),
  Stock(ticker: 'AGESA', name: 'AgeSA Hayat ve Emeklilik', sector: 'Sigorta'),
  Stock(ticker: 'AGHOL', name: 'AG Anadolu Grubu Holding', sector: 'Holding'),
  Stock(ticker: 'AKBNK', name: 'Akbank', sector: 'Bankacilik'),
  Stock(ticker: 'AKCNS', name: 'Akcansa', sector: 'Cimento'),
  Stock(ticker: 'AKFGY', name: 'Akfen GYO', sector: 'GYO'),
  Stock(ticker: 'AKSA', name: 'Aksa Akrilik', sector: 'Kimya'),
  Stock(ticker: 'AKSEN', name: 'Aksa Enerji', sector: 'Enerji'),
  Stock(ticker: 'ALARK', name: 'Alarko Holding', sector: 'Holding'),
  Stock(ticker: 'ALFAS', name: 'Alfa Solar Enerji', sector: 'Enerji'),
  Stock(ticker: 'ARCLK', name: 'Arcelik', sector: 'Dayanikli Tuketim'),
  Stock(ticker: 'ASELS', name: 'Aselsan', sector: 'Savunma'),
  Stock(ticker: 'ASTOR', name: 'Astor Enerji', sector: 'Enerji'),
  Stock(ticker: 'BASGZ', name: 'Baskent Dogalgaz', sector: 'Enerji'),
  Stock(ticker: 'BERA', name: 'Bera Holding', sector: 'Holding'),
  Stock(ticker: 'BIMAS', name: 'BIM Magazalar', sector: 'Perakende'),
  Stock(ticker: 'BIOEN', name: 'Biotrend Enerji', sector: 'Enerji'),
  Stock(ticker: 'BRYAT', name: 'Borusan Yatirim', sector: 'Holding'),
  Stock(ticker: 'BTCIM', name: 'Baticim', sector: 'Cimento'),
  Stock(ticker: 'CANTE', name: 'Can2 Termik', sector: 'Enerji'),
  Stock(ticker: 'CCOLA', name: 'Coca-Cola Icecek', sector: 'Icecek'),
  Stock(ticker: 'CEMTS', name: 'Cemtas', sector: 'Metal'),
  Stock(ticker: 'CIMSA', name: 'Cimsa', sector: 'Cimento'),
  Stock(ticker: 'CWENE', name: 'CW Enerji', sector: 'Enerji'),
  Stock(ticker: 'DOAS', name: 'Dogus Otomotiv', sector: 'Otomotiv'),
  Stock(ticker: 'DOHOL', name: 'Dogan Holding', sector: 'Holding'),
  Stock(ticker: 'ECILC', name: 'Eczacibasi Ilac', sector: 'Ilac'),
  Stock(ticker: 'EGEEN', name: 'Ege Endustri', sector: 'Otomotiv'),
  Stock(ticker: 'EKGYO', name: 'Emlak Konut GYO', sector: 'GYO'),
  Stock(ticker: 'ENJSA', name: 'Enerjisa Enerji', sector: 'Enerji'),
  Stock(ticker: 'ENKAI', name: 'Enka Insaat', sector: 'Insaat'),
  Stock(ticker: 'EREGL', name: 'Eregli Demir Celik', sector: 'Metal'),
  Stock(ticker: 'EUPWR', name: 'Europower Enerji', sector: 'Enerji'),
  Stock(ticker: 'FROTO', name: 'Ford Otosan', sector: 'Otomotiv'),
  Stock(ticker: 'GARAN', name: 'Garanti BBVA', sector: 'Bankacilik'),
  Stock(ticker: 'GESAN', name: 'Giresun Enerji', sector: 'Enerji'),
  Stock(ticker: 'GUBRF', name: 'Gubre Fabrikalari', sector: 'Kimya'),
  Stock(ticker: 'HALKB', name: 'Halkbank', sector: 'Bankacilik'),
  Stock(ticker: 'HEKTS', name: 'Hektas', sector: 'Kimya'),
  Stock(ticker: 'ISCTR', name: 'Is Bankasi C', sector: 'Bankacilik'),
  Stock(ticker: 'ISGYO', name: 'Is GYO', sector: 'GYO'),
  Stock(ticker: 'KCHOL', name: 'Koc Holding', sector: 'Holding'),
  Stock(ticker: 'KLRHO', name: 'Kiler Holding', sector: 'Holding'),
  Stock(ticker: 'KMPUR', name: 'Kimmtas Poliuretan', sector: 'Kimya'),
  Stock(ticker: 'KONTR', name: 'Kontrolmatik', sector: 'Teknoloji'),
  Stock(ticker: 'KONYA', name: 'Konya Cimento', sector: 'Cimento'),
  Stock(ticker: 'KOZAA', name: 'Koza Anadolu', sector: 'Madencilik'),
  Stock(ticker: 'KOZAL', name: 'Koza Altin', sector: 'Madencilik'),
  Stock(ticker: 'KRDMD', name: 'Kardemir D', sector: 'Metal'),
  Stock(ticker: 'KZBGY', name: 'Kizilbuk GYO', sector: 'GYO'),
  Stock(ticker: 'LOGO', name: 'Logo Yazilim', sector: 'Teknoloji'),
  Stock(ticker: 'MAVI', name: 'Mavi Giyim', sector: 'Tekstil'),
  Stock(ticker: 'MGROS', name: 'Migros', sector: 'Perakende'),
  Stock(ticker: 'MPARK', name: 'MLP Saglik', sector: 'Saglik'),
  Stock(ticker: 'OBAMS', name: 'Oba Makarna', sector: 'Gida'),
  Stock(ticker: 'ODAS', name: 'Odas Elektrik', sector: 'Enerji'),
  Stock(ticker: 'OTKAR', name: 'Otokar', sector: 'Otomotiv'),
  Stock(ticker: 'OYAKC', name: 'Oyak Cimento', sector: 'Cimento'),
  Stock(ticker: 'PEKGY', name: 'Pekintas GYO', sector: 'GYO'),
  Stock(ticker: 'PETKM', name: 'Petkim', sector: 'Kimya'),
  Stock(ticker: 'PGSUS', name: 'Pegasus', sector: 'Havacilik'),
  Stock(ticker: 'QUAGR', name: 'QUA Granite', sector: 'Seramik'),
  Stock(ticker: 'SAHOL', name: 'Sabanci Holding', sector: 'Holding'),
  Stock(ticker: 'SASA', name: 'SASA Polyester', sector: 'Kimya'),
  Stock(ticker: 'SDTTR', name: 'SDT Uzay ve Teknoloji', sector: 'Savunma'),
  Stock(ticker: 'SISE', name: 'Sisecam', sector: 'Cam'),
  Stock(ticker: 'SKBNK', name: 'Sekerbank', sector: 'Bankacilik'),
  Stock(ticker: 'SMRTG', name: 'Smartiks Yazilim', sector: 'Teknoloji'),
  Stock(ticker: 'SOKM', name: 'Sok Marketler', sector: 'Perakende'),
  Stock(ticker: 'TABGD', name: 'Tab Gida', sector: 'Gida'),
  Stock(ticker: 'TATGD', name: 'Tat Gida', sector: 'Gida'),
  Stock(ticker: 'TAVHL', name: 'TAV Havalimanlari', sector: 'Havacilik'),
  Stock(ticker: 'TCELL', name: 'Turkcell', sector: 'Telekomunikasyon'),
  Stock(ticker: 'THYAO', name: 'Turk Hava Yollari', sector: 'Havacilik'),
  Stock(ticker: 'TKFEN', name: 'Tekfen Holding', sector: 'Holding'),
  Stock(ticker: 'TKNSA', name: 'Teknosa', sector: 'Perakende'),
  Stock(ticker: 'TMSN', name: 'Tumosan Motor', sector: 'Otomotiv'),
  Stock(ticker: 'TOASO', name: 'Tofas', sector: 'Otomotiv'),
  Stock(ticker: 'TPMS', name: 'Toprak Mahsulleri Ofisi', sector: 'Tarim'),
  Stock(ticker: 'TTKOM', name: 'Turk Telekom', sector: 'Telekomunikasyon'),
  Stock(ticker: 'TTRAK', name: 'Turk Traktor', sector: 'Otomotiv'),
  Stock(ticker: 'TUKAS', name: 'Tukas Gida', sector: 'Gida'),
  Stock(ticker: 'TUPRS', name: 'Tupras', sector: 'Petrol'),
  Stock(ticker: 'TURSG', name: 'Turkiye Sigorta', sector: 'Sigorta'),
  Stock(ticker: 'ULKER', name: 'Ulker Biskuvi', sector: 'Gida'),
  Stock(ticker: 'ULUUN', name: 'Ulusoy Un Sanayi', sector: 'Gida'),
  Stock(ticker: 'VAKBN', name: 'Vakifbank', sector: 'Bankacilik'),
  Stock(ticker: 'VESBE', name: 'Vestel Beyaz Esya', sector: 'Dayanikli Tuketim'),
  Stock(ticker: 'VESTL', name: 'Vestel Elektronik', sector: 'Elektronik'),
  Stock(ticker: 'YKBNK', name: 'Yapi Kredi', sector: 'Bankacilik'),
  Stock(ticker: 'YYLGD', name: 'Yayla Agro Gida', sector: 'Gida'),
  Stock(ticker: 'ZOREN', name: 'Zorlu Enerji', sector: 'Enerji'),
  Stock(ticker: 'ZTCNM', name: 'Zubeyde Tuneli Cimento', sector: 'Cimento'),
  Stock(ticker: 'SNGYO', name: 'Sinpas GYO', sector: 'GYO'),
  Stock(ticker: 'ANGEN', name: 'Anadolu Genetik', sector: 'Saglik'),
  Stock(ticker: 'SMEN', name: 'Soktas Mensucat', sector: 'Tekstil'),
  Stock(ticker: 'KCAER', name: 'Kocaerli', sector: 'Tarim'),
  Stock(ticker: 'ANSGR', name: 'Anadolu Sigorta', sector: 'Sigorta'),
  Stock(ticker: 'ARDYZ', name: 'Ardor Yazilim', sector: 'Teknoloji'),
  Stock(ticker: 'KARTN', name: 'Kartonsan', sector: 'Ambalaj'),
];
