import 'package:sqflite/sqflite.dart';
import '../local/database_helper.dart';
import '../models/ai_analysis.dart';
import '../models/analysis_session.dart';
import '../models/indicator.dart';
import '../models/fibonacci.dart';
import '../models/transaction.dart';
import '../../config/app_config.dart';

class AnalysisRepository {
  final DatabaseHelper _db = DatabaseHelper.instance;

  // Indicators
  Future<void> saveIndicators(List<Indicator> indicators) async {
    final db = await _db.database;
    final batch = db.batch();
    for (final ind in indicators) {
      batch.insert('indicators', ind.toMap()..remove('id'),
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  Future<Indicator?> getLatestIndicator(int stockId) async {
    final db = await _db.database;
    final maps = await db.query('indicators',
        where: 'stock_id = ?',
        whereArgs: [stockId],
        orderBy: 'date DESC',
        limit: 1);
    if (maps.isEmpty) return null;
    return Indicator.fromMap(maps.first);
  }

  Future<List<Indicator>> getIndicatorsForStock(int stockId) async {
    final db = await _db.database;
    final maps = await db.query('indicators',
        where: 'stock_id = ?', whereArgs: [stockId], orderBy: 'date DESC');
    return maps.map((m) => Indicator.fromMap(m)).toList();
  }

  // Fibonacci
  Future<void> saveFibonacci(FibonacciData fib) async {
    final db = await _db.database;
    await db.insert('fibonacci_data', fib.toMap()..remove('id'),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<FibonacciData?> getFibonacci(int stockId) async {
    final db = await _db.database;
    final maps = await db.query('fibonacci_data',
        where: 'stock_id = ?', whereArgs: [stockId]);
    if (maps.isEmpty) return null;
    return FibonacciData.fromMap(maps.first);
  }

  // ==================== ANALYSIS SESSIONS ====================

  /// Yeni analiz oturumu olusturur, ID dondurur
  Future<int> createSession(AnalysisSession session) async {
    final db = await _db.database;
    return await db.insert('analysis_sessions', session.toMap()..remove('id'));
  }

  /// Session'in prompt/response text'ini gunceller
  Future<void> updateSessionTexts(int sessionId, String promptText, String responseText) async {
    final db = await _db.database;
    await db.update('analysis_sessions', {
      'prompt_text': promptText,
      'response_text': responseText,
    }, where: 'id = ?', whereArgs: [sessionId]);
  }

  /// Session'in stock_count'unu gunceller
  Future<void> updateSessionStockCount(int sessionId, int stockCount) async {
    final db = await _db.database;
    await db.update('analysis_sessions', {
      'stock_count': stockCount,
    }, where: 'id = ?', whereArgs: [sessionId]);
  }

  /// Tek bir session getirir
  Future<AnalysisSession?> getSession(int sessionId) async {
    final db = await _db.database;
    final maps = await db.query('analysis_sessions',
        where: 'id = ?', whereArgs: [sessionId]);
    if (maps.isEmpty) return null;
    return AnalysisSession.fromMap(maps.first);
  }

  /// Son session'lari getirir (yeniden eskiye)
  Future<List<AnalysisSession>> getRecentSessions({int limit = 30}) async {
    final db = await _db.database;
    final maps = await db.query('analysis_sessions',
        orderBy: 'datetime DESC', limit: limit);
    return maps.map((m) => AnalysisSession.fromMap(m)).toList();
  }

  /// Bir session'a ait tum analizleri getirir (confidence DESC)
  Future<List<AiAnalysis>> getAnalysesForSession(int sessionId) async {
    final db = await _db.database;
    final maps = await db.query('ai_analyses',
        where: 'session_id = ?',
        whereArgs: [sessionId],
        orderBy: 'confidence DESC');
    return maps.map((m) => AiAnalysis.fromMap(m)).toList();
  }

  /// Session ve iliskili analizleri siler
  Future<void> deleteSession(int sessionId) async {
    final db = await _db.database;
    await db.delete('ai_analyses', where: 'session_id = ?', whereArgs: [sessionId]);
    await db.delete('analysis_sessions', where: 'id = ?', whereArgs: [sessionId]);
  }

  /// Bugunun gunluk session'lari haric tum session/analizleri siler
  Future<int> deleteAllSessionsExceptTodayDaily() async {
    final db = await _db.database;
    final now = DateTime.now();
    final todayMs = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;

    // Silinecek session ID'lerini bul
    final toDelete = await db.query('analysis_sessions',
        columns: ['id'],
        where: 'NOT (analysis_type = ? AND datetime >= ?)',
        whereArgs: ['GUNLUK', todayMs]);
    final ids = toDelete.map((m) => m['id'] as int).toList();

    if (ids.isEmpty) return 0;

    final placeholders = ids.map((_) => '?').join(',');
    await db.rawDelete(
        'DELETE FROM ai_analyses WHERE session_id IN ($placeholders)', ids);
    final deleted = await db.rawDelete(
        'DELETE FROM analysis_sessions WHERE id IN ($placeholders)', ids);

    // session_id'siz eski analizleri de temizle
    await db.delete('ai_analyses',
        where: 'session_id IS NULL AND NOT (analysis_type = ? AND datetime >= ?)',
        whereArgs: ['GUNLUK', todayMs]);

    return deleted;
  }

  // ==================== AI ANALYSES ====================

  Future<void> saveAiAnalysis(AiAnalysis analysis) async {
    final db = await _db.database;
    await db.insert('ai_analyses', analysis.toMap()..remove('id'));
    await db.rawDelete('''
      DELETE FROM ai_analyses WHERE stock_id = ? AND id NOT IN (
        SELECT id FROM ai_analyses WHERE stock_id = ? ORDER BY datetime DESC LIMIT ?
      )
    ''', [analysis.stockId, analysis.stockId, AppConfig.maxCommentsPerStock]);
  }

  Future<AiAnalysis?> getLatestAiAnalysis(int stockId) async {
    final db = await _db.database;
    final maps = await db.query('ai_analyses',
        where: 'stock_id = ?',
        whereArgs: [stockId],
        orderBy: 'datetime DESC',
        limit: 1);
    if (maps.isEmpty) return null;
    return AiAnalysis.fromMap(maps.first);
  }

  /// O gunun GUNLUK analizini getirir (saatlik analizde onceki olarak kullanilir)
  Future<AiAnalysis?> getTodayDailyAnalysis(int stockId) async {
    final db = await _db.database;
    final now = DateTime.now();
    final todayMs = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    final maps = await db.query('ai_analyses',
        where: 'stock_id = ? AND analysis_type = ? AND datetime >= ?',
        whereArgs: [stockId, 'GUNLUK', todayMs],
        orderBy: 'datetime DESC',
        limit: 1);
    if (maps.isEmpty) {
      // Gunluk analiz yoksa en son analizi getir (fallback)
      return getLatestAiAnalysis(stockId);
    }
    return AiAnalysis.fromMap(maps.first);
  }

  /// Bugunku sabah analizinin gun ici notlarini getirir
  Future<String?> getMorningNotes(int stockId) async {
    final db = await _db.database;
    final now = DateTime.now();
    final todayMs = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    final maps = await db.query('ai_analyses',
        columns: ['intraday_notes'],
        where: 'stock_id = ? AND analysis_type = ? AND datetime >= ? AND intraday_notes IS NOT NULL',
        whereArgs: [stockId, 'GUNLUK', todayMs],
        orderBy: 'datetime DESC',
        limit: 1);
    if (maps.isEmpty) return null;
    return maps.first['intraday_notes'] as String?;
  }

  /// Bugunun gunluk analizleri haric tum analizleri siler
  Future<int> deleteAllExceptTodayDaily() async {
    final db = await _db.database;
    final now = DateTime.now();
    final todayMs = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    return await db.delete('ai_analyses',
        where: 'NOT (analysis_type = ? AND datetime >= ?)',
        whereArgs: ['GUNLUK', todayMs]);
  }

  Future<List<AiAnalysis>> getAiAnalysesForStock(int stockId) async {
    final db = await _db.database;
    final maps = await db.query('ai_analyses',
        where: 'stock_id = ?', whereArgs: [stockId], orderBy: 'datetime DESC');
    return maps.map((m) => AiAnalysis.fromMap(m)).toList();
  }

  // Transactions
  Future<void> saveTransaction(StockTransaction tx) async {
    final db = await _db.database;
    await db.insert('transactions', tx.toMap()..remove('id'));
  }

  Future<List<StockTransaction>> getTransactionsForStock(int stockId) async {
    final db = await _db.database;
    final maps = await db.query('transactions',
        where: 'stock_id = ?', whereArgs: [stockId], orderBy: 'datetime DESC');
    return maps.map((m) => StockTransaction.fromMap(m)).toList();
  }

  Future<void> deleteTransaction(int txId) async {
    final db = await _db.database;
    await db.delete('transactions', where: 'id = ?', whereArgs: [txId]);
  }

  /// Tum son AI analizlerini getirir (tum hisseler, yeniden eskiye)
  Future<List<AiAnalysis>> getAllRecentAnalyses({int limit = 50}) async {
    final db = await _db.database;
    final maps = await db.query('ai_analyses',
        orderBy: 'datetime DESC', limit: limit);
    return maps.map((m) => AiAnalysis.fromMap(m)).toList();
  }

  /// Tek bir AI analizini siler
  Future<void> deleteAiAnalysis(int id) async {
    final db = await _db.database;
    await db.delete('ai_analyses', where: 'id = ?', whereArgs: [id]);
  }

  /// analysisRetentionDays'den eski analizleri siler
  Future<int> cleanupOldAnalyses() async {
    final db = await _db.database;
    final cutoff = DateTime.now()
        .subtract(Duration(days: AppConfig.analysisRetentionDays))
        .millisecondsSinceEpoch;
    return await db
        .delete('ai_analyses', where: 'datetime < ?', whereArgs: [cutoff]);
  }

  // Cleanup - her tablo kendi retention policy'sine gore
  Future<void> cleanupOldData() async {
    final db = await _db.database;

    // Indikatorler: windowDays (250 gun)
    final indicatorCutoff = DateTime.now()
        .subtract(Duration(days: AppConfig.windowDays))
        .millisecondsSinceEpoch;
    await db.delete('indicators', where: 'date < ?', whereArgs: [indicatorCutoff]);

    // AI analizleri: analysisRetentionDays (14 gun)
    final analysisCutoff = DateTime.now()
        .subtract(Duration(days: AppConfig.analysisRetentionDays))
        .millisecondsSinceEpoch;
    await db.delete('ai_analyses', where: 'datetime < ?', whereArgs: [analysisCutoff]);

    // Eski session'lari da temizle
    await db.delete('analysis_sessions', where: 'datetime < ?', whereArgs: [analysisCutoff]);

    // Islemler: transactionRetentionDays (365 gun)
    final txCutoff = DateTime.now()
        .subtract(Duration(days: AppConfig.transactionRetentionDays))
        .millisecondsSinceEpoch;
    await db.delete('transactions', where: 'datetime < ?', whereArgs: [txCutoff]);
  }

  /// Silinen verilerden sonra DB dosya boyutunu kucultmek icin VACUUM
  Future<void> vacuumDatabase() async {
    final db = await _db.database;
    await db.execute('VACUUM');
  }
}
