import 'package:sqflite/sqflite.dart';
import '../local/database_helper.dart';
import '../models/daily_price.dart';
import '../remote/yahoo_finance_api.dart';
import '../../config/app_config.dart';

class PriceRepository {
  final DatabaseHelper _db = DatabaseHelper.instance;
  final YahooFinanceApi _yahooApi = YahooFinanceApi();
  String? lastApiError;

  /// Checks if stock data is already up-to-date (has data from today or last trading day).
  /// Returns true if data is fresh and no fetch is needed.
  Future<bool> isDataFresh(int stockId) async {
    final db = await _db.database;
    final maps = await db.query('daily_prices',
        where: 'stock_id = ?',
        whereArgs: [stockId],
        orderBy: 'date DESC',
        limit: 1);
    if (maps.isEmpty) return false;

    final latestDate =
        DateTime.fromMillisecondsSinceEpoch(maps.first['date'] as int);
    final now = DateTime.now();

    // If latest data is from today, it's fresh
    if (_isSameDay(latestDate, now)) return true;

    // If today is Monday and latest is Friday/Saturday/Sunday, still fresh before market open
    if (now.weekday == DateTime.monday) {
      final friday = now.subtract(Duration(days: now.weekday - DateTime.friday));
      if (_isSameDay(latestDate, friday) || latestDate.isAfter(friday)) {
        final marketOpenMinutes =
            AppConfig.marketOpenHour * 60 + AppConfig.marketOpenMinute;
        final nowMinutes = now.hour * 60 + now.minute;
        if (nowMinutes < marketOpenMinutes) return true;
      }
    }

    // If today is weekend, Friday data is enough
    if (now.weekday == DateTime.saturday || now.weekday == DateTime.sunday) {
      final friday = now.subtract(Duration(days: now.weekday - DateTime.friday));
      if (_isSameDay(latestDate, friday) || latestDate.isAfter(friday)) {
        return true;
      }
    }

    // If latest is yesterday and market hasn't opened yet today
    final yesterday = now.subtract(const Duration(days: 1));
    if (_isSameDay(latestDate, yesterday)) {
      final marketOpenMinutes =
          AppConfig.marketOpenHour * 60 + AppConfig.marketOpenMinute;
      final nowMinutes = now.hour * 60 + now.minute;
      if (nowMinutes < marketOpenMinutes) return true;
    }

    return false;
  }

  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  /// Fetches only missing data. If stock already has recent data,
  /// fetches with shorter range to save bandwidth.
  Future<List<DailyPrice>> fetchAndSaveDailyPrices(
      String ticker, int stockId,
      {bool force = false}) async {
    // Check if data is fresh - skip if so (unless forced)
    if (!force && await isDataFresh(stockId)) {
      return await getDailyPrices(stockId);
    }

    // Determine how much data we need
    final db = await _db.database;
    final maps = await db.query('daily_prices',
        where: 'stock_id = ?',
        whereArgs: [stockId],
        orderBy: 'date DESC',
        limit: 1);

    String range = '1y'; // ~250 islem gunu, SMA200 icin yeterli
    if (maps.isNotEmpty) {
      final latestDate =
          DateTime.fromMillisecondsSinceEpoch(maps.first['date'] as int);
      final daysMissing = DateTime.now().difference(latestDate).inDays;

      if (daysMissing <= 7) {
        range = '5d';
      } else if (daysMissing <= 35) {
        range = '1mo';
      } else if (daysMissing <= 100) {
        range = '6mo';
      }
    }

    final prices =
        await _yahooApi.fetchDailyPrices(ticker, stockId, range: range);
    lastApiError = _yahooApi.lastError;
    if (prices.isNotEmpty) {
      final batch = db.batch();
      for (final p in prices) {
        batch.insert('daily_prices', p.toMap()..remove('id'),
            conflictAlgorithm: ConflictAlgorithm.replace);
      }
      await batch.commit(noResult: true);
    }
    return prices;
  }

  /// Emtia fiyatlarini USD/ons -> TL/gram cevirip kaydeder
  Future<List<DailyPrice>> fetchAndSaveCommodityPrices(
      String ticker, int stockId,
      {bool force = false}) async {
    if (!force && await isDataFresh(stockId)) {
      return await getDailyPrices(stockId);
    }

    final db = await _db.database;
    final maps = await db.query('daily_prices',
        where: 'stock_id = ?',
        whereArgs: [stockId],
        orderBy: 'date DESC',
        limit: 1);

    String range = '1y';
    if (maps.isNotEmpty) {
      final latestDate =
          DateTime.fromMillisecondsSinceEpoch(maps.first['date'] as int);
      final daysMissing = DateTime.now().difference(latestDate).inDays;
      if (daysMissing <= 7) range = '5d';
      else if (daysMissing <= 35) range = '1mo';
      else if (daysMissing <= 100) range = '6mo';
    }

    // 1. Emtia fiyatlarini cek (USD/ons)
    final usdPrices =
        await _yahooApi.fetchDailyPrices(ticker, stockId, range: range);
    lastApiError = _yahooApi.lastError;
    if (usdPrices.isEmpty) return usdPrices;

    // 2. USDTRY kurunu ayni periyod icin cek
    final usdTryPrices = await _yahooApi.fetchDailyPrices(
        AppConfig.usdTryTicker, 0, range: range);

    if (usdTryPrices.isEmpty) {
      // Kur alinamazsa USD cinsinden kaydet (fallback)
      lastApiError = 'USDTRY kuru alinamadi, USD fiyatlar kaydedildi';
      final batch = db.batch();
      for (final p in usdPrices) {
        batch.insert('daily_prices', p.toMap()..remove('id'),
            conflictAlgorithm: ConflictAlgorithm.replace);
      }
      await batch.commit(noResult: true);
      return usdPrices;
    }

    // 3. Tarih -> USDTRY kuru map'i olustur (gun bazinda eslestirme)
    final usdTryMap = <int, double>{};
    for (final p in usdTryPrices) {
      // Tarihi gune yuvarla (ayni gun eslesmesi icin)
      final dayKey = DateTime.fromMillisecondsSinceEpoch(p.date);
      final normalizedKey = DateTime(dayKey.year, dayKey.month, dayKey.day)
          .millisecondsSinceEpoch;
      usdTryMap[normalizedKey] = p.close;
    }

    // Son bilinen kur (eslesmezse fallback)
    final latestUsdTry = usdTryPrices.last.close;

    // 4. USD/ons -> TL/gram cevirimi
    const divisor = AppConfig.troyOunceToGram;
    final convertedPrices = <DailyPrice>[];
    for (final p in usdPrices) {
      final dayKey = DateTime.fromMillisecondsSinceEpoch(p.date);
      final normalizedKey = DateTime(dayKey.year, dayKey.month, dayKey.day)
          .millisecondsSinceEpoch;
      final rate = usdTryMap[normalizedKey] ?? latestUsdTry;
      final factor = rate / divisor;

      convertedPrices.add(DailyPrice(
        stockId: stockId,
        date: p.date,
        open: p.open * factor,
        high: p.high * factor,
        low: p.low * factor,
        close: p.close * factor,
        volume: p.volume,
      ));
    }

    // 5. Kaydet
    final batch = db.batch();
    for (final p in convertedPrices) {
      batch.insert('daily_prices', p.toMap()..remove('id'),
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
    return convertedPrices;
  }

  Future<List<DailyPrice>> getDailyPrices(int stockId,
      {int limit = 250}) async {
    final db = await _db.database;
    final maps = await db.query('daily_prices',
        where: 'stock_id = ?',
        whereArgs: [stockId],
        orderBy: 'date DESC',
        limit: limit);
    return maps.map((m) => DailyPrice.fromMap(m)).toList();
  }

  /// Check if a stock has any price data at all
  Future<bool> hasData(int stockId) async {
    final db = await _db.database;
    final result = await db.rawQuery(
        'SELECT COUNT(*) as cnt FROM daily_prices WHERE stock_id = ?',
        [stockId]);
    return (result.first['cnt'] as int) > 0;
  }

  Future<void> cleanupOldData() async {
    final db = await _db.database;
    final cutoff = DateTime.now()
        .subtract(Duration(days: AppConfig.windowDays))
        .millisecondsSinceEpoch;
    await db.delete('daily_prices', where: 'date < ?', whereArgs: [cutoff]);
  }
}
