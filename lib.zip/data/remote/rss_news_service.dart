import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:xml/xml.dart';
import '../../config/app_config.dart';
import '../models/news_item.dart';

class NewsSource {
  final String name;
  final String url;
  final String language;
  final String category;
  final bool isAtom; // Atom format (NTV gibi) vs RSS 2.0

  const NewsSource(this.name, this.url, this.language, this.category,
      {this.isAtom = false});
}

const List<NewsSource> defaultNewsSources = [
  // BIST/borsa odakli — en yuksek oncelik
  NewsSource(
    'BigPara',
    'https://bigpara.hurriyet.com.tr/rss/',
    'tr',
    'STOCK',
  ),
  // Genel finans — kaliteli
  NewsSource(
    'Bloomberg HT',
    'https://www.bloomberght.com/rss',
    'tr',
    'MACRO',
  ),
  // Uluslararasi + Turkiye finans
  NewsSource(
    'Investing.com Turkey',
    'https://tr.investing.com/rss/news.rss',
    'tr',
    'MACRO',
  ),
  // Ekonomi analiz
  NewsSource(
    'ParaAnaliz',
    'https://www.paraanaliz.com/feed/',
    'tr',
    'MACRO',
  ),
  // Genel ekonomi haberleri (Atom format)
  NewsSource(
    'NTV Ekonomi',
    'https://www.ntv.com.tr/ekonomi.rss',
    'tr',
    'MACRO',
    isAtom: true,
  ),
];

class RssNewsService {
  final Dio _dio;

  RssNewsService({Dio? dio})
      : _dio = dio ??
            Dio(BaseOptions(
              connectTimeout: AppConfig.connectTimeout,
              receiveTimeout: AppConfig.readTimeout,
              headers: {
                'User-Agent': 'Mozilla/5.0 (compatible; BorsaAnaliz/1.0)',
              },
            ));

  Future<List<NewsItem>> fetchFromSource(NewsSource source) async {
    try {
      final response = await _dio.get(source.url);
      if (response.statusCode != 200) return [];

      final xml = XmlDocument.parse(response.data as String);

      if (source.isAtom) {
        return _parseAtom(xml, source);
      } else {
        return _parseRss(xml, source);
      }
    } catch (e) {
      debugPrint('[RssNewsService] ${source.name} hatasi: $e');
      return [];
    }
  }

  /// RSS 2.0 formatini parse et (<item> taglari)
  List<NewsItem> _parseRss(XmlDocument xml, NewsSource source) {
    final items = <NewsItem>[];

    for (final item in xml.findAllElements('item')) {
      final title = item.getElement('title')?.innerText;
      if (title == null || title.isEmpty) continue;

      final description = item.getElement('description')?.innerText;
      final pubDateStr = item.getElement('pubDate')?.innerText;
      final link = item.getElement('link')?.innerText;

      DateTime pubDate;
      if (pubDateStr != null) {
        pubDate = _parseDate(pubDateStr) ?? DateTime.now();
      } else {
        pubDate = DateTime.now();
      }

      items.add(NewsItem(
        title: _cleanHtml(title),
        description: description != null ? _cleanHtml(description) : null,
        pubDate: pubDate,
        source: source.name,
        language: source.language,
        category: source.category,
        link: link,
      ));
    }

    return items;
  }

  /// Atom formatini parse et (<entry> taglari)
  List<NewsItem> _parseAtom(XmlDocument xml, NewsSource source) {
    final items = <NewsItem>[];

    for (final entry in xml.findAllElements('entry')) {
      final title = entry.getElement('title')?.innerText;
      if (title == null || title.isEmpty) continue;

      final summary = entry.getElement('summary')?.innerText ??
          entry.getElement('content')?.innerText;

      // Atom uses <updated> or <published> for date
      final dateStr = entry.getElement('published')?.innerText ??
          entry.getElement('updated')?.innerText;

      // Atom uses <link href="..."/> attribute
      String? link;
      final linkEl = entry.getElement('link');
      if (linkEl != null) {
        link = linkEl.getAttribute('href') ?? linkEl.innerText;
      }

      DateTime pubDate;
      if (dateStr != null) {
        pubDate = _parseDate(dateStr) ?? DateTime.now();
      } else {
        pubDate = DateTime.now();
      }

      items.add(NewsItem(
        title: _cleanHtml(title),
        description: summary != null ? _cleanHtml(summary) : null,
        pubDate: pubDate,
        source: source.name,
        language: source.language,
        category: source.category,
        link: link,
      ));
    }

    return items;
  }

  Future<List<NewsItem>> fetchAll({
    List<NewsSource>? sources,
  }) async {
    final srcs = sources ?? defaultNewsSources;
    final allNews = <NewsItem>[];
    final cutoff = DateTime.now()
        .subtract(Duration(hours: AppConfig.newsMaxAgeHours));

    for (final source in srcs) {
      final items = await fetchFromSource(source);
      allNews.addAll(items.where((item) => item.pubDate.isAfter(cutoff)));
      await Future.delayed(
          Duration(milliseconds: AppConfig.newsSourceDelayMs));
    }

    allNews.sort((a, b) => b.pubDate.compareTo(a.pubDate));
    return allNews;
  }

  String _cleanHtml(String text) {
    return text
        .replaceAll(RegExp(r'<[^>]*>'), '')
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&nbsp;', ' ')
        .trim();
  }

  /// Hem ISO 8601 hem RFC 822 tarih formatlarini parse eder
  DateTime? _parseDate(String dateStr) {
    // ISO 8601 (Atom format: 2026-04-07T09:30:00Z)
    try {
      return DateTime.parse(dateStr);
    } catch (_) {}

    // RFC 822 (RSS format: Mon, 07 Apr 2026 09:30:00 +0300)
    try {
      return _parseRfc822(dateStr);
    } catch (_) {}

    return null;
  }

  DateTime? _parseRfc822(String dateStr) {
    final months = {
      'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
      'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12,
    };

    final cleaned = dateStr.contains(',')
        ? dateStr.substring(dateStr.indexOf(',') + 1).trim()
        : dateStr.trim();

    final parts = cleaned.split(RegExp(r'\s+'));
    if (parts.length < 4) return null;

    final day = int.tryParse(parts[0]);
    final month = months[parts[1]];
    final year = int.tryParse(parts[2]);
    final timeParts = parts[3].split(':');

    if (day == null || month == null || year == null || timeParts.length < 2) {
      return null;
    }

    return DateTime(
      year,
      month,
      day,
      int.tryParse(timeParts[0]) ?? 0,
      int.tryParse(timeParts[1]) ?? 0,
      timeParts.length > 2 ? (int.tryParse(timeParts[2]) ?? 0) : 0,
    );
  }
}

/// Izolat uyumlu top-level fonksiyon (background service icin)
Future<List<NewsItem>> fetchAllRssNews() async {
  final service = RssNewsService();
  return service.fetchAll();
}
