import 'package:dio/dio.dart';
import '../../config/app_config.dart';
import '../models/daily_price.dart';

class YahooFinanceApi {
  final Dio _dio;
  String? lastError;

  static const int _maxRetries = 2;

  // Interval -> max range mapping for Yahoo Finance
  static const Map<String, String> intervalRanges = {
    '15m': '5d',
    '60m': '1mo',
    '1d': '3mo',
  };

  YahooFinanceApi()
      : _dio = Dio(BaseOptions(
          baseUrl: AppConfig.yahooBaseUrl,
          connectTimeout: AppConfig.connectTimeout,
          receiveTimeout: AppConfig.readTimeout,
        ));

  Future<List<DailyPrice>> fetchDailyPrices(String ticker, int stockId,
      {String range = '1y'}) async {
    return fetchPrices(ticker, stockId, interval: '1d', range: range);
  }

  Future<List<DailyPrice>> fetchPrices(String ticker, int stockId,
      {String interval = '1d', String? range}) async {
    lastError = null;
    final effectiveRange = range ?? intervalRanges[interval] ?? '3mo';

    for (int attempt = 0; attempt < _maxRetries; attempt++) {
      try {
        // Emtia ve endeks ticker'lari zaten Yahoo formatinda (GC=F, XU100.IS vb.)
        // .IS suffix sadece BIST hisselerine eklenir
        final yahooTicker = ticker.contains('=') || ticker.contains('.')
            ? ticker
            : '$ticker${AppConfig.yahooTickerSuffix}';
        final response = await _dio.get(
          '/v8/finance/chart/$yahooTicker',
          queryParameters: {
            'range': effectiveRange,
            'interval': interval,
          },
        );

        final data = response.data;
        final chart = data['chart'];
        if (chart == null) {
          lastError = '$ticker: Veri bulunamadi';
          return [];
        }

        final results = chart['result'] as List?;
        if (results == null || results.isEmpty) {
          lastError = '$ticker: Sonuc bos';
          return [];
        }

        final result = results[0];
        final timestamps =
            (result['timestamp'] as List?)?.cast<int>() ?? [];
        final indicators = result['indicators'];
        final quote = indicators?['quote']?[0];
        if (quote == null || timestamps.isEmpty) {
          lastError = '$ticker: Fiyat verisi eksik';
          return [];
        }

        final opens = (quote['open'] as List?) ?? [];
        final highs = (quote['high'] as List?) ?? [];
        final lows = (quote['low'] as List?) ?? [];
        final closes = (quote['close'] as List?) ?? [];
        final volumes = (quote['volume'] as List?) ?? [];

        final prices = <DailyPrice>[];
        for (int i = 0; i < timestamps.length; i++) {
          final o = opens.length > i ? opens[i] : null;
          final h = highs.length > i ? highs[i] : null;
          final l = lows.length > i ? lows[i] : null;
          final c = closes.length > i ? closes[i] : null;
          final v = volumes.length > i ? volumes[i] : null;

          if (o == null || h == null || l == null || c == null) continue;

          prices.add(DailyPrice(
            stockId: stockId,
            date: timestamps[i] * 1000,
            open: (o as num).toDouble(),
            high: (h as num).toDouble(),
            low: (l as num).toDouble(),
            close: (c as num).toDouble(),
            volume: (v as num?)?.toInt() ?? 0,
          ));
        }
        return prices;
      } on DioException catch (e) {
        final statusCode = e.response?.statusCode;
        // 404 = hisse Yahoo'da yok, retry anlamsiz
        if (statusCode == 404) {
          lastError = '$ticker: Yahoo\'da bulunamadi (404)';
          return [];
        }
        if (statusCode == 429) {
          lastError = '$ticker: Rate limit asildi, bekleniyor...';
          await Future.delayed(Duration(seconds: (attempt + 1) * 3));
          continue;
        }
        // 4xx hatalari (400, 403 vs.) retry anlamsiz
        if (statusCode != null && statusCode >= 400 && statusCode < 500) {
          lastError = '$ticker: HTTP $statusCode hatasi';
          return [];
        }
        if (e.type == DioExceptionType.connectionTimeout ||
            e.type == DioExceptionType.receiveTimeout) {
          lastError = '$ticker: Baglanti zaman asimi';
          if (attempt < _maxRetries - 1) {
            await Future.delayed(const Duration(seconds: 1));
            continue;
          }
        }
        if (e.type == DioExceptionType.connectionError) {
          lastError = '$ticker: Internet baglantisi yok';
          return [];
        }
        lastError = '$ticker: Ag hatasi - ${e.message}';
        if (attempt < _maxRetries - 1) {
          await Future.delayed(const Duration(seconds: 1));
          continue;
        }
      } catch (e) {
        lastError = '$ticker: Beklenmeyen hata - $e';
        return [];
      }
    }

    return [];
  }
}
