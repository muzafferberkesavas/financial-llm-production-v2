import 'package:flutter/foundation.dart';
import '../models/kap_disclosure.dart';
import '../../config/app_config.dart';

class KapService {
  /// Belirtilen hisse sembolleri icin son 24 saatin KAP bildirimlerini ceker.
  ///
  /// TODO: KAP API endpoint'i arastirilip implement edilecek.
  /// Secenekler:
  /// 1. kap.org.tr dahili API (Network sekmesinden XHR izle)
  /// 2. kap.org.tr/en Ingilizce sayfa scraping
  /// 3. Ucuncu parti kaynaklar (pykap, kap-notifier referans)
  Future<List<KapDisclosure>> fetchDisclosures({
    List<String>? tickers,
    int maxAgeHours = 24,
  }) async {
    // Stub: pipeline hazir, KAP verisi ileride eklenecek
    debugPrint('[KapService] Stub — KAP API henuz implement edilmedi');
    return [];
  }

  /// Bildirimleri oncelik sirasina gore filtreler.
  /// Sadece HIGH ve MEDIUM oncelikli bildirimleri dondurur.
  static List<KapDisclosure> filterByPriority(List<KapDisclosure> disclosures) {
    return disclosures
        .where((d) => d.priority == 'HIGH' || d.priority == 'MEDIUM')
        .toList();
  }

  /// Belirli bir ticker icin bildirimleri filtreler.
  static List<KapDisclosure> filterByTicker(
    List<KapDisclosure> disclosures,
    String ticker,
  ) {
    return disclosures.where((d) => d.ticker == ticker).toList();
  }
}

/// Izolat uyumlu top-level fonksiyon
Future<List<KapDisclosure>> fetchKapDisclosures({
  List<String>? tickers,
  int maxAgeHours = AppConfig.newsMaxAgeHours,
}) async {
  final service = KapService();
  return service.fetchDisclosures(
    tickers: tickers,
    maxAgeHours: maxAgeHours,
  );
}
