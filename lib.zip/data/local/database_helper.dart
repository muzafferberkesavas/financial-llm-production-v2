import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._();
  static Database? _database;

  DatabaseHelper._();

  Future<Database> get database async {
    if (_database == null) {
      _database = await _initDB();
      // Migration sonrasi kolon kontrolu
      await _ensureColumns(_database!);
    }
    return _database!;
  }

  Future<Database> _initDB() async {
    final path = join(await getDatabasesPath(), 'borsa_analiz.db');
    return openDatabase(path, version: 6, onCreate: _createDB, onUpgrade: _upgradeDB);
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE stocks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticker TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        sector TEXT,
        is_active INTEGER NOT NULL DEFAULT 0,
        is_in_portfolio INTEGER NOT NULL DEFAULT 0,
        last_updated INTEGER,
        portfolio_since INTEGER
      )
    ''');

    await db.execute('''
      CREATE TABLE daily_prices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        stock_id INTEGER NOT NULL,
        date INTEGER NOT NULL,
        open_price REAL NOT NULL,
        high REAL NOT NULL,
        low REAL NOT NULL,
        close REAL NOT NULL,
        volume INTEGER NOT NULL,
        FOREIGN KEY (stock_id) REFERENCES stocks(id),
        UNIQUE(stock_id, date)
      )
    ''');

    await db.execute('''
      CREATE TABLE indicators (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        stock_id INTEGER NOT NULL,
        date INTEGER NOT NULL,
        rsi REAL, macd REAL, macd_signal REAL, macd_histogram REAL,
        bb_upper REAL, bb_middle REAL, bb_lower REAL, bb_percent_b REAL,
        obv REAL, sma5 REAL, sma20 REAL, sma50 REAL, sma200 REAL,
        ema12 REAL, ema26 REAL, atr REAL, technical_score REAL,
        adx REAL, plus_di REAL, minus_di REAL,
        FOREIGN KEY (stock_id) REFERENCES stocks(id),
        UNIQUE(stock_id, date)
      )
    ''');

    await db.execute('''
      CREATE TABLE analysis_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        datetime INTEGER NOT NULL,
        analysis_type TEXT NOT NULL,
        stock_count INTEGER NOT NULL,
        prompt_text TEXT,
        response_text TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE ai_analyses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        stock_id INTEGER NOT NULL,
        datetime INTEGER NOT NULL,
        analysis_type TEXT NOT NULL,
        summary TEXT NOT NULL,
        signal TEXT NOT NULL,
        confidence REAL NOT NULL,
        risk_reward TEXT,
        scenario_status TEXT,
        raw_response TEXT,
        session_id INTEGER,
        intraday_notes TEXT,
        FOREIGN KEY (stock_id) REFERENCES stocks(id),
        FOREIGN KEY (session_id) REFERENCES analysis_sessions(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        stock_id INTEGER NOT NULL,
        datetime INTEGER NOT NULL,
        type TEXT NOT NULL,
        price REAL NOT NULL,
        quantity INTEGER NOT NULL,
        trigger_source TEXT,
        FOREIGN KEY (stock_id) REFERENCES stocks(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE fibonacci_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        stock_id INTEGER NOT NULL UNIQUE,
        swing_high_price REAL NOT NULL,
        swing_high_date INTEGER NOT NULL,
        swing_low_price REAL NOT NULL,
        swing_low_date INTEGER NOT NULL,
        level_236 REAL NOT NULL,
        level_382 REAL NOT NULL,
        level_500 REAL NOT NULL,
        level_618 REAL NOT NULL,
        level_786 REAL NOT NULL,
        renewal_countdown INTEGER NOT NULL,
        last_calculated INTEGER NOT NULL,
        is_downtrend INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (stock_id) REFERENCES stocks(id)
      )
    ''');

    await db.execute(
        'CREATE INDEX idx_daily_prices_stock ON daily_prices(stock_id, date DESC)');
    await db.execute(
        'CREATE INDEX idx_indicators_stock ON indicators(stock_id, date DESC)');
    await db.execute(
        'CREATE INDEX idx_ai_analyses_stock ON ai_analyses(stock_id, datetime DESC)');
    await db.execute(
        'CREATE INDEX idx_ai_analyses_session ON ai_analyses(session_id)');
    await db.execute(
        'CREATE INDEX idx_transactions_stock ON transactions(stock_id, datetime DESC)');
  }

  Future<void> _upgradeDB(Database db, int oldVersion, int newVersion) async {
    debugPrint('[DB] Migration: v$oldVersion -> v$newVersion');
    if (oldVersion < 2) {
      await db.execute(
          'ALTER TABLE fibonacci_data ADD COLUMN is_downtrend INTEGER NOT NULL DEFAULT 0');
      debugPrint('[DB] v2: is_downtrend kolonu eklendi');
    }
    if (oldVersion < 3) {
      await db.execute(
          'ALTER TABLE stocks ADD COLUMN portfolio_since INTEGER');
      debugPrint('[DB] v3: portfolio_since kolonu eklendi');
    }
    if (oldVersion < 4) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS analysis_sessions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          datetime INTEGER NOT NULL,
          analysis_type TEXT NOT NULL,
          stock_count INTEGER NOT NULL,
          prompt_text TEXT,
          response_text TEXT
        )
      ''');
      await db.execute(
          'ALTER TABLE ai_analyses ADD COLUMN session_id INTEGER');
      await db.execute(
          'CREATE INDEX IF NOT EXISTS idx_ai_analyses_session ON ai_analyses(session_id)');
      debugPrint('[DB] v4: analysis_sessions tablosu + session_id kolonu eklendi');
    }
    if (oldVersion < 5) {
      await db.execute('ALTER TABLE indicators ADD COLUMN adx REAL');
      await db.execute('ALTER TABLE indicators ADD COLUMN plus_di REAL');
      await db.execute('ALTER TABLE indicators ADD COLUMN minus_di REAL');
      debugPrint('[DB] v5: ADX kolonlari eklendi');
    }
    if (oldVersion < 6) {
      await db.execute('ALTER TABLE ai_analyses ADD COLUMN intraday_notes TEXT');
      debugPrint('[DB] v6: intraday_notes kolonu eklendi');
    }
  }

  /// Kolon eksikse ALTER TABLE ile ekler (migration atlanmis olabilir)
  Future<void> _ensureColumns(Database db) async {
    try {
      final cols = await db.rawQuery('PRAGMA table_info(stocks)');
      final colNames = cols.map((c) => c['name'] as String).toSet();
      if (!colNames.contains('portfolio_since')) {
        await db.execute('ALTER TABLE stocks ADD COLUMN portfolio_since INTEGER');
        debugPrint('[DB] portfolio_since kolonu eksikti, eklendi');
      }
    } catch (e) {
      debugPrint('[DB] Kolon kontrol hatasi: $e');
    }

    try {
      final cols = await db.rawQuery('PRAGMA table_info(ai_analyses)');
      final colNames = cols.map((c) => c['name'] as String).toSet();
      if (!colNames.contains('session_id')) {
        await db.execute('ALTER TABLE ai_analyses ADD COLUMN session_id INTEGER');
        debugPrint('[DB] session_id kolonu eksikti, eklendi');
      }
      if (!colNames.contains('intraday_notes')) {
        await db.execute('ALTER TABLE ai_analyses ADD COLUMN intraday_notes TEXT');
        debugPrint('[DB] intraday_notes kolonu eksikti, eklendi');
      }
    } catch (e) {
      debugPrint('[DB] session_id kontrol hatasi: $e');
    }
  }
}
