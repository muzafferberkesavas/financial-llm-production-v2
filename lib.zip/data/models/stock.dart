class Stock {
  final int? id;
  final String ticker;
  final String name;
  final String? sector;
  final bool isActive;
  final bool isInPortfolio;
  final int? lastUpdated;
  final int? portfolioSince; // T+1 icin: portfoye eklenme zamani (ms)

  Stock({
    this.id,
    required this.ticker,
    required this.name,
    this.sector,
    this.isActive = false,
    this.isInPortfolio = false,
    this.lastUpdated,
    this.portfolioSince,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'ticker': ticker,
        'name': name,
        'sector': sector,
        'is_active': isActive ? 1 : 0,
        'is_in_portfolio': isInPortfolio ? 1 : 0,
        'last_updated': lastUpdated,
        'portfolio_since': portfolioSince,
      };

  factory Stock.fromMap(Map<String, dynamic> map) => Stock(
        id: map['id'] as int?,
        ticker: map['ticker'] as String,
        name: map['name'] as String,
        sector: map['sector'] as String?,
        isActive: (map['is_active'] as int?) == 1,
        isInPortfolio: (map['is_in_portfolio'] as int?) == 1,
        lastUpdated: map['last_updated'] as int?,
        portfolioSince: map['portfolio_since'] as int?,
      );

  /// T+1 kontrolu: bugun eklenen hisse yarin sabaha kadar satilamaz
  bool get isT1Locked {
    if (portfolioSince == null) return false;
    final addedDate = DateTime.fromMillisecondsSinceEpoch(portfolioSince!);
    final now = DateTime.now();
    final addedDay = DateTime(addedDate.year, addedDate.month, addedDate.day);
    final today = DateTime(now.year, now.month, now.day);
    return addedDay == today;
  }

  Stock copyWith({
    int? id,
    String? ticker,
    String? name,
    String? sector,
    bool? isActive,
    bool? isInPortfolio,
    int? lastUpdated,
    int? portfolioSince,
  }) =>
      Stock(
        id: id ?? this.id,
        ticker: ticker ?? this.ticker,
        name: name ?? this.name,
        sector: sector ?? this.sector,
        isActive: isActive ?? this.isActive,
        isInPortfolio: isInPortfolio ?? this.isInPortfolio,
        lastUpdated: lastUpdated ?? this.lastUpdated,
        portfolioSince: portfolioSince ?? this.portfolioSince,
      );
}
