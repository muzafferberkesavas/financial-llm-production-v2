class StockTransaction {
  final int? id;
  final int stockId;
  final int datetime;
  final String type;
  final double price;
  final int quantity;
  final String? triggerSource;

  StockTransaction({
    this.id,
    required this.stockId,
    required this.datetime,
    required this.type,
    required this.price,
    required this.quantity,
    this.triggerSource,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'stock_id': stockId,
        'datetime': datetime,
        'type': type,
        'price': price,
        'quantity': quantity,
        'trigger_source': triggerSource,
      };

  factory StockTransaction.fromMap(Map<String, dynamic> map) => StockTransaction(
        id: map['id'] as int?,
        stockId: map['stock_id'] as int,
        datetime: map['datetime'] as int,
        type: map['type'] as String,
        price: (map['price'] as num).toDouble(),
        quantity: map['quantity'] as int,
        triggerSource: map['trigger_source'] as String?,
      );
}
