class AiAnalysis {
  final int? id;
  final int stockId;
  final int datetime;
  final String analysisType;
  final String summary;
  final String signal;
  final double confidence;
  final String? riskReward;
  final String? scenarioStatus;
  final String? rawResponse;
  final int? sessionId;
  final String? intradayNotes;

  AiAnalysis({
    this.id,
    required this.stockId,
    required this.datetime,
    required this.analysisType,
    required this.summary,
    required this.signal,
    required this.confidence,
    this.riskReward,
    this.scenarioStatus,
    this.rawResponse,
    this.sessionId,
    this.intradayNotes,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'stock_id': stockId,
        'datetime': datetime,
        'analysis_type': analysisType,
        'summary': summary,
        'signal': signal,
        'confidence': confidence,
        'risk_reward': riskReward,
        'scenario_status': scenarioStatus,
        'raw_response': rawResponse,
        'session_id': sessionId,
        'intraday_notes': intradayNotes,
      };

  factory AiAnalysis.fromMap(Map<String, dynamic> map) => AiAnalysis(
        id: map['id'] as int?,
        stockId: map['stock_id'] as int,
        datetime: map['datetime'] as int,
        analysisType: map['analysis_type'] as String,
        summary: map['summary'] as String,
        signal: map['signal'] as String,
        confidence: (map['confidence'] as num).toDouble(),
        riskReward: map['risk_reward'] as String?,
        scenarioStatus: map['scenario_status'] as String?,
        rawResponse: map['raw_response'] as String?,
        sessionId: map['session_id'] as int?,
        intradayNotes: map['intraday_notes'] as String?,
      );
}
