import '../../config/app_config.dart';

class MarketAgenda {
  final String formattedAgenda;
  final DateTime fetchTime;
  final int kapCount;
  final int rssCount;

  MarketAgenda({
    required this.formattedAgenda,
    required this.fetchTime,
    this.kapCount = 0,
    this.rssCount = 0,
  });

  int get totalItems => kapCount + rssCount;

  bool get isStale =>
      DateTime.now().difference(fetchTime).inMinutes >=
      AppConfig.agendaCacheMinutes;
}
