class FibonacciData {
  final int? id;
  final int stockId;
  final double swingHighPrice;
  final int swingHighDate;
  final double swingLowPrice;
  final int swingLowDate;
  final double level236;
  final double level382;
  final double level500;
  final double level618;
  final double level786;
  final int renewalCountdown;
  final int lastCalculated;
  final bool isDowntrend; // true: high önce geldi (düşüş retracement), false: low önce (yükseliş retracement)

  FibonacciData({
    this.id,
    required this.stockId,
    required this.swingHighPrice,
    required this.swingHighDate,
    required this.swingLowPrice,
    required this.swingLowDate,
    required this.level236,
    required this.level382,
    required this.level500,
    required this.level618,
    required this.level786,
    required this.renewalCountdown,
    required this.lastCalculated,
    this.isDowntrend = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'stock_id': stockId,
        'swing_high_price': swingHighPrice,
        'swing_high_date': swingHighDate,
        'swing_low_price': swingLowPrice,
        'swing_low_date': swingLowDate,
        'level_236': level236,
        'level_382': level382,
        'level_500': level500,
        'level_618': level618,
        'level_786': level786,
        'renewal_countdown': renewalCountdown,
        'last_calculated': lastCalculated,
        'is_downtrend': isDowntrend ? 1 : 0,
      };

  factory FibonacciData.fromMap(Map<String, dynamic> map) => FibonacciData(
        id: map['id'] as int?,
        stockId: map['stock_id'] as int,
        swingHighPrice: (map['swing_high_price'] as num).toDouble(),
        swingHighDate: map['swing_high_date'] as int,
        swingLowPrice: (map['swing_low_price'] as num).toDouble(),
        swingLowDate: map['swing_low_date'] as int,
        level236: (map['level_236'] as num).toDouble(),
        level382: (map['level_382'] as num).toDouble(),
        level500: (map['level_500'] as num).toDouble(),
        level618: (map['level_618'] as num).toDouble(),
        level786: (map['level_786'] as num).toDouble(),
        renewalCountdown: map['renewal_countdown'] as int,
        lastCalculated: map['last_calculated'] as int,
        isDowntrend: (map['is_downtrend'] as int?) == 1,
      );
}
