class NewsItem {
  final String title;
  final String? description;
  final DateTime pubDate;
  final String source;
  final String language; // 'tr' or 'en'
  final String? category; // MACRO, SECTOR, STOCK, GEOPOLITICAL
  final String? link;
  final String? relatedTicker;

  NewsItem({
    required this.title,
    this.description,
    required this.pubDate,
    required this.source,
    required this.language,
    this.category,
    this.link,
    this.relatedTicker,
  });
}
