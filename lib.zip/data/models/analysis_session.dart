class AnalysisSession {
  final int? id;
  final int datetime;
  final String analysisType; // GUNLUK / SAATLIK
  final int stockCount;
  final String? promptText;
  final String? responseText;

  AnalysisSession({
    this.id,
    required this.datetime,
    required this.analysisType,
    required this.stockCount,
    this.promptText,
    this.responseText,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'datetime': datetime,
        'analysis_type': analysisType,
        'stock_count': stockCount,
        'prompt_text': promptText,
        'response_text': responseText,
      };

  factory AnalysisSession.fromMap(Map<String, dynamic> map) => AnalysisSession(
        id: map['id'] as int?,
        datetime: map['datetime'] as int,
        analysisType: map['analysis_type'] as String,
        stockCount: map['stock_count'] as int,
        promptText: map['prompt_text'] as String?,
        responseText: map['response_text'] as String?,
      );
}
