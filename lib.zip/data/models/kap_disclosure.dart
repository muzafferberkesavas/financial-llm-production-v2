class KapDisclosure {
  final String ticker;
  final String companyName;
  final DateTime publishDate;
  final String title;
  final String? titleEn;
  final String type; // MATERIAL_EVENT, FINANCIAL_STATEMENT, DIVIDEND, etc.
  final String? summary;
  final String? url;
  final String priority; // HIGH, MEDIUM, LOW

  KapDisclosure({
    required this.ticker,
    required this.companyName,
    required this.publishDate,
    required this.title,
    this.titleEn,
    required this.type,
    this.summary,
    this.url,
    required this.priority,
  });

  /// KAP bildirim tipine gore oncelik belirle
  static String priorityForType(String type) {
    switch (type.toUpperCase()) {
      case 'MATERIAL_EVENT':
      case 'FINANCIAL_STATEMENT':
      case 'DIVIDEND':
      case 'SHARE_BUYBACK':
      case 'BOARD_DECISION':
      case 'MERGER_ACQUISITION':
        return 'HIGH';
      case 'GENERAL_ASSEMBLY':
      case 'CREDIT_RATING':
      case 'SIGNIFICANT_CONTRACT':
        return 'MEDIUM';
      default:
        return 'LOW';
    }
  }
}
