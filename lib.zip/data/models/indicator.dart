class Indicator {
  final int? id;
  final int stockId;
  final int date;
  final double? rsi;
  final double? macd;
  final double? macdSignal;
  final double? macdHistogram;
  final double? bbUpper;
  final double? bbMiddle;
  final double? bbLower;
  final double? bbPercentB;
  final double? obv;
  final double? sma5;
  final double? sma20;
  final double? sma50;
  final double? sma200;
  final double? ema12;
  final double? ema26;
  final double? atr;
  final double? technicalScore;
  final double? adx;
  final double? plusDi;
  final double? minusDi;

  Indicator({
    this.id,
    required this.stockId,
    required this.date,
    this.rsi,
    this.macd,
    this.macdSignal,
    this.macdHistogram,
    this.bbUpper,
    this.bbMiddle,
    this.bbLower,
    this.bbPercentB,
    this.obv,
    this.sma5,
    this.sma20,
    this.sma50,
    this.sma200,
    this.ema12,
    this.ema26,
    this.atr,
    this.technicalScore,
    this.adx,
    this.plusDi,
    this.minusDi,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'stock_id': stockId,
        'date': date,
        'rsi': rsi,
        'macd': macd,
        'macd_signal': macdSignal,
        'macd_histogram': macdHistogram,
        'bb_upper': bbUpper,
        'bb_middle': bbMiddle,
        'bb_lower': bbLower,
        'bb_percent_b': bbPercentB,
        'obv': obv,
        'sma5': sma5,
        'sma20': sma20,
        'sma50': sma50,
        'sma200': sma200,
        'ema12': ema12,
        'ema26': ema26,
        'atr': atr,
        'technical_score': technicalScore,
        'adx': adx,
        'plus_di': plusDi,
        'minus_di': minusDi,
      };

  factory Indicator.fromMap(Map<String, dynamic> map) => Indicator(
        id: map['id'] as int?,
        stockId: map['stock_id'] as int,
        date: map['date'] as int,
        rsi: (map['rsi'] as num?)?.toDouble(),
        macd: (map['macd'] as num?)?.toDouble(),
        macdSignal: (map['macd_signal'] as num?)?.toDouble(),
        macdHistogram: (map['macd_histogram'] as num?)?.toDouble(),
        bbUpper: (map['bb_upper'] as num?)?.toDouble(),
        bbMiddle: (map['bb_middle'] as num?)?.toDouble(),
        bbLower: (map['bb_lower'] as num?)?.toDouble(),
        bbPercentB: (map['bb_percent_b'] as num?)?.toDouble(),
        obv: (map['obv'] as num?)?.toDouble(),
        sma5: (map['sma5'] as num?)?.toDouble(),
        sma20: (map['sma20'] as num?)?.toDouble(),
        sma50: (map['sma50'] as num?)?.toDouble(),
        sma200: (map['sma200'] as num?)?.toDouble(),
        ema12: (map['ema12'] as num?)?.toDouble(),
        ema26: (map['ema26'] as num?)?.toDouble(),
        atr: (map['atr'] as num?)?.toDouble(),
        technicalScore: (map['technical_score'] as num?)?.toDouble(),
        adx: (map['adx'] as num?)?.toDouble(),
        plusDi: (map['plus_di'] as num?)?.toDouble(),
        minusDi: (map['minus_di'] as num?)?.toDouble(),
      );
}
