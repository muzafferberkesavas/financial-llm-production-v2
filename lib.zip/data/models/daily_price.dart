class DailyPrice {
  final int? id;
  final int stockId;
  final int date;
  final double open;
  final double high;
  final double low;
  final double close;
  final int volume;

  DailyPrice({
    this.id,
    required this.stockId,
    required this.date,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'stock_id': stockId,
        'date': date,
        'open_price': open,
        'high': high,
        'low': low,
        'close': close,
        'volume': volume,
      };

  factory DailyPrice.fromMap(Map<String, dynamic> map) => DailyPrice(
        id: map['id'] as int?,
        stockId: map['stock_id'] as int,
        date: map['date'] as int,
        open: (map['open_price'] as num).toDouble(),
        high: (map['high'] as num).toDouble(),
        low: (map['low'] as num).toDouble(),
        close: (map['close'] as num).toDouble(),
        volume: map['volume'] as int,
      );
}
