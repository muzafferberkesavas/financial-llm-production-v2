import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _controller = TextEditingController();
  bool _obscure = true;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // API Key Section
        const Text('Gemini API Ayarlari',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      state.hasApiKey ? Icons.check_circle : Icons.error,
                      color: state.hasApiKey ? Colors.green : Colors.red,
                    ),
                    const SizedBox(width: 8),
                    Text(state.hasApiKey
                        ? 'API Key kayitli'
                        : 'API Key girilmedi'),
                  ],
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _controller,
                  obscureText: _obscure,
                  decoration: InputDecoration(
                    labelText: 'Gemini API Key',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: Icon(
                          _obscure ? Icons.visibility : Icons.visibility_off),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    ElevatedButton.icon(
                      onPressed: () {
                        if (_controller.text.trim().isNotEmpty) {
                          state.saveApiKey(_controller.text.trim());
                          _controller.clear();
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text(
                                    'API Key kaydedildi - Ilk AI analizi baslatiliyor...')),
                          );
                        }
                      },
                      icon: const Icon(Icons.save),
                      label: const Text('Kaydet'),
                    ),
                    const SizedBox(width: 12),
                    if (state.hasApiKey)
                      OutlinedButton.icon(
                        onPressed: () {
                          state.clearApiKey();
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('API Key silindi')),
                          );
                        },
                        icon: const Icon(Icons.delete),
                        label: const Text('Sil'),
                        style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.red),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 24),

        // Status Section
        const Text('Durum',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _statusRow(
                  'Baglanti',
                  state.isOnline ? 'Cevrimici' : 'Cevrimdisi',
                  state.isOnline ? Icons.wifi : Icons.wifi_off,
                  state.isOnline ? Colors.green : Colors.red,
                ),
                const Divider(),
                _statusRow(
                  'Son Guncelleme',
                  state.lastUpdatedTime ?? 'Henuz guncellenmedi',
                  Icons.access_time,
                  Colors.grey,
                ),
                const Divider(),
                _statusRow(
                  'Otomatik Yenileme',
                  'Piyasa saatlerinde her saat',
                  Icons.autorenew,
                  Colors.blue,
                ),
                const Divider(),
                _statusRow(
                  'Toplam Hisse',
                  '${state.allStocks.length}',
                  Icons.bar_chart,
                  Colors.indigo,
                ),
                const Divider(),
                _statusRow(
                  'Aktif Hisse',
                  '${state.activeStocks.length}',
                  Icons.trending_up,
                  Colors.green,
                ),
                const Divider(),
                _statusRow(
                  'Portfoy',
                  '${state.portfolioStocks.length} hisse',
                  Icons.star,
                  Colors.amber,
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 24),

        // About Section
        const Text('Hakkinda',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Borsa Analiz v1.0.0',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                const Text(
                    'BIST-100 teknik analiz ve AI destekli sinyal uygulamasi'),
                const SizedBox(height: 12),
                const Text('Ozellikler:',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                _featureItem('15+ teknik indikator (RSI, MACD, BB, SMA, EMA, ATR, OBV)'),
                _featureItem('Fibonacci geri cekilme seviyeleri'),
                _featureItem('Google Gemini AI ile sinyal uretimi'),
                _featureItem('Gercek mum grafigi (candlestick)'),
                _featureItem('Otomatik veri yenileme (piyasa saatleri)'),
                _featureItem('Bildirim destegi (al/sat sinyalleri)'),
                _featureItem('Islem kaydi ve portfoy takibi'),
                const SizedBox(height: 12),
                const Text(
                    'Gemini API Key Google AI Studio\'dan ucretsiz alinabilir.',
                    style: TextStyle(color: Colors.grey, fontSize: 13)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _statusRow(String label, String value, IconData icon, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(width: 12),
          Text(label),
          const Spacer(),
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _featureItem(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 8, bottom: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('- ', style: TextStyle(color: Colors.grey)),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 13))),
        ],
      ),
    );
  }
}
