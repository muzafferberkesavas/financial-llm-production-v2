import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../config/app_config.dart';
import '../../data/models/ai_analysis.dart';
import '../../data/models/analysis_session.dart';
import '../providers/app_state.dart';
import 'detail_screen.dart';

class AnalysesScreen extends StatefulWidget {
  const AnalysesScreen({super.key});

  @override
  State<AnalysesScreen> createState() => _AnalysesScreenState();
}

class _AnalysesScreenState extends State<AnalysesScreen> {
  final Set<int> _expandedSessions = {};

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final sessions = state.recentSessions;

    if (sessions.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.auto_awesome, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            const Text('Henuz AI analizi yok',
                style: TextStyle(fontSize: 18, color: Colors.grey)),
            const SizedBox(height: 8),
            const Text(
              'Gemini API key girildiginde ve veri\nguncellendiginde analizler burada gozukecek.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: state.isLoading
                  ? null
                  : () => state.runManualAnalysis(),
              icon: const Icon(Icons.auto_awesome),
              label: const Text('Simdi Analiz Et'),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        // Header bar
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            children: [
              Text('${sessions.length} analiz oturumu',
                  style: const TextStyle(color: Colors.grey, fontSize: 13)),
              const SizedBox(width: 8),
              SizedBox(
                height: 32,
                child: IconButton(
                  onPressed: () => _confirmClearAnalyses(context, state),
                  icon: const Icon(Icons.delete_sweep, size: 20),
                  tooltip: 'Eski analizleri temizle',
                  padding: EdgeInsets.zero,
                  visualDensity: VisualDensity.compact,
                  color: Colors.grey,
                ),
              ),
              const Spacer(),
              if (state.lastUpdatedTime != null)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: Text('Son: ${state.lastUpdatedTime}',
                      style:
                          const TextStyle(color: Colors.grey, fontSize: 11)),
                ),
              SizedBox(
                height: 32,
                child: ElevatedButton.icon(
                  onPressed: state.isLoading
                      ? null
                      : () => state.runManualAnalysis(),
                  icon: const Icon(Icons.auto_awesome, size: 16),
                  label: const Text('Analiz Et', style: TextStyle(fontSize: 12)),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                  ),
                ),
              ),
            ],
          ),
        ),
        // Session list
        Expanded(
          child: ListView.builder(
            itemCount: sessions.length,
            itemBuilder: (context, index) {
              final session = sessions[index];
              final isExpanded = _expandedSessions.contains(session.id);
              return _SessionCard(
                session: session,
                isExpanded: isExpanded,
                onToggle: () {
                  setState(() {
                    if (isExpanded) {
                      _expandedSessions.remove(session.id);
                    } else {
                      _expandedSessions.add(session.id!);
                    }
                  });
                },
              );
            },
          ),
        ),
      ],
    );
  }

  void _confirmClearAnalyses(BuildContext context, AppState state) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Analizleri Temizle'),
        content: const Text(
          'Bugunun gunluk analizi haric tum oturumlar silinecek. Devam edilsin mi?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Iptal'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final deleted = await state.clearOldAnalyses();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('$deleted oturum silindi')),
                );
              }
            },
            child: const Text('Temizle',
                style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}

/// Bugunun GUNLUK oturumu piyasa acikken silinemez
bool _isDailySessionLocked(AnalysisSession session) {
  if (session.analysisType != 'GUNLUK') return false;
  final now = DateTime.now();
  final sessionDate = DateTime.fromMillisecondsSinceEpoch(session.datetime);
  // Sadece bugunun sabah analizi korunur
  if (sessionDate.year != now.year ||
      sessionDate.month != now.month ||
      sessionDate.day != now.day) {
    return false;
  }
  // Hafta ici ve piyasa kapanmadan once (18:10) ise kilitli
  if (now.weekday >= 6) return false; // Cumartesi/Pazar kilitlenmez
  final marketClose = DateTime(now.year, now.month, now.day,
      AppConfig.marketCloseHour, AppConfig.marketCloseMinute);
  return now.isBefore(marketClose);
}

/// Tek bir analiz oturumu karti
class _SessionCard extends StatelessWidget {
  final AnalysisSession session;
  final bool isExpanded;
  final VoidCallback onToggle;

  const _SessionCard({
    required this.session,
    required this.isExpanded,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    final date = DateTime.fromMillisecondsSinceEpoch(session.datetime);
    final isDaily = session.analysisType == 'GUNLUK';
    final borderColor = isDaily
        ? Colors.teal.withValues(alpha: 0.4)
        : Colors.indigo.withValues(alpha: 0.3);
    final bgColor = isDaily
        ? Colors.teal.withValues(alpha: 0.06)
        : Colors.indigo.withValues(alpha: 0.03);
    final typeLabel = isDaily ? 'Sabah Analizi' : 'Gun Ici Analiz';
    final typeColor = isDaily ? Colors.teal : Colors.indigo.shade300;

    final isEmpty = session.stockCount == 0;
    final isLocked = _isDailySessionLocked(session);

    return Dismissible(
      key: ValueKey('session_${session.id}'),
      direction: isLocked ? DismissDirection.none : DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.red.shade700,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      confirmDismiss: (_) async {
        return await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Oturumu Sil'),
            content: const Text(
                'Bu analiz oturumu ve icerisindeki tum hisse analizleri silinecek.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Iptal'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Sil',
                    style: TextStyle(color: Colors.red)),
              ),
            ],
          ),
        );
      },
      onDismissed: (_) {
        state.deleteSession(session.id!);
      },
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        color: isEmpty ? Colors.grey.withValues(alpha: 0.05) : bgColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
              color: isEmpty
                  ? Colors.grey.withValues(alpha: 0.3)
                  : borderColor),
        ),
        child: Column(
          children: [
            // Collapsed header - always visible
            InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: isEmpty ? null : onToggle,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Row 1: Type badge + time + expand icon
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: typeColor.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            typeLabel,
                            style: TextStyle(
                              color: typeColor,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          isEmpty
                              ? 'Bos yanit'
                              : '${session.stockCount} hisse',
                          style: TextStyle(
                              color: isEmpty ? Colors.red : Colors.grey,
                              fontSize: 12),
                        ),
                        if (isEmpty && !isLocked) ...[
                          const SizedBox(width: 8),
                          const Text('← sola kaydir sil',
                              style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 10,
                                  fontStyle: FontStyle.italic)),
                        ],
                        if (isLocked) ...[
                          const SizedBox(width: 6),
                          Icon(Icons.lock_outline,
                              size: 14, color: Colors.teal.shade300),
                        ],
                        const Spacer(),
                        Text(
                          _formatDateTime(date),
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 11),
                        ),
                        if (!isEmpty) ...[
                          const SizedBox(width: 4),
                          Icon(
                            isExpanded
                                ? Icons.keyboard_arrow_up
                                : Icons.keyboard_arrow_down,
                            color: Colors.grey,
                            size: 20,
                          ),
                        ],
                      ],
                    ),
                    // Row 2: Top 3 preview (only when collapsed and not empty)
                    if (!isExpanded && !isEmpty) ...[
                      const SizedBox(height: 10),
                      _TopStocksPreview(sessionId: session.id!),
                    ],
                  ],
                ),
              ),
            ),
            // Expanded content
            if (isExpanded && !isEmpty) ...[
              const Divider(height: 1),
              _ExpandedSessionContent(
                session: session,
                state: state,
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _formatDateTime(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final dateDay = DateTime(date.year, date.month, date.day);
    final timeStr = DateFormat('HH:mm').format(date);

    if (dateDay == today) {
      return 'Bugun $timeStr';
    } else if (dateDay == yesterday) {
      return 'Dun $timeStr';
    } else {
      return DateFormat('dd.MM.yyyy HH:mm').format(date);
    }
  }
}

/// Collapsed durumdaki top 3 hisse preview
class _TopStocksPreview extends StatefulWidget {
  final int sessionId;

  const _TopStocksPreview({required this.sessionId});

  @override
  State<_TopStocksPreview> createState() => _TopStocksPreviewState();
}

class _TopStocksPreviewState extends State<_TopStocksPreview> {
  List<AiAnalysis>? _analyses;

  @override
  void initState() {
    super.initState();
    _loadAnalyses();
  }

  Future<void> _loadAnalyses() async {
    final state = context.read<AppState>();
    final analyses = await state.getAnalysesForSession(widget.sessionId);
    if (mounted) {
      setState(() => _analyses = analyses);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();

    if (_analyses == null) {
      return const SizedBox(
        height: 20,
        child: Center(
          child: SizedBox(
            width: 14,
            height: 14,
            child: CircularProgressIndicator(strokeWidth: 1.5),
          ),
        ),
      );
    }

    if (_analyses!.isEmpty) {
      return const Text('Sonuc yok',
          style: TextStyle(color: Colors.grey, fontSize: 12));
    }

    // Top 3 by confidence
    final top3 = _analyses!.take(3).toList();
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      children: top3.map((a) {
        final displayName = state.getDisplayName(a.stockId);
        final signalColor = _signalColor(a.signal);
        final conf = (a.confidence * 100).toStringAsFixed(0);
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: signalColor.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: signalColor.withValues(alpha: 0.3)),
          ),
          child: Text(
            '$displayName ${a.signal.replaceAll("_", " ")} %$conf',
            style: TextStyle(
              fontSize: 11,
              color: signalColor,
              fontWeight: FontWeight.w600,
            ),
          ),
        );
      }).toList(),
    );
  }
}

/// Expanded session content: tum hisseler + prompt butonu
class _ExpandedSessionContent extends StatefulWidget {
  final AnalysisSession session;
  final AppState state;

  const _ExpandedSessionContent({
    required this.session,
    required this.state,
  });

  @override
  State<_ExpandedSessionContent> createState() =>
      _ExpandedSessionContentState();
}

class _ExpandedSessionContentState extends State<_ExpandedSessionContent> {
  List<AiAnalysis>? _analyses;

  @override
  void initState() {
    super.initState();
    _loadAnalyses();
  }

  Future<void> _loadAnalyses() async {
    final analyses =
        await widget.state.getAnalysesForSession(widget.session.id!);
    if (mounted) {
      setState(() => _analyses = analyses);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_analyses == null) {
      return const Padding(
        padding: EdgeInsets.all(20),
        child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }

    if (_analyses!.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Text('Bu oturumda sonuc yok.',
            style: TextStyle(color: Colors.grey)),
      );
    }

    return Column(
      children: [
        // Stock analyses sorted by confidence
        ..._analyses!.map((a) => _buildStockRow(context, a)),
        // Action buttons
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 12),
          child: Row(
            children: [
              // Prompt/Response görüntüle butonu
              TextButton.icon(
                onPressed: () => _showPromptResponse(context),
                icon: const Icon(Icons.code, size: 16),
                label: const Text('Prompt & Yanit',
                    style: TextStyle(fontSize: 12)),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  visualDensity: VisualDensity.compact,
                ),
              ),
              const Spacer(),
              // Session sil butonu (kilitliyse gosterme)
              if (!_isDailySessionLocked(widget.session))
                TextButton.icon(
                  onPressed: () => _confirmDeleteSession(context),
                  icon: const Icon(Icons.delete_outline,
                      size: 16, color: Colors.red),
                  label: const Text('Sil',
                      style: TextStyle(fontSize: 12, color: Colors.red)),
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    visualDensity: VisualDensity.compact,
                  ),
                )
              else
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.lock_outline,
                        size: 14, color: Colors.teal.shade300),
                    const SizedBox(width: 4),
                    Text('Piyasa kapaninca silinebilir',
                        style: TextStyle(
                            fontSize: 11, color: Colors.teal.shade300)),
                  ],
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStockRow(BuildContext context, AiAnalysis analysis) {
    final ticker = widget.state.getDisplayName(analysis.stockId);
    final signalColor = _signalColor(analysis.signal);
    final conf = (analysis.confidence * 100).toStringAsFixed(0);

    return InkWell(
      onTap: () => _showAnalysisDetail(context, analysis),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        child: Row(
          children: [
            // Ticker / Emtia ismi
            SizedBox(
              width: 85,
              child: Text(
                ticker,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 14),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            // Signal badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: signalColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                analysis.signal.replaceAll('_', ' '),
                style: TextStyle(
                  color: signalColor,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Confidence
            Text(
              '%$conf',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: analysis.confidence >= 0.7
                    ? Colors.green
                    : analysis.confidence >= 0.5
                        ? Colors.orange
                        : Colors.grey,
              ),
            ),
            const SizedBox(width: 10),
            // Summary preview
            Expanded(
              child: Text(
                analysis.summary,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ),
            const Icon(Icons.chevron_right, size: 16, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  void _showAnalysisDetail(BuildContext context, AiAnalysis analysis) {
    final ticker = widget.state.getDisplayName(analysis.stockId);
    final date = DateTime.fromMillisecondsSinceEpoch(analysis.datetime);
    final timeStr = DateFormat('dd.MM.yyyy HH:mm').format(date);
    final signalColor = _signalColor(analysis.signal);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.65,
        minChildSize: 0.3,
        maxChildSize: 0.92,
        expand: false,
        builder: (_, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Handle bar
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              // Header
              Row(
                children: [
                  Text(ticker,
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: signalColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      analysis.signal.replaceAll('_', ' '),
                      style: TextStyle(
                          color: signalColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 14),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  const Icon(Icons.access_time,
                      size: 14, color: Colors.grey),
                  const SizedBox(width: 4),
                  Text(timeStr,
                      style: const TextStyle(
                          color: Colors.grey, fontSize: 13)),
                  const SizedBox(width: 16),
                  const Icon(Icons.verified,
                      size: 14, color: Colors.grey),
                  const SizedBox(width: 4),
                  Text(
                    'Guven: %${(analysis.confidence * 100).toStringAsFixed(0)}',
                    style: TextStyle(
                        color: analysis.confidence >= 0.7
                            ? Colors.green
                            : Colors.orange,
                        fontSize: 13,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const Divider(height: 28),
              // Summary
              const Text('Ozet',
                  style: TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 8),
              Text(analysis.summary,
                  style: const TextStyle(fontSize: 14, height: 1.4)),
              // Risk/Reward
              if (analysis.riskReward != null &&
                  analysis.riskReward!.isNotEmpty) ...[
                const SizedBox(height: 20),
                const Text('Risk / Odul',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),
                Text(analysis.riskReward!,
                    style: const TextStyle(fontSize: 14, height: 1.4)),
              ],
              // Scenario
              if (analysis.scenarioStatus != null &&
                  analysis.scenarioStatus!.isNotEmpty) ...[
                const SizedBox(height: 20),
                const Text('Senaryo Durumu',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),
                Text(analysis.scenarioStatus!,
                    style: const TextStyle(fontSize: 14, height: 1.4)),
              ],
              // Go to stock detail
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () {
                    Navigator.pop(ctx);
                    widget.state.loadStockDetail(analysis.stockId);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            DetailScreen(stockId: analysis.stockId),
                      ),
                    );
                  },
                  icon: const Icon(Icons.candlestick_chart),
                  label: Text('$ticker Detayina Git'),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  void _showPromptResponse(BuildContext context) async {
    final session = await widget.state.getSession(widget.session.id!);
    if (session == null || !context.mounted) return;

    final hasPrompt =
        session.promptText != null && session.promptText!.isNotEmpty;
    final hasResponse =
        session.responseText != null && session.responseText!.isNotEmpty;

    if (!hasPrompt && !hasResponse) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Bu oturum icin prompt/yanit kaydedilmemis.')),
      );
      return;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => DefaultTabController(
        length: 2,
        child: DraggableScrollableSheet(
          initialChildSize: 0.8,
          minChildSize: 0.3,
          maxChildSize: 0.95,
          expand: false,
          builder: (_, scrollController) => Column(
            children: [
              // Handle bar
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(top: 12, bottom: 8),
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const TabBar(
                tabs: [
                  Tab(text: 'Prompt (Gonderilen)'),
                  Tab(text: 'Yanit (Gemini)'),
                ],
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    // Prompt tab
                    _buildCopyableTab(
                      ctx,
                      scrollController,
                      session.promptText ?? 'Prompt kaydedilmemis.',
                      'Prompt',
                    ),
                    // Response tab
                    _buildCopyableTab(
                      ctx,
                      null,
                      session.responseText ?? 'Yanit kaydedilmemis.',
                      'Yanit',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmDeleteSession(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Oturumu Sil'),
        content: const Text(
            'Bu analiz oturumu ve icerisindeki tum hisse analizleri silinecek.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Iptal'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              widget.state.deleteSession(widget.session.id!);
            },
            child:
                const Text('Sil', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Widget _buildCopyableTab(
    BuildContext context,
    ScrollController? scrollController,
    String text,
    String label,
  ) {
    return Column(
      children: [
        // Kopyala butonu
        Padding(
          padding: const EdgeInsets.only(top: 8, right: 16, left: 16),
          child: Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: text));
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('$label panoya kopyalandi'),
                    duration: const Duration(seconds: 2),
                  ),
                );
              },
              icon: const Icon(Icons.copy, size: 16),
              label: Text('$label Kopyala'),
              style: TextButton.styleFrom(
                visualDensity: VisualDensity.compact,
              ),
            ),
          ),
        ),
        // Icerik
        Expanded(
          child: SingleChildScrollView(
            controller: scrollController,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SelectableText(
              text,
              style: const TextStyle(
                fontSize: 12,
                fontFamily: 'monospace',
                height: 1.4,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

Color _signalColor(String signal) {
  switch (signal) {
    case 'GUCLU_AL':
      return Colors.green.shade700;
    case 'AL':
      return Colors.green;
    case 'IZLE':
      return Colors.blue;
    case 'TUT':
      return Colors.orange;
    case 'KISMI_SAT':
      return Colors.orange.shade700;
    case 'SAT':
      return Colors.red;
    case 'GUCLU_SAT':
      return Colors.red.shade700;
    case 'ACIL_SAT':
      return Colors.red.shade900;
    default:
      return Colors.grey;
  }
}
