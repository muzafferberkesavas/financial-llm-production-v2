import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../config/app_config.dart';
import '../providers/app_state.dart';
import '../widgets/signal_badge.dart';
import '../widgets/sparkline_widget.dart';
import 'detail_screen.dart';

class PortfolioScreen extends StatelessWidget {
  const PortfolioScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final stocks = state.portfolioStocks;

    if (stocks.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.account_balance_wallet,
                size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            const Text('Portfoyde hisse yok',
                style: TextStyle(fontSize: 18, color: Colors.grey)),
            const SizedBox(height: 8),
            const Text(
              'AI analizi calistirdiginizda en iyi 3 hisse\notomatik olarak portfoye eklenecek.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: state.isLoading
                  ? null
                  : () => state.runManualAnalysis(),
              icon: const Icon(Icons.auto_awesome),
              label: const Text('Analiz Et'),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Text(
                  '${stocks.length}/${AppConfig.maxPortfolioStocks} hisse',
                  style: const TextStyle(color: Colors.grey, fontSize: 13)),
              const SizedBox(width: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.blue.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.auto_awesome, size: 12, color: Colors.blue),
                    SizedBox(width: 4),
                    Text('AI Yonetimli',
                        style: TextStyle(
                            color: Colors.blue,
                            fontSize: 11,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: stocks.length,
            itemBuilder: (context, index) {
              final stock = stocks[index];
              final summary = state.stockSummaries[stock.id];
              return _buildPortfolioCard(context, state, stock, summary);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildPortfolioCard(
      BuildContext context, AppState state, stock, StockSummary? summary) {
    final hasData = summary != null;
    final isUp = hasData && summary.changePercent >= 0;
    final isLocked = stock.isT1Locked;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: isLocked
            ? BorderSide(color: Colors.orange.withValues(alpha: 0.4))
            : BorderSide.none,
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          state.loadStockDetail(stock.id!);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => DetailScreen(stockId: stock.id!),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              // Left: Ticker + name + signal + T+1 badge
              Expanded(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(stock.ticker,
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 15)),
                        if (isLocked) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 1),
                            decoration: BoxDecoration(
                              color: Colors.orange.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text('T+1',
                                style: TextStyle(
                                    color: Colors.orange,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${stock.name} - ${stock.sector ?? ""}',
                      style:
                          const TextStyle(color: Colors.grey, fontSize: 11),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (summary?.signal != null) ...[
                      const SizedBox(height: 4),
                      SignalBadge(signal: summary!.signal!),
                    ],
                  ],
                ),
              ),

              // Middle: Sparkline
              if (hasData && summary.sparkline.length >= 2)
                Expanded(
                  flex: 2,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: SizedBox(
                      height: 32,
                      child: SparklineWidget(
                        data: summary.sparkline,
                        color: isUp ? Colors.green : Colors.red,
                      ),
                    ),
                  ),
                ),

              // Right: Price + change
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (hasData) ...[
                    Text(
                      '${summary.price.toStringAsFixed(2)} TL',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                    const SizedBox(height: 2),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: isUp
                            ? Colors.green.withValues(alpha: 0.15)
                            : Colors.red.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        '${isUp ? "+" : ""}${summary.changePercent.toStringAsFixed(2)}%',
                        style: TextStyle(
                          color: isUp ? Colors.green : Colors.red,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                  if (summary?.confidence != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      'Guven: %${(summary!.confidence! * 100).toStringAsFixed(0)}',
                      style: TextStyle(
                        fontSize: 10,
                        color: summary.confidence! >= 0.7
                            ? Colors.green
                            : Colors.orange,
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
