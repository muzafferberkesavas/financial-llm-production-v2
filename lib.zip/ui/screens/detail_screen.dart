import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../providers/app_state.dart';
import '../widgets/signal_badge.dart';
import '../../data/models/daily_price.dart';
import '../../data/models/indicator.dart';
import '../../data/models/fibonacci.dart';
import 'transaction_screen.dart';

class DetailScreen extends StatefulWidget {
  final int stockId;
  const DetailScreen({super.key, required this.stockId});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  bool showBollinger = false;
  bool showRsi = false;
  bool showMacd = false;
  bool showFibonacci = true;
  bool showVolume = true;
  bool showObv = false;

  // Zoom & Pan state
  int _visibleStart = 0;
  int _visibleEnd = 0;
  int _totalDataLength = 0;
  double _baseScaleSpan = 0; // span at start of pinch

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final stock = state.selectedStock;
    final prices = state.selectedStockPrices;
    final chartPrices = state.chartPrices;
    final indicators = state.selectedStockIndicators;
    final analyses = state.selectedStockAnalyses;
    final fibonacci = state.selectedStockFibonacci;

    final latestPrice = prices.isNotEmpty ? prices.first : null;
    final prevPrice = prices.length > 1 ? prices[1] : null;
    final changePercent =
        (latestPrice != null && prevPrice != null && prevPrice.close != 0)
            ? ((latestPrice.close - prevPrice.close) / prevPrice.close) * 100
            : null;

    return Scaffold(
      appBar: AppBar(
        title: Text(stock?.sector == 'Emtia' ? stock!.name : (stock?.ticker ?? 'Detay')),
        actions: [
          if (stock != null)
            IconButton(
              icon: const Icon(Icons.receipt_long),
              tooltip: 'Islemler',
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => TransactionScreen(
                    stockId: stock.id!,
                    ticker: stock.ticker,
                  ),
                ),
              ),
            ),
          if (stock != null && stock.isInPortfolio)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Chip(
                avatar: const Icon(Icons.star, color: Colors.amber, size: 16),
                label: Text(
                  stock.isT1Locked ? 'Portfoy (T+1)' : 'Portfoy',
                  style: const TextStyle(fontSize: 12),
                ),
                visualDensity: VisualDensity.compact,
              ),
            ),
        ],
      ),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(12),
              children: [
                // Price card
                _buildPriceCard(latestPrice, changePercent),
                const SizedBox(height: 8),

                // Interval selector
                _buildIntervalSelector(state),
                const SizedBox(height: 8),

                // Candlestick chart + Volume
                if (chartPrices.length > 3) ...[
                  if (state.isLoadingChart)
                    const SizedBox(
                      height: 300,
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else ...[
                    Builder(builder: (context) {
                      final allPrices = chartPrices.reversed.toList();
                      final allIndicators = state.selectedInterval == '1d'
                          ? indicators.reversed.toList()
                          : <Indicator>[];

                      // Initialize visible range
                      if (_totalDataLength != allPrices.length) {
                        _totalDataLength = allPrices.length;
                        _visibleStart = max(0, allPrices.length - 60);
                        _visibleEnd = allPrices.length;
                      }

                      final visiblePrices = allPrices.sublist(
                        _visibleStart.clamp(0, allPrices.length),
                        _visibleEnd.clamp(0, allPrices.length),
                      );

                      // Slice indicators to match visible range
                      List<Indicator> visibleIndicators = [];
                      if (allIndicators.isNotEmpty) {
                        final indOffset = allPrices.length - allIndicators.length;
                        final indStart = max(0, _visibleStart - indOffset);
                        final indEnd = max(0, _visibleEnd - indOffset);
                        if (indStart < allIndicators.length && indEnd > 0) {
                          visibleIndicators = allIndicators.sublist(
                            indStart.clamp(0, allIndicators.length),
                            indEnd.clamp(0, allIndicators.length),
                          );
                        }
                      }

                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(left: 8, bottom: 4),
                                child: Row(
                                  children: [
                                    Text(
                                      _intervalLabel(state.selectedInterval),
                                      style: const TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.grey),
                                    ),
                                    const Spacer(),
                                    // Zoom controls
                                    GestureDetector(
                                      onTap: () => _zoomIn(allPrices.length),
                                      child: const Icon(Icons.zoom_in, size: 20, color: Colors.grey),
                                    ),
                                    const SizedBox(width: 12),
                                    GestureDetector(
                                      onTap: () => _zoomOut(allPrices.length),
                                      child: const Icon(Icons.zoom_out, size: 20, color: Colors.grey),
                                    ),
                                    const SizedBox(width: 12),
                                    GestureDetector(
                                      onTap: () => setState(() {
                                        _visibleStart = 0;
                                        _visibleEnd = allPrices.length;
                                      }),
                                      child: const Icon(Icons.fit_screen, size: 20, color: Colors.grey),
                                    ),
                                  ],
                                ),
                              ),
                              GestureDetector(
                                onScaleStart: (details) {
                                  _baseScaleSpan = (_visibleEnd - _visibleStart).toDouble();
                                },
                                onScaleUpdate: (details) {
                                  setState(() {
                                    if (details.pointerCount >= 2) {
                                      // Pinch zoom
                                      final newSpan = (_baseScaleSpan / details.scale)
                                          .round()
                                          .clamp(10, allPrices.length);
                                      final center = (_visibleStart + _visibleEnd) ~/ 2;
                                      _visibleStart = (center - newSpan ~/ 2).clamp(0, allPrices.length - 10);
                                      _visibleEnd = (_visibleStart + newSpan).clamp(10, allPrices.length);
                                      _visibleStart = _visibleEnd - newSpan.clamp(10, allPrices.length);
                                    } else {
                                      // Pan (single finger drag)
                                      final chartWidth = MediaQuery.of(context).size.width - 80;
                                      final span = _visibleEnd - _visibleStart;
                                      final pixelsPerBar = chartWidth / span;
                                      final barDelta = -(details.focalPointDelta.dx / pixelsPerBar).round();
                                      if (barDelta != 0) {
                                        final newStart = (_visibleStart + barDelta).clamp(0, allPrices.length - span);
                                        _visibleStart = newStart;
                                        _visibleEnd = newStart + span;
                                      }
                                    }
                                  });
                                },
                                child: SizedBox(
                                  height: 280,
                                  child: _buildCandlestickChart(
                                    visiblePrices,
                                    visibleIndicators,
                                    fibonacci,
                                    state.selectedInterval,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),

                    // Volume chart (synced with zoom)
                    if (showVolume)
                      Builder(builder: (context) {
                        final allVols = chartPrices.reversed.toList();
                        final volStart = _visibleStart.clamp(0, allVols.length);
                        final volEnd = _visibleEnd.clamp(0, allVols.length);
                        final visibleVols = allVols.sublist(volStart, volEnd);
                        return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Padding(
                                padding: EdgeInsets.only(left: 8, bottom: 4),
                                child: Text('Hacim',
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.grey)),
                              ),
                              SizedBox(
                                height: 100,
                                child: _buildVolumeChart(
                                    visibleVols,
                                    state.selectedInterval),
                              ),
                            ],
                          ),
                        ),
                      );
                      }),
                  ],
                ] else if (chartPrices.isEmpty && !state.isLoadingChart)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Center(
                        child: Text('Bu aralik icin veri bulunamadi',
                            style: TextStyle(color: Colors.grey)),
                      ),
                    ),
                  ),

                const SizedBox(height: 4),

                // Indicator toggles
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: [
                    FilterChip(
                        label: const Text('Hacim'),
                        selected: showVolume,
                        onSelected: (v) => setState(() => showVolume = v)),
                    FilterChip(
                        label: const Text('BB'),
                        selected: showBollinger,
                        onSelected: (v) => setState(() => showBollinger = v)),
                    FilterChip(
                        label: const Text('RSI'),
                        selected: showRsi,
                        onSelected: (v) => setState(() => showRsi = v)),
                    FilterChip(
                        label: const Text('MACD'),
                        selected: showMacd,
                        onSelected: (v) => setState(() => showMacd = v)),
                    FilterChip(
                        label: const Text('OBV'),
                        selected: showObv,
                        onSelected: (v) => setState(() => showObv = v)),
                    FilterChip(
                        label: const Text('Fib'),
                        selected: showFibonacci,
                        onSelected: (v) => setState(() => showFibonacci = v)),
                  ],
                ),
                const SizedBox(height: 8),

                // RSI chart
                if (showRsi && indicators.isNotEmpty && state.selectedInterval == '1d')
                  _buildSubChart(
                    'RSI (14)',
                    150,
                    _buildRsiChart(indicators.reversed.toList()),
                  ),

                // MACD chart
                if (showMacd && indicators.isNotEmpty && state.selectedInterval == '1d')
                  _buildSubChart(
                    'MACD (12,26,9)',
                    150,
                    _buildMacdChart(indicators.reversed.toList()),
                  ),

                // OBV chart
                if (showObv && indicators.isNotEmpty && state.selectedInterval == '1d')
                  _buildSubChart(
                    'OBV',
                    120,
                    _buildObvChart(indicators.reversed.toList()),
                  ),

                const SizedBox(height: 8),

                // Technical indicators summary
                if (indicators.isNotEmpty) _buildIndicatorSummary(indicators.first),

                const SizedBox(height: 8),

                // AI analysis
                if (analyses.isNotEmpty) _buildAiAnalysisCard(analyses),

                // Transactions
                if (state.selectedStockTransactions.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.receipt_long),
                      title: Text(
                          '${state.selectedStockTransactions.length} islem kaydi'),
                      subtitle: const Text('Detaylar icin dokunun'),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {
                        if (stock != null) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => TransactionScreen(
                                stockId: stock.id!,
                                ticker: stock.ticker,
                              ),
                            ),
                          );
                        }
                      },
                    ),
                  ),
                ],
              ],
            ),
    );
  }

  // ─── Interval selector ───
  Widget _buildIntervalSelector(AppState state) {
    return Row(
      children: [
        _intervalButton(state, '15m', '15dk'),
        const SizedBox(width: 6),
        _intervalButton(state, '60m', '1 Saat'),
        const SizedBox(width: 6),
        _intervalButton(state, '1d', 'Gunluk'),
      ],
    );
  }

  Widget _intervalButton(AppState state, String interval, String label) {
    final isSelected = state.selectedInterval == interval;
    return Expanded(
      child: FilledButton.tonal(
        onPressed: state.isLoadingChart
            ? null
            : () => state.changeInterval(interval),
        style: FilledButton.styleFrom(
          backgroundColor: isSelected
              ? Theme.of(context).colorScheme.primary
              : Theme.of(context).colorScheme.surfaceContainerHighest,
          foregroundColor: isSelected
              ? Theme.of(context).colorScheme.onPrimary
              : Theme.of(context).colorScheme.onSurface,
          padding: const EdgeInsets.symmetric(vertical: 8),
        ),
        child: Text(label, style: const TextStyle(fontSize: 13)),
      ),
    );
  }

  void _zoomIn(int totalLength) {
    setState(() {
      final span = _visibleEnd - _visibleStart;
      final newSpan = (span * 0.7).round().clamp(10, totalLength);
      final center = (_visibleStart + _visibleEnd) ~/ 2;
      _visibleStart = (center - newSpan ~/ 2).clamp(0, totalLength - newSpan);
      _visibleEnd = _visibleStart + newSpan;
    });
  }

  void _zoomOut(int totalLength) {
    setState(() {
      final span = _visibleEnd - _visibleStart;
      final newSpan = (span * 1.4).round().clamp(10, totalLength);
      final center = (_visibleStart + _visibleEnd) ~/ 2;
      _visibleStart = (center - newSpan ~/ 2).clamp(0, totalLength - newSpan);
      _visibleEnd = (_visibleStart + newSpan).clamp(newSpan, totalLength);
      _visibleStart = _visibleEnd - newSpan;
    });
  }

  String _intervalLabel(String interval) {
    switch (interval) {
      case '15m':
        return '15 Dakikalik Mumlar (5 Gun)';
      case '60m':
        return 'Saatlik Mumlar (1 Ay)';
      default:
        return 'Gunluk Mumlar (3 Ay)';
    }
  }

  String _dateFormat(String interval) {
    switch (interval) {
      case '15m':
        return 'HH:mm';
      case '60m':
        return 'dd/MM HH:mm';
      default:
        return 'dd/MM';
    }
  }

  /// Chart icin hangi indekslerde tarih label'i gosterilecegini hesaplar.
  /// Veri miktarina gore ay basi veya hafta basi gosterir.
  Set<int> _calcLabelIndices(List<DailyPrice> prices, String interval) {
    if (prices.isEmpty) return {};
    final indices = <int>{};

    if (interval == '15m' || interval == '60m') {
      // Intraday: esit aralıklarla max 4 label
      final step = max(1, prices.length ~/ 4);
      for (int i = step; i < prices.length - 1; i += step) {
        indices.add(i);
      }
      return indices;
    }

    // Gunluk veri: ay degisimlerini bul
    int? lastMonth;
    int? lastWeek;
    for (int i = 0; i < prices.length; i++) {
      final date = DateTime.fromMillisecondsSinceEpoch(prices[i].date);
      if (lastMonth == null || date.month != lastMonth) {
        indices.add(i);
        lastMonth = date.month;
        lastWeek = _weekOfMonth(date);
      } else if (prices.length <= 90) {
        // 3 ay ve altinda hafta baslarini da goster
        final week = _weekOfMonth(date);
        if (week != lastWeek && date.weekday == DateTime.monday) {
          indices.add(i);
          lastWeek = week;
        }
      }
    }

    // Kenardakileri kaldir (cakisma onleme)
    indices.remove(0);
    if (prices.isNotEmpty) indices.remove(prices.length - 1);
    return indices;
  }

  int _weekOfMonth(DateTime date) => ((date.day - 1) ~/ 7) + 1;

  /// Veri miktarina gore uygun tarih formati
  String _smartDateLabel(DateTime date, int dataLength, String interval) {
    if (interval == '15m') return DateFormat('HH:mm').format(date);
    if (interval == '60m') return DateFormat('dd/MM HH:mm').format(date);

    const aylar = ['Oca','Sub','Mar','Nis','May','Haz','Tem','Agu','Eyl','Eki','Kas','Ara'];
    final ay = aylar[date.month - 1];

    if (dataLength > 90) {
      return ay;
    }
    final week = _weekOfMonth(date);
    return '$ay H$week';
  }

  Widget _buildBottomTitle(
      double value, List<DailyPrice> prices, Set<int> labelIndices, String interval) {
    final i = value.toInt();
    if (i < 0 || i >= prices.length || !labelIndices.contains(i)) {
      return const SizedBox();
    }
    final date = DateTime.fromMillisecondsSinceEpoch(prices[i].date);
    final text = _smartDateLabel(date, prices.length, interval);
    return Transform.rotate(
      angle: -0.7, // ~40 derece
      child: Text(text, style: const TextStyle(fontSize: 7, color: Colors.grey)),
    );
  }

  // ─── Price card ───
  Widget _buildPriceCard(DailyPrice? latestPrice, double? changePercent) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Son Fiyat',
                  style: TextStyle(color: Colors.grey, fontSize: 12)),
              Text(
                latestPrice != null
                    ? '${latestPrice.close.toStringAsFixed(2)} TL'
                    : '---',
                style:
                    const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              if (latestPrice != null)
                Text(
                  'A: ${latestPrice.open.toStringAsFixed(2)}  Y: ${latestPrice.high.toStringAsFixed(2)}  D: ${latestPrice.low.toStringAsFixed(2)}',
                  style: const TextStyle(color: Colors.grey, fontSize: 11),
                ),
            ]),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              if (changePercent != null)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: changePercent >= 0
                        ? Colors.green.withValues(alpha: 0.2)
                        : Colors.red.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '${changePercent >= 0 ? "+" : ""}${changePercent.toStringAsFixed(2)}%',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: changePercent >= 0 ? Colors.green : Colors.red,
                    ),
                  ),
                ),
              if (latestPrice != null)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    'Hacim: ${_formatVolume(latestPrice.volume)}',
                    style: const TextStyle(color: Colors.grey, fontSize: 11),
                  ),
                ),
            ]),
          ],
        ),
      ),
    );
  }

  // ─── Candlestick chart ───
  Widget _buildCandlestickChart(List<DailyPrice> prices,
      List<Indicator> indicators, FibonacciData? fibonacci, String interval) {
    final barGroups = <BarChartGroupData>[];
    var minY = double.infinity;
    var maxY = double.negativeInfinity;

    for (int i = 0; i < prices.length; i++) {
      final p = prices[i];
      if (p.low < minY) minY = p.low;
      if (p.high > maxY) maxY = p.high;

      final isUp = p.close >= p.open;
      final color = isUp ? Colors.green : Colors.red;
      final bodyTop = isUp ? p.close : p.open;
      final bodyBottom = isUp ? p.open : p.close;
      final bodyWidth = prices.length > 100 ? 2.0 : prices.length > 50 ? 3.0 : 5.0;

      barGroups.add(BarChartGroupData(x: i, barRods: [
        BarChartRodData(
          fromY: p.low, toY: p.high, width: 1,
          color: color, borderRadius: BorderRadius.zero,
          rodStackItems: [BarChartRodStackItem(bodyBottom, bodyTop, color)],
          backDrawRodData: BackgroundBarChartRodData(show: false),
        ),
        BarChartRodData(
          fromY: bodyBottom,
          toY: bodyTop == bodyBottom ? bodyTop + 0.01 : bodyTop,
          width: bodyWidth, color: color, borderRadius: BorderRadius.zero,
        ),
      ]));
    }

    if (showBollinger && indicators.isNotEmpty) {
      for (final ind in indicators) {
        if (ind.bbUpper != null && ind.bbUpper! > maxY) maxY = ind.bbUpper!;
        if (ind.bbLower != null && ind.bbLower! < minY) minY = ind.bbLower!;
      }
    }

    // Fibonacci seviyeleri - oncelik: chart range'i genislet
    final extraLines = <HorizontalLine>[];
    if (showFibonacci && fibonacci != null) {
      final fibLevels = [
        ('0%', fibonacci.swingLowPrice, Colors.green.shade700),
        ('23.6%', fibonacci.level236, Colors.pink),
        ('38.2%', fibonacci.level382, Colors.purple),
        ('50%', fibonacci.level500, Colors.blue),
        ('61.8%', fibonacci.level618, Colors.teal),
        ('78.6%', fibonacci.level786, Colors.orange),
        ('100%', fibonacci.swingHighPrice, Colors.red.shade700),
      ];
      for (final (_, level, _) in fibLevels) {
        if (level < minY) minY = level;
        if (level > maxY) maxY = level;
      }
    }

    final pad = (maxY - minY) * 0.05;
    minY -= pad;
    maxY += pad;

    if (showFibonacci && fibonacci != null) {
      final fibLevels = [
        ('0%', fibonacci.swingLowPrice, Colors.green.shade700),
        ('23.6%', fibonacci.level236, Colors.pink),
        ('38.2%', fibonacci.level382, Colors.purple),
        ('50%', fibonacci.level500, Colors.blue),
        ('61.8%', fibonacci.level618, Colors.teal),
        ('78.6%', fibonacci.level786, Colors.orange),
        ('100%', fibonacci.swingHighPrice, Colors.red.shade700),
      ];
      for (final (label, level, color) in fibLevels) {
        extraLines.add(HorizontalLine(
          y: level, color: color,
          strokeWidth: 1.0, dashArray: [4, 4],
          label: HorizontalLineLabel(
            show: true,
            alignment: Alignment.topRight,
            labelResolver: (_) => '$label ${level.toStringAsFixed(2)}',
            style: TextStyle(color: color, fontSize: 8),
          ),
        ));
      }
    }

    final labelIndices = _calcLabelIndices(prices, interval);

    return Stack(children: [
      BarChart(BarChartData(
        barGroups: barGroups, minY: minY, maxY: maxY,
        gridData: FlGridData(
          show: true, drawVerticalLine: false,
          getDrawingHorizontalLine: (v) =>
              FlLine(color: Colors.grey.withValues(alpha: 0.2), strokeWidth: 0.5),
        ),
        titlesData: FlTitlesData(
          leftTitles: AxisTitles(sideTitles: SideTitles(
            showTitles: true, reservedSize: 55,
            getTitlesWidget: (value, meta) => Padding(
              padding: const EdgeInsets.only(right: 4),
              child: Text(value.toStringAsFixed(1),
                  style: const TextStyle(fontSize: 9, color: Colors.grey)),
            ),
          )),
          bottomTitles: AxisTitles(sideTitles: SideTitles(
            showTitles: true, reservedSize: 30,
            interval: 1,
            getTitlesWidget: (value, meta) =>
                _buildBottomTitle(value, prices, labelIndices, interval),
          )),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        extraLinesData: ExtraLinesData(horizontalLines: extraLines),
        barTouchData: BarTouchData(
          touchTooltipData: BarTouchTooltipData(
            getTooltipItem: (group, gi, rod, ri) {
              if (ri != 1) return null;
              final p = prices[group.x.toInt()];
              final d = DateTime.fromMillisecondsSinceEpoch(p.date);
              return BarTooltipItem(
                '${DateFormat(_dateFormat(interval)).format(d)}\nA:${p.open.toStringAsFixed(2)} K:${p.close.toStringAsFixed(2)}\nY:${p.high.toStringAsFixed(2)} D:${p.low.toStringAsFixed(2)}\nH:${_formatVolume(p.volume)}',
                const TextStyle(color: Colors.white, fontSize: 10),
              );
            },
          ),
        ),
      )),
      if (showBollinger && indicators.isNotEmpty)
        Positioned.fill(
          child: IgnorePointer(
            child: CustomPaint(
              painter: _BollingerPainter(
                prices: prices, indicators: indicators,
                minY: minY, maxY: maxY, leftReserved: 55,
              ),
            ),
          ),
        ),
    ]);
  }

  // ─── Volume chart ───
  Widget _buildVolumeChart(List<DailyPrice> prices, String interval) {
    final maxVol = prices.map((p) => p.volume).reduce(max).toDouble();
    final volLabelIndices = _calcLabelIndices(prices, interval);

    final barGroups = prices.asMap().entries.map((e) {
      final i = e.key;
      final p = e.value;
      final isUp = p.close >= p.open;
      return BarChartGroupData(x: i, barRods: [
        BarChartRodData(
          fromY: 0, toY: p.volume.toDouble(),
          width: prices.length > 100 ? 1.5 : prices.length > 50 ? 2.5 : 4,
          color: isUp
              ? Colors.green.withValues(alpha: 0.6)
              : Colors.red.withValues(alpha: 0.6),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(1)),
        ),
      ]);
    }).toList();

    return BarChart(BarChartData(
      barGroups: barGroups, minY: 0, maxY: maxVol * 1.1,
      gridData: FlGridData(
        show: true, drawVerticalLine: false,
        getDrawingHorizontalLine: (v) =>
            FlLine(color: Colors.grey.withValues(alpha: 0.15), strokeWidth: 0.5),
      ),
      titlesData: FlTitlesData(
        leftTitles: AxisTitles(sideTitles: SideTitles(
          showTitles: true, reservedSize: 55,
          getTitlesWidget: (value, meta) => Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Text(_formatVolume(value.toInt()),
                style: const TextStyle(fontSize: 8, color: Colors.grey)),
          ),
        )),
        bottomTitles: AxisTitles(sideTitles: SideTitles(
          showTitles: true, reservedSize: 30,
          interval: 1,
          getTitlesWidget: (value, meta) =>
              _buildBottomTitle(value, prices, volLabelIndices, interval),
        )),
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      ),
      borderData: FlBorderData(show: false),
      barTouchData: BarTouchData(
        touchTooltipData: BarTouchTooltipData(
          getTooltipItem: (group, gi, rod, ri) {
            final p = prices[group.x.toInt()];
            return BarTooltipItem(
              'Hacim: ${_formatVolume(p.volume)}',
              const TextStyle(color: Colors.white, fontSize: 10),
            );
          },
        ),
      ),
    ));
  }

  // ─── Sub chart wrapper ───
  Widget _buildSubChart(String title, double height, Widget chart) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 8, bottom: 4),
              child: Text(title,
                  style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey)),
            ),
            SizedBox(height: height, child: chart),
          ],
        ),
      ),
    );
  }

  // ─── RSI chart ───
  Widget _buildRsiChart(List<Indicator> indicators) {
    final spots = <FlSpot>[];
    for (int i = 0; i < indicators.length; i++) {
      if (indicators[i].rsi != null) {
        spots.add(FlSpot(i.toDouble(), indicators[i].rsi!));
      }
    }

    return LineChart(LineChartData(
      minY: 0, maxY: 100,
      lineBarsData: [
        LineChartBarData(
            spots: spots, isCurved: false, color: Colors.purple,
            barWidth: 1.5, dotData: const FlDotData(show: false)),
      ],
      extraLinesData: ExtraLinesData(horizontalLines: [
        HorizontalLine(y: 70, color: Colors.red.withValues(alpha: 0.5),
            strokeWidth: 1, dashArray: [5, 5]),
        HorizontalLine(y: 30, color: Colors.green.withValues(alpha: 0.5),
            strokeWidth: 1, dashArray: [5, 5]),
      ]),
      gridData: FlGridData(show: true, drawVerticalLine: false),
      titlesData: const FlTitlesData(
        leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 30)),
        bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
      ),
      borderData: FlBorderData(show: false),
      lineTouchData: LineTouchData(
        touchTooltipData: LineTouchTooltipData(
          getTooltipItems: (spots) => spots
              .map((s) => LineTooltipItem(
                    'RSI: ${s.y.toStringAsFixed(1)}',
                    const TextStyle(color: Colors.white, fontSize: 11)))
              .toList(),
        ),
      ),
    ));
  }

  // ─── MACD chart ───
  Widget _buildMacdChart(List<Indicator> indicators) {
    final macdSpots = <FlSpot>[];
    final signalSpots = <FlSpot>[];

    for (int i = 0; i < indicators.length; i++) {
      if (indicators[i].macd != null) {
        macdSpots.add(FlSpot(i.toDouble(), indicators[i].macd!));
      }
      if (indicators[i].macdSignal != null) {
        signalSpots.add(FlSpot(i.toDouble(), indicators[i].macdSignal!));
      }
    }

    // Build histogram as bar-like line
    final histSpots = <FlSpot>[];
    for (int i = 0; i < indicators.length; i++) {
      if (indicators[i].macdHistogram != null) {
        histSpots.add(FlSpot(i.toDouble(), indicators[i].macdHistogram!));
      }
    }

    return LineChart(LineChartData(
      lineBarsData: [
        // Histogram as area
        if (histSpots.isNotEmpty)
          LineChartBarData(
            spots: histSpots, isCurved: false,
            color: Colors.grey.withValues(alpha: 0.4),
            barWidth: 0,
            dotData: const FlDotData(show: false),
            belowBarData: BarAreaData(
              show: true,
              color: Colors.green.withValues(alpha: 0.15),
              cutOffY: 0, applyCutOffY: true,
            ),
            aboveBarData: BarAreaData(
              show: true,
              color: Colors.red.withValues(alpha: 0.15),
              cutOffY: 0, applyCutOffY: true,
            ),
          ),
        LineChartBarData(
            spots: macdSpots, isCurved: false, color: Colors.blue,
            barWidth: 1.5, dotData: const FlDotData(show: false)),
        LineChartBarData(
            spots: signalSpots, isCurved: false, color: Colors.orange,
            barWidth: 1.5, dotData: const FlDotData(show: false)),
      ],
      gridData: FlGridData(show: true, drawVerticalLine: false),
      titlesData: const FlTitlesData(
        leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 40)),
        bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
      ),
      borderData: FlBorderData(show: false),
      extraLinesData: ExtraLinesData(horizontalLines: [
        HorizontalLine(y: 0, color: Colors.grey.withValues(alpha: 0.5), strokeWidth: 0.5),
      ]),
      lineTouchData: LineTouchData(
        touchTooltipData: LineTouchTooltipData(
          getTooltipItems: (spots) {
            if (spots.isEmpty) return [];
            final i = spots.first.x.toInt();
            if (i < 0 || i >= indicators.length) return [];
            final ind = indicators[i];
            return [
              LineTooltipItem(
                'MACD: ${ind.macd?.toStringAsFixed(2) ?? "-"}\nSinyal: ${ind.macdSignal?.toStringAsFixed(2) ?? "-"}\nHist: ${ind.macdHistogram?.toStringAsFixed(2) ?? "-"}',
                const TextStyle(color: Colors.white, fontSize: 10),
              ),
            ];
          },
        ),
      ),
    ));
  }

  // ─── OBV chart ───
  Widget _buildObvChart(List<Indicator> indicators) {
    final spots = <FlSpot>[];
    for (int i = 0; i < indicators.length; i++) {
      if (indicators[i].obv != null) {
        spots.add(FlSpot(i.toDouble(), indicators[i].obv!));
      }
    }
    if (spots.isEmpty) return const SizedBox();

    return LineChart(LineChartData(
      lineBarsData: [
        LineChartBarData(
          spots: spots, isCurved: false, color: Colors.cyan,
          barWidth: 1.5, dotData: const FlDotData(show: false),
          belowBarData: BarAreaData(
            show: true, color: Colors.cyan.withValues(alpha: 0.1),
          ),
        ),
      ],
      gridData: FlGridData(show: true, drawVerticalLine: false),
      titlesData: FlTitlesData(
        leftTitles: AxisTitles(sideTitles: SideTitles(
          showTitles: true, reservedSize: 55,
          getTitlesWidget: (value, meta) => Text(
            _formatVolume(value.toInt()),
            style: const TextStyle(fontSize: 8, color: Colors.grey),
          ),
        )),
        bottomTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      ),
      borderData: FlBorderData(show: false),
      lineTouchData: LineTouchData(
        touchTooltipData: LineTouchTooltipData(
          getTooltipItems: (spots) => spots
              .map((s) => LineTooltipItem(
                    'OBV: ${_formatVolume(s.y.toInt())}',
                    const TextStyle(color: Colors.white, fontSize: 11)))
              .toList(),
        ),
      ),
    ));
  }

  // ─── Indicator summary ───
  Widget _buildIndicatorSummary(Indicator ind) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Teknik Gostergeler',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _indicatorItem('RSI', ind.rsi?.toStringAsFixed(1),
                  color: _rsiColor(ind.rsi))),
              Expanded(child: _indicatorItem('MACD', ind.macd?.toStringAsFixed(2),
                  color: ind.macd != null ? (ind.macd! > 0 ? Colors.green : Colors.red) : null)),
              Expanded(child: _indicatorItem('ATR', ind.atr?.toStringAsFixed(2))),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: _indicatorItem('SMA20', ind.sma20?.toStringAsFixed(2))),
              Expanded(child: _indicatorItem('SMA50', ind.sma50?.toStringAsFixed(2))),
              Expanded(child: _indicatorItem('SMA200', ind.sma200?.toStringAsFixed(2))),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: _indicatorItem('BB Ust', ind.bbUpper?.toStringAsFixed(2))),
              Expanded(child: _indicatorItem('BB Alt', ind.bbLower?.toStringAsFixed(2))),
              Expanded(child: _indicatorItem('Skor', ind.technicalScore?.toStringAsFixed(0),
                  color: _scoreColor(ind.technicalScore))),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: _indicatorItem('EMA12', ind.ema12?.toStringAsFixed(2))),
              Expanded(child: _indicatorItem('EMA26', ind.ema26?.toStringAsFixed(2))),
              Expanded(child: _indicatorItem('OBV', ind.obv != null
                  ? _formatVolume(ind.obv!.toInt()) : null)),
            ]),
          ],
        ),
      ),
    );
  }

  // ─── AI Analysis card ───
  Widget _buildAiAnalysisCard(List analyses) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Gemini Analizi',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                SignalBadge(signal: analyses.first.signal),
              ],
            ),
            const SizedBox(height: 8),
            Text('Guven: ${(analyses.first.confidence * 100).toStringAsFixed(0)}%',
                style: const TextStyle(color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 4),
            Text(analyses.first.summary, style: const TextStyle(fontSize: 14, height: 1.5)),
            if (analyses.first.riskReward != null) ...[
              const SizedBox(height: 4),
              Text('Risk/Odul: ${analyses.first.riskReward}',
                  style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ],
            if (analyses.first.scenarioStatus != null) ...[
              const SizedBox(height: 4),
              Text('Senaryo: ${analyses.first.scenarioStatus}',
                  style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ],
            if (analyses.length > 1) ...[
              const SizedBox(height: 8),
              const Divider(),
              ExpansionTile(
                title: const Text('Onceki Analizler', style: TextStyle(fontSize: 14)),
                children: analyses.skip(1).take(5).map<Widget>((a) => ListTile(
                  dense: true,
                  title: Text(a.summary, maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text(DateFormat('dd.MM.yyyy HH:mm')
                      .format(DateTime.fromMillisecondsSinceEpoch(a.datetime))),
                  trailing: SignalBadge(signal: a.signal),
                )).toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ─── Helpers ───
  Widget _indicatorItem(String label, String? value, {Color? color}) {
    return Column(children: [
      Text(label, style: const TextStyle(color: Colors.grey, fontSize: 11)),
      const SizedBox(height: 2),
      Text(value ?? '-',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: color)),
    ]);
  }

  Color? _scoreColor(double? score) {
    if (score == null) return null;
    if (score >= 70) return Colors.green;
    if (score >= 50) return Colors.orange;
    return Colors.red;
  }

  Color? _rsiColor(double? rsi) {
    if (rsi == null) return null;
    if (rsi >= 70) return Colors.red;
    if (rsi <= 30) return Colors.green;
    return null;
  }

  String _formatVolume(int volume) {
    if (volume >= 1000000000) return '${(volume / 1000000000).toStringAsFixed(1)}B';
    if (volume >= 1000000) return '${(volume / 1000000).toStringAsFixed(1)}M';
    if (volume >= 1000) return '${(volume / 1000).toStringAsFixed(1)}K';
    return volume.toString();
  }
}

// ─── Bollinger CustomPaint overlay ───
class _BollingerPainter extends CustomPainter {
  final List<DailyPrice> prices;
  final List<Indicator> indicators;
  final double minY, maxY, leftReserved;

  _BollingerPainter({
    required this.prices, required this.indicators,
    required this.minY, required this.maxY, required this.leftReserved,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (indicators.isEmpty || prices.isEmpty) return;

    final paintUpper = Paint()..color = Colors.orange.withValues(alpha: 0.6)
      ..strokeWidth = 1.2..style = PaintingStyle.stroke;
    final paintLower = Paint()..color = Colors.orange.withValues(alpha: 0.6)
      ..strokeWidth = 1.2..style = PaintingStyle.stroke;
    final paintMiddle = Paint()..color = Colors.orange.withValues(alpha: 0.3)
      ..strokeWidth = 0.8..style = PaintingStyle.stroke;

    final chartWidth = size.width - leftReserved;
    final chartHeight = size.height - 22;
    final offset = prices.length - indicators.length;

    final upperPath = Path();
    final lowerPath = Path();
    final middlePath = Path();
    bool fU = true, fL = true, fM = true;

    for (int i = 0; i < indicators.length; i++) {
      final x = leftReserved +
          ((i + (offset > 0 ? offset : 0)) / (prices.length - 1)) * chartWidth;

      void addPoint(Path path, double? val, bool isFirst, Function(bool) setFirst) {
        if (val == null) return;
        final y = chartHeight - ((val - minY) / (maxY - minY)) * chartHeight;
        if (isFirst) { path.moveTo(x, y); setFirst(false); }
        else { path.lineTo(x, y); }
      }

      addPoint(upperPath, indicators[i].bbUpper, fU, (v) => fU = v);
      addPoint(lowerPath, indicators[i].bbLower, fL, (v) => fL = v);
      addPoint(middlePath, indicators[i].bbMiddle, fM, (v) => fM = v);
    }

    canvas.drawPath(upperPath, paintUpper);
    canvas.drawPath(lowerPath, paintLower);
    canvas.drawPath(middlePath, paintMiddle);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
