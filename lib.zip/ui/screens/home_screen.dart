import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/models/stock.dart';
import '../providers/app_state.dart';
import '../widgets/signal_badge.dart';
import '../widgets/sparkline_widget.dart';
import 'detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _searchQuery = '';
  String? _selectedSector;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    if (state.isLoading && state.progressMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(),
            if (state.progressMessage != null) ...[
              const SizedBox(height: 16),
              Text(state.progressMessage!,
                  style: const TextStyle(fontSize: 12, color: Colors.grey)),
              if (state.progressTotal > 0) ...[
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 48),
                  child: LinearProgressIndicator(
                    value: state.progressCurrent / state.progressTotal,
                  ),
                ),
              ],
            ],
          ],
        ),
      );
    }

    // Emtialar en uste, sonra aktif + portfoy hisseleri
    final baseStocksSet = <int>{};
    final baseStocks = <Stock>[];
    for (final s in [...state.commodityStocks, ...state.activeStocks, ...state.portfolioStocks]) {
      if (baseStocksSet.add(s.id!)) baseStocks.add(s);
    }

    // Apply search and filter
    final stocks = baseStocks.where((s) {
      final matchesSearch = _searchQuery.isEmpty ||
          s.ticker.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          s.name.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesSector =
          _selectedSector == null || s.sector == _selectedSector;
      return matchesSearch && matchesSector;
    }).toList();

    // Get unique sectors
    final sectors = baseStocks
        .map((s) => s.sector)
        .whereType<String>()
        .where((s) => s.isNotEmpty)
        .toSet()
        .toList()
      ..sort();

    if (baseStocks.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (state.isLoading) ...[
              const CircularProgressIndicator(),
              const SizedBox(height: 16),
              if (state.progressMessage != null) ...[
                Text(state.progressMessage!,
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
                if (state.progressTotal > 0) ...[
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 48),
                    child: LinearProgressIndicator(
                      value: state.progressCurrent / state.progressTotal,
                    ),
                  ),
                ],
              ],
            ] else ...[
              const Icon(Icons.trending_up, size: 64, color: Colors.grey),
              const SizedBox(height: 16),
              const Text('Henuz tarama yapilmadi',
                  style: TextStyle(fontSize: 18, color: Colors.grey)),
              const SizedBox(height: 8),
              const Text(
                  'Tum BIST hisselerinin fiyatlarini internetten ceker,\nindikatorleri hesaplar ve filtreyi uygular.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey, fontSize: 12)),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () => state.fetchAllData(),
                icon: const Icon(Icons.download),
                label: const Text('Tarama Baslat'),
              ),
            ],
          ],
        ),
      );
    }

    final hasError = state.lastError != null;

    return Column(
      children: [
        // Error banner
        if (hasError)
          MaterialBanner(
            content: Text(state.lastError!,
                style: const TextStyle(fontSize: 12)),
            backgroundColor: Colors.orange.withValues(alpha: 0.15),
            leading: const Icon(Icons.warning_amber, color: Colors.orange),
            actions: [
              TextButton(
                onPressed: () => state.clearError(),
                child: const Text('Kapat'),
              ),
            ],
          ),

        // Offline banner
        if (!state.isOnline)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
            color: Colors.red.withValues(alpha: 0.2),
            child: const Row(
              children: [
                Icon(Icons.wifi_off, size: 16, color: Colors.red),
                SizedBox(width: 8),
                Text('Cevrimdisi - Onbellekteki veriler gosteriliyor',
                    style: TextStyle(fontSize: 12, color: Colors.red)),
              ],
            ),
          ),

        // Search bar
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Hisse ara (ornek: THYAO, Turk Hava)',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12)),
              isDense: true,
              contentPadding: const EdgeInsets.symmetric(vertical: 10),
              suffixIcon: _searchQuery.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () => setState(() => _searchQuery = ''),
                    )
                  : null,
            ),
            onChanged: (v) => setState(() => _searchQuery = v),
          ),
        ),

        // Sector filter chips
        SizedBox(
          height: 40,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: FilterChip(
                  label: const Text('Tumu'),
                  selected: _selectedSector == null,
                  onSelected: (_) =>
                      setState(() => _selectedSector = null),
                ),
              ),
              ...sectors.map((sector) => Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: FilterChip(
                      label: Text(sector),
                      selected: _selectedSector == sector,
                      onSelected: (selected) => setState(() =>
                          _selectedSector = selected ? sector : null),
                    ),
                  )),
            ],
          ),
        ),

        // Stock count
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(
            children: [
              Text('${stocks.length} hisse',
                  style: const TextStyle(color: Colors.grey, fontSize: 12)),
              const Spacer(),
              if (state.lastUpdatedTime != null)
                Text(
                  'Son guncelleme: ${state.lastUpdatedTime}',
                  style: const TextStyle(color: Colors.grey, fontSize: 11),
                ),
            ],
          ),
        ),

        // Stock list
        Expanded(
          child: stocks.isEmpty
              ? const Center(
                  child: Text('Aramayla eslesen hisse bulunamadi',
                      style: TextStyle(color: Colors.grey)))
              : RefreshIndicator(
                  onRefresh: () => state.fetchAllData(),
                  child: ListView.builder(
                    itemCount: stocks.length,
                    itemBuilder: (context, index) {
                      final stock = stocks[index];
                      final summary = state.stockSummaries[stock.id];
                      return _buildStockCard(context, state, stock, summary);
                    },
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildStockCard(
      BuildContext context, AppState state, stock, StockSummary? summary) {
    final hasData = summary != null;
    final isUp = hasData && summary.changePercent >= 0;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          state.loadStockDetail(stock.id!);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => DetailScreen(stockId: stock.id!),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              // Left: Ticker + name
              Expanded(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(stock.sector == 'Emtia' ? stock.name : stock.ticker,
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 15)),
                        if (stock.isInPortfolio) ...[
                          const SizedBox(width: 4),
                          const Icon(Icons.star,
                              color: Colors.amber, size: 14),
                        ],
                      ],
                    ),
                    if (stock.sector != 'Emtia') ...[
                      const SizedBox(height: 2),
                      Text(
                        stock.name,
                        style: const TextStyle(
                            color: Colors.grey, fontSize: 11),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                    if (summary?.signal != null) ...[
                      const SizedBox(height: 4),
                      SignalBadge(signal: summary!.signal!),
                    ],
                  ],
                ),
              ),

              // Middle: Sparkline
              if (hasData && summary.sparkline.length >= 2)
                Expanded(
                  flex: 2,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: SizedBox(
                      height: 32,
                      child: SparklineWidget(
                        data: summary.sparkline,
                        color: isUp ? Colors.green : Colors.red,
                      ),
                    ),
                  ),
                ),

              // Right: Price + change
              if (hasData)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      summary.price.toStringAsFixed(2),
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                    const SizedBox(height: 2),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: isUp
                            ? Colors.green.withValues(alpha: 0.15)
                            : Colors.red.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        '${isUp ? "+" : ""}${summary.changePercent.toStringAsFixed(2)}%',
                        style: TextStyle(
                          color: isUp ? Colors.green : Colors.red,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    if (summary.technicalScore != null) ...[
                      const SizedBox(height: 2),
                      Text(
                        'Skor: ${summary.technicalScore!.toStringAsFixed(0)}',
                        style: TextStyle(
                          fontSize: 10,
                          color: summary.technicalScore! >= 70
                              ? Colors.green
                              : summary.technicalScore! >= 50
                                  ? Colors.orange
                                  : Colors.red,
                        ),
                      ),
                    ],
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}
