import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/app_state.dart';
import '../../data/models/transaction.dart';

class TransactionScreen extends StatefulWidget {
  final int stockId;
  final String ticker;

  const TransactionScreen({
    super.key,
    required this.stockId,
    required this.ticker,
  });

  @override
  State<TransactionScreen> createState() => _TransactionScreenState();
}

class _TransactionScreenState extends State<TransactionScreen> {
  final _priceController = TextEditingController();
  final _quantityController = TextEditingController();
  String _type = 'BUY';

  @override
  void dispose() {
    _priceController.dispose();
    _quantityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final transactions = state.selectedStockTransactions;

    return Scaffold(
      appBar: AppBar(title: Text('${widget.ticker} Islemler')),
      body: Column(
        children: [
          // Add transaction form
          Card(
            margin: const EdgeInsets.all(12),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Yeni Islem',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: SegmentedButton<String>(
                          segments: const [
                            ButtonSegment(value: 'BUY', label: Text('Alis')),
                            ButtonSegment(value: 'SELL', label: Text('Satis')),
                          ],
                          selected: {_type},
                          onSelectionChanged: (v) =>
                              setState(() => _type = v.first),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _priceController,
                          keyboardType: const TextInputType.numberWithOptions(
                              decimal: true),
                          decoration: const InputDecoration(
                            labelText: 'Fiyat (TL)',
                            border: OutlineInputBorder(),
                            isDense: true,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextField(
                          controller: _quantityController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Adet',
                            border: OutlineInputBorder(),
                            isDense: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () => _saveTransaction(state),
                      icon: const Icon(Icons.add),
                      label: const Text('Kaydet'),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Transaction list
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Text('Islem Gecmisi',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const Spacer(),
                if (transactions.isNotEmpty)
                  Text('${transactions.length} islem',
                      style:
                          const TextStyle(color: Colors.grey, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 8),

          if (transactions.isEmpty)
            const Expanded(
              child: Center(
                child: Text('Henuz islem yok',
                    style: TextStyle(color: Colors.grey)),
              ),
            )
          else
            Expanded(
              child: ListView.builder(
                itemCount: transactions.length,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemBuilder: (context, index) {
                  final tx = transactions[index];
                  return _buildTransactionCard(tx, state);
                },
              ),
            ),

          // Summary
          if (transactions.isNotEmpty) _buildSummary(transactions),
        ],
      ),
    );
  }

  Widget _buildTransactionCard(StockTransaction tx, AppState state) {
    final isBuy = tx.type == 'BUY';
    final dateStr = DateFormat('dd.MM.yyyy HH:mm')
        .format(DateTime.fromMillisecondsSinceEpoch(tx.datetime));
    final total = tx.price * tx.quantity;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor:
              isBuy ? Colors.green.withValues(alpha: 0.2) : Colors.red.withValues(alpha: 0.2),
          child: Icon(
            isBuy ? Icons.arrow_downward : Icons.arrow_upward,
            color: isBuy ? Colors.green : Colors.red,
          ),
        ),
        title: Text(
          '${isBuy ? "Alis" : "Satis"} - ${tx.quantity} adet',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: isBuy ? Colors.green : Colors.red,
          ),
        ),
        subtitle: Text('$dateStr\n${tx.price.toStringAsFixed(2)} TL x ${tx.quantity}'),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text('${total.toStringAsFixed(2)} TL',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            if (tx.triggerSource != null)
              Text(tx.triggerSource!,
                  style: const TextStyle(color: Colors.grey, fontSize: 10)),
          ],
        ),
        isThreeLine: true,
        onLongPress: () => _confirmDelete(tx, state),
      ),
    );
  }

  Widget _buildSummary(List<StockTransaction> transactions) {
    double totalBuy = 0;
    int totalBuyQty = 0;
    double totalSell = 0;
    int totalSellQty = 0;

    for (final tx in transactions) {
      if (tx.type == 'BUY') {
        totalBuy += tx.price * tx.quantity;
        totalBuyQty += tx.quantity;
      } else {
        totalSell += tx.price * tx.quantity;
        totalSellQty += tx.quantity;
      }
    }

    final netQty = totalBuyQty - totalSellQty;
    final avgBuyPrice = totalBuyQty > 0 ? totalBuy / totalBuyQty : 0.0;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _summaryItem('Ort. Maliyet', '${avgBuyPrice.toStringAsFixed(2)} TL'),
          _summaryItem('Net Adet', '$netQty'),
          _summaryItem('Toplam Alis', '${totalBuy.toStringAsFixed(0)} TL'),
          _summaryItem('Toplam Satis', '${totalSell.toStringAsFixed(0)} TL'),
        ],
      ),
    );
  }

  Widget _summaryItem(String label, String value) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 10)),
        const SizedBox(height: 2),
        Text(value,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
      ],
    );
  }

  void _saveTransaction(AppState state) {
    final price = double.tryParse(_priceController.text.replaceAll(',', '.'));
    final quantity = int.tryParse(_quantityController.text);

    if (price == null || price <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gecerli bir fiyat girin')));
      return;
    }
    if (quantity == null || quantity <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gecerli bir adet girin')));
      return;
    }

    state.addTransaction(
      stockId: widget.stockId,
      type: _type,
      price: price,
      quantity: quantity,
    );

    _priceController.clear();
    _quantityController.clear();

    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Islem kaydedildi')));
  }

  void _confirmDelete(StockTransaction tx, AppState state) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Islemi Sil'),
        content: const Text('Bu islemi silmek istediginize emin misiniz?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Iptal')),
          TextButton(
            onPressed: () {
              state.deleteTransaction(tx.id!);
              Navigator.pop(ctx);
            },
            child:
                const Text('Sil', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
