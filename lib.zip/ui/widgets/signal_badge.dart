import 'package:flutter/material.dart';

class SignalBadge extends StatelessWidget {
  final String signal;
  const SignalBadge({super.key, required this.signal});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (signal.toUpperCase()) {
      case 'GUCLU_AL':
        color = Colors.green.shade700;
        break;
      case 'AL':
        color = Colors.green;
        break;
      case 'IZLE':
        color = Colors.blue;
        break;
      case 'TUT':
        color = Colors.grey;
        break;
      case 'KISMI_SAT':
        color = Colors.orange;
        break;
      case 'SAT':
        color = Colors.red;
        break;
      case 'ACIL_SAT':
        color = Colors.red.shade900;
        break;
      default:
        color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        signal.replaceAll('_', ' '),
        style: const TextStyle(
            color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
      ),
    );
  }
}
