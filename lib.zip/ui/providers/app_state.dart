import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import '../../data/models/stock.dart';
import '../../data/models/daily_price.dart';
import '../../data/models/indicator.dart';
import '../../data/models/ai_analysis.dart';
import '../../data/models/analysis_session.dart';
import '../../data/models/fibonacci.dart';
import '../../data/models/transaction.dart';
import '../../data/remote/yahoo_finance_api.dart';
import '../../data/repositories/stock_repository.dart';
import '../../data/repositories/price_repository.dart';
import '../../data/repositories/analysis_repository.dart';
import '../../domain/analysis/indicator_calculator.dart';
import '../../domain/analysis/fibonacci_calculator.dart';
import '../../domain/filter/filter_pipeline.dart';
import '../../ai/gemini_client.dart';
import '../../ai/prompt_builder.dart';
import '../../ai/response_parser.dart';
import '../../ai/news_translation_service.dart';
import '../../data/remote/rss_news_service.dart';
import '../../data/remote/kap_service.dart';
import '../../data/models/market_agenda.dart';
import '../../data/models/kap_disclosure.dart';
import '../../services/connectivity_service.dart';
import '../../services/notification_service.dart';
import '../../config/app_config.dart';

class AppState extends ChangeNotifier {
  final StockRepository _stockRepo = StockRepository();
  final PriceRepository _priceRepo = PriceRepository();
  final AnalysisRepository _analysisRepo = AnalysisRepository();
  final IndicatorCalculator _indicatorCalc = IndicatorCalculator();
  final FibonacciCalculator _fibCalc = FibonacciCalculator();
  final FilterPipeline _filterPipeline = FilterPipeline();
  final PromptBuilder _promptBuilder = PromptBuilder();
  final ResponseParser _responseParser = ResponseParser();
  static const _apiKeyPref = 'gemini_api_key';
  static const _hasScannedPref = 'has_scanned_once';
  static const _lastFilterDatePref = 'last_filter_date';
  static const _lastUpdatedTimePref = 'last_updated_time';

  List<Stock> activeStocks = [];
  List<Stock> portfolioStocks = [];
  List<Stock> commodityStocks = [];
  List<Stock> allStocks = [];
  bool isLoading = false;
  bool hasScannedOnce = false; // en az 1 tarama yapildi mi
  String? apiKey;
  String? lastError;
  bool isOnline = true;
  String? lastUpdatedTime;

  // Stock summary cache for list views (stockId -> summary)
  Map<int, StockSummary> stockSummaries = {};

  // Auto-refresh
  Timer? _autoRefreshTimer;

  // Track when last daily filter was done
  DateTime? _lastFilterDate;

  // Detail screen state
  Stock? selectedStock;
  List<DailyPrice> selectedStockPrices = [];
  List<Indicator> selectedStockIndicators = [];
  List<AiAnalysis> selectedStockAnalyses = [];
  List<StockTransaction> selectedStockTransactions = [];
  FibonacciData? selectedStockFibonacci;

  // Chart interval state
  String selectedInterval = '1d';
  List<DailyPrice> chartPrices = [];
  bool isLoadingChart = false;

  // Recent AI analyses
  List<AiAnalysis> recentAnalyses = [];

  // Analysis sessions (grouped analyses)
  List<AnalysisSession> recentSessions = [];
  // Session ID -> analyses cache
  Map<int, List<AiAnalysis>> sessionAnalysesCache = {};

  // Progress tracking
  String? progressMessage;
  int progressCurrent = 0;
  int progressTotal = 0;

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    super.dispose();
  }

  Future<void> init() async {
    isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      apiKey = prefs.getString(_apiKeyPref);
      hasScannedOnce = prefs.getBool(_hasScannedPref) ?? false;
      lastUpdatedTime = prefs.getString(_lastUpdatedTimePref);
      final lastFilterMs = prefs.getInt(_lastFilterDatePref);
      if (lastFilterMs != null) {
        _lastFilterDate = DateTime.fromMillisecondsSinceEpoch(lastFilterMs);
      }
      await _stockRepo.seedBist100IfEmpty();
      await _stockRepo.seedCommoditiesIfMissing(); // Upgrade: emtia yoksa ekle
      await refreshStocks();
      await loadRecentAnalyses();
      isOnline = await ConnectivityService.checkConnectivity();
      await NotificationService.instance.init();
      _startAutoRefresh();
    } catch (e) {
      lastError = 'Baslangic hatasi: $e';
    }

    isLoading = false;
    notifyListeners();
  }

  // ==================== PERSISTENCE HELPERS ====================

  Future<void> _persistState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_hasScannedPref, hasScannedOnce);
    if (_lastFilterDate != null) {
      await prefs.setInt(
          _lastFilterDatePref, _lastFilterDate!.millisecondsSinceEpoch);
    }
    if (lastUpdatedTime != null) {
      await prefs.setString(_lastUpdatedTimePref, lastUpdatedTime!);
    }
  }

  // ==================== AUTO REFRESH ====================

  void _startAutoRefresh() {
    _autoRefreshTimer?.cancel();
    _autoRefreshTimer = Timer.periodic(
      Duration(minutes: AppConfig.intradayIntervalMinutes),
      (_) {
        if (isLoading) return;
        // Sabah analizi: piyasa acilmadan once otomatik tetikle
        if (_isMorningAnalysisTime() && !_isMorningAnalysisDoneToday()) {
          _runMorningAnalysis();
          return;
        }
        if (_isMarketOpen()) {
          _refreshActiveAndPortfolio();
        }
      },
    );
  }

  bool _isMorningAnalysisTime() {
    final now = DateTime.now();
    if (now.weekday == DateTime.saturday || now.weekday == DateTime.sunday) return false;
    final currentMinutes = now.hour * 60 + now.minute;
    final morningMinutes = AppConfig.morningAnalysisHour * 60 + AppConfig.morningAnalysisMinute;
    final openMinutes = AppConfig.marketOpenHour * 60 + AppConfig.marketOpenMinute;
    return currentMinutes >= morningMinutes && currentMinutes < openMinutes;
  }

  bool _isMorningAnalysisDoneToday() {
    // Bugun GUNLUK analiz yapilmissa sabah analizi tamamlanmis demektir
    return _isFilterDoneToday();
  }

  Future<void> _runMorningAnalysis() async {
    if (apiKey == null || apiKey!.isEmpty) return;
    if (!hasScannedOnce) return; // En az 1 tarama yapilmis olmali

    debugPrint('[AI] Sabah analizi tetikleniyor...');
    AgendaCache.clear(); // Sabah taze haber cek
    progressMessage = 'Sabah analizi baslatiliyor...';
    isLoading = true;
    notifyListeners();

    try {
      isOnline = await ConnectivityService.checkConnectivity();
      if (!isOnline) {
        isLoading = false;
        notifyListeners();
        return;
      }

      // Fiyatlari guncelle
      final stocksToRefresh = <Stock>{...activeStocks, ...portfolioStocks};
      stocksToRefresh.addAll(await _stockRepo.getCommodityStocks());
      for (final stock in stocksToRefresh) {
        try {
          if (AppConfig.isCommodityTicker(stock.ticker)) {
            await _priceRepo.fetchAndSaveCommodityPrices(stock.ticker, stock.id!, force: true);
          } else {
            await _priceRepo.fetchAndSaveDailyPrices(stock.ticker, stock.id!, force: true);
          }
        } catch (_) {}
      }

      // Tam tarama: filtre uygula
      final allDbStocks = await _stockRepo.getAllStocks();
      final swi = await _buildStockWithIndicators(allDbStocks.toSet());
      if (swi.isEmpty) {
        isLoading = false;
        notifyListeners();
        return;
      }

      final filteredSwi = _filterPipeline.execute(swi);
      final filteredIds = filteredSwi.map((s) => s.stock.id!).toSet();

      // Sabah analizi = GUNLUK, buildMorningPrompt kullanilir
      await _runGeminiAnalysis(
        filteredSwi.isEmpty ? swi.take(5).toList() : filteredSwi,
        filteredStockIds: filteredIds,
        analysisType: 'GUNLUK',
        useMorningPrompt: true,
      );

      _lastFilterDate = DateTime.now();
      hasScannedOnce = true;
      await refreshStocks();
      await loadRecentAnalyses();
      await _updatePortfolioFromAnalysis();
      lastUpdatedTime = DateFormat('HH:mm').format(DateTime.now());
      _persistState();
    } catch (e) {
      lastError = 'Sabah analizi hatasi: $e';
    } finally {
      isLoading = false;
      progressMessage = null;
      notifyListeners();
    }
  }

  bool _isMarketOpen() {
    final now = DateTime.now();
    if (now.weekday == DateTime.saturday || now.weekday == DateTime.sunday) {
      return false;
    }
    final currentMinutes = now.hour * 60 + now.minute;
    final openMinutes =
        AppConfig.marketOpenHour * 60 + AppConfig.marketOpenMinute;
    final closeMinutes =
        AppConfig.marketCloseHour * 60 + AppConfig.marketCloseMinute;
    return currentMinutes >= openMinutes && currentMinutes <= closeMinutes;
  }

  bool _isFilterDoneToday() {
    if (_lastFilterDate == null) return false;
    final now = DateTime.now();
    return _lastFilterDate!.year == now.year &&
        _lastFilterDate!.month == now.month &&
        _lastFilterDate!.day == now.day;
  }

  // ==================== STOCK REFRESH ====================

  void clearError() {
    lastError = null;
    notifyListeners();
  }

  Future<void> refreshStocks() async {
    allStocks = await _stockRepo.getAllStocks();
    activeStocks = await _stockRepo.getActiveStocks();
    portfolioStocks = await _stockRepo.getPortfolioStocks();
    commodityStocks = await _stockRepo.getCommodityStocks();
    await _loadStockSummaries();
    notifyListeners();
  }

  // ==================== API KEY ====================

  Future<void> saveApiKey(String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_apiKeyPref, key);
    apiKey = key;
    notifyListeners();
    _runFirstAnalysisAfterKeySet();
  }

  Future<void> _runFirstAnalysisAfterKeySet() async {
    if (!hasApiKey || isLoading) return;

    if (activeStocks.isEmpty && portfolioStocks.isEmpty) {
      await fetchAllData();
      return;
    }

    // Aktif hisseler var, sadece AI analizini calistir
    isLoading = true;
    progressMessage = 'AI analizi yapiliyor...';
    notifyListeners();

    try {
      final swi = await _buildStockWithIndicators(
          {...activeStocks, ...portfolioStocks});
      if (swi.isNotEmpty) {
        await _runGeminiAnalysis(swi, analysisType: 'GUNLUK');
        await refreshStocks();
        await loadRecentAnalyses();
        await _updatePortfolioFromAnalysis();
        lastUpdatedTime = DateFormat('HH:mm').format(DateTime.now());
        _persistState();
      }
    } catch (e) {
      lastError = 'Ilk AI analizi hatasi: $e';
    } finally {
      isLoading = false;
      progressMessage = null;
      notifyListeners();
    }
  }

  Future<void> clearApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_apiKeyPref);
    apiKey = null;
    notifyListeners();
  }

  bool get hasApiKey => apiKey != null && apiKey!.isNotEmpty;

  // ==================== 15DK OTO GUNCELLEME ====================
  // Sadece aktif + portfoy hisselerinin fiyatini gunceller (filtre yapmaz)

  Future<void> _refreshActiveAndPortfolio() async {
    if (isLoading) return;
    isLoading = true;
    lastError = null;
    notifyListeners();

    isOnline = await ConnectivityService.checkConnectivity();
    if (!isOnline) {
      isLoading = false;
      notifyListeners();
      return;
    }

    try {
      final stocksToRefresh = <Stock>{...activeStocks, ...portfolioStocks};
      // Emtialari da her zaman guncelle
      final commodityStocks = await _stockRepo.getCommodityStocks();
      stocksToRefresh.addAll(commodityStocks);

      if (stocksToRefresh.isEmpty) {
        isLoading = false;
        notifyListeners();
        return;
      }

      int errorCount = 0;
      progressTotal = stocksToRefresh.length;
      int i = 0;
      for (final stock in stocksToRefresh) {
        progressCurrent = ++i;
        progressMessage =
            '${stock.ticker} guncelleniyor... ($i/${stocksToRefresh.length})';
        notifyListeners();
        try {
          if (AppConfig.isCommodityTicker(stock.ticker)) {
            await _priceRepo.fetchAndSaveCommodityPrices(stock.ticker, stock.id!);
          } else {
            await _priceRepo.fetchAndSaveDailyPrices(stock.ticker, stock.id!);
          }
        } catch (_) {
          errorCount++;
        }
      }

      await refreshStocks();
      lastUpdatedTime = DateFormat('HH:mm').format(DateTime.now());
      _persistState();
      if (errorCount > 0) {
        lastError = '$errorCount hisse icin fiyat alinamadi.';
      }
    } catch (e) {
      lastError = 'Guncelleme hatasi: $e';
    } finally {
      isLoading = false;
      progressMessage = null;
      notifyListeners();
    }
  }

  // ==================== TAM TARAMA (BIST-100 filtre) ====================
  // Tum BIST-100 uzerinde calisir, fiyatlari zorla ceker, filtre uygular

  Future<void> fetchAllData() async {
    if (isLoading) return;
    isLoading = true;
    lastError = null;
    notifyListeners();

    isOnline = await ConnectivityService.checkConnectivity();
    if (!isOnline) {
      lastError =
          'Internet baglantisi yok. Onbellekteki veriler gosteriliyor.';
      isLoading = false;
      notifyListeners();
      return;
    }

    try {
      final allDbStocks = await _stockRepo.getAllStocks();
      int errorCount = 0;
      int successCount = 0;
      final errors = <String>[];

      // STEP 1: Tum BIST-100 fiyatlarini internetten cek (force)
      progressTotal = allDbStocks.length;
      for (int i = 0; i < allDbStocks.length; i++) {
        final stock = allDbStocks[i];
        progressCurrent = i + 1;
        progressMessage =
            '${stock.ticker} fiyatlari aliniyor... (${i + 1}/${allDbStocks.length})';
        notifyListeners();
        try {
          final prices = AppConfig.isCommodityTicker(stock.ticker)
              ? await _priceRepo.fetchAndSaveCommodityPrices(
                  stock.ticker, stock.id!, force: true)
              : await _priceRepo.fetchAndSaveDailyPrices(
                  stock.ticker, stock.id!, force: true);
          if (prices.isNotEmpty) {
            successCount++;
          } else {
            errorCount++;
            final apiErr = _priceRepo.lastApiError;
            if (apiErr != null && errors.length < 5) {
              errors.add(apiErr);
            }
          }
        } catch (e) {
          errorCount++;
          if (errors.length < 5) errors.add('${stock.ticker}: $e');
        }
      }

      // STEP 2: Indikator hesapla
      progressMessage = 'Indikatorler hesaplaniyor...';
      notifyListeners();

      await _stockRepo.clearAllActive();
      final stocksWithIndicators = <StockWithIndicators>[];

      for (final stock in allDbStocks) {
        try {
          final prices = await _priceRepo.getDailyPrices(stock.id!);
          if (prices.length < AppConfig.minPricesForIndicator) continue;

          final indicators = _indicatorCalc.calculate(prices, stock.id!);
          if (indicators.isNotEmpty) {
            await _analysisRepo.saveIndicators(indicators);
          }

          final atrValues = indicators.map((i) => i.atr).toList();
          final fib = _fibCalc.calculate(prices, atrValues, stock.id!);
          if (fib != null) await _analysisRepo.saveFibonacci(fib);

          final latestIndicator =
              await _analysisRepo.getLatestIndicator(stock.id!);
          final latestPrice = prices.isNotEmpty ? prices.first : null;
          if (latestIndicator != null && latestPrice != null) {
            stocksWithIndicators.add(StockWithIndicators(
              stock: stock,
              indicator: latestIndicator,
              latestPrice: latestPrice,
            ));
          }
        } catch (_) {}
      }

      // STEP 3: Filtre pipeline
      progressMessage = 'Filtre uygulaniyor...';
      notifyListeners();

      final filtered = _filterPipeline.execute(stocksWithIndicators);

      if (filtered.isNotEmpty) {
        for (final item in filtered) {
          await _stockRepo.setActive(item.stock.id!, true);
        }
      } else if (stocksWithIndicators.isNotEmpty) {
        // Filtre bos: en iyi 5 adayi goster
        final sorted = List.of(stocksWithIndicators)
          ..sort((a, b) => (b.indicator.technicalScore ?? 0)
              .compareTo(a.indicator.technicalScore ?? 0));
        for (final item in sorted.take(5)) {
          await _stockRepo.setActive(item.stock.id!, true);
        }
      }

      _lastFilterDate = DateTime.now();
      hasScannedOnce = true;
      await _persistState();

      // STEP 4: Gemini analizi - filtreden gecenler veya en iyi 5
      final filteredIds = filtered.map((f) => f.stock.id!).toSet();
      final activeForAnalysis =
          filtered.isNotEmpty ? filtered : stocksWithIndicators.take(5).toList();
      if (hasApiKey && activeForAnalysis.isNotEmpty) {
        progressMessage = 'AI analizi yapiliyor...';
        notifyListeners();
        await _runGeminiAnalysis(activeForAnalysis,
            filteredStockIds: filteredIds, analysisType: 'GUNLUK');
      }

      await refreshStocks();
      await loadRecentAnalyses();
      await _updatePortfolioFromAnalysis();

      await _priceRepo.cleanupOldData();
      await _analysisRepo.cleanupOldData();
      await _analysisRepo.vacuumDatabase(); // Silinen verilerden sonra DB boyutunu kucult

      lastUpdatedTime = DateFormat('HH:mm').format(DateTime.now());
      _persistState();

      // Sonuc mesaji
      debugPrint('[TARAMA] Toplam: ${allDbStocks.length}, Basarili: $successCount, '
          'Hata: $errorCount, Indikator: ${stocksWithIndicators.length}, '
          'Filtre: ${filtered.length}');
      if (errors.isNotEmpty) {
        debugPrint('[TARAMA HATALAR] ${errors.join(' | ')}');
      }

      if (successCount == 0) {
        lastError = 'HATA: Hicbir fiyat cekilemedi!\n${errors.join('\n')}';
      } else if (stocksWithIndicators.isEmpty) {
        lastError = '$successCount fiyat cekildi ama indikator hesaplanamadi '
            '(50+ gun veri gerekli).\n${errors.isNotEmpty ? errors.first : ""}';
      } else {
        final msg = StringBuffer();
        msg.write('$successCount/${ allDbStocks.length} fiyat cekildi');
        msg.write(', ${stocksWithIndicators.length} indikator');
        msg.write(', ${filtered.length} filtre gecti');
        if (filtered.isEmpty) msg.write(' (en iyi 5 gosteriliyor)');
        if (errors.isNotEmpty) msg.write('\nHatalar: ${errors.first}');
        lastError = msg.toString();
      }

      progressMessage = null;
    } catch (e) {
      lastError = 'Veri guncellenirken hata: $e';
    } finally {
      isLoading = false;
      progressMessage = null;
      notifyListeners();
    }
  }

  /// Ilk tarama - ayni fetchAllData
  Future<void> fetchInitialData() async {
    await fetchAllData();
  }

  // ==================== ANALIZ ET BUTONU ====================
  // Gun icinde filtreleme yapilmadiysa -> once tam filtreleme yap
  // Yapildiysa -> sadece saatlik veri cek + AI analizi

  Future<void> runManualAnalysis() async {
    if (!hasApiKey) {
      lastError = 'AI analizi icin once Ayarlar\'dan Gemini API key girin.';
      notifyListeners();
      return;
    }
    if (isLoading) return;

    // Gun ici filtreleme yapilmadi mi?
    if (!_isFilterDoneToday()) {
      // Tam BIST-100 filtrele + analiz
      await fetchAllData();
      return;
    }

    // Filtreleme bugun yapildi, sadece saatlik veri cek + AI analizi
    isLoading = true;
    progressMessage = 'Saatlik veriler aliniyor...';
    notifyListeners();

    try {
      isOnline = await ConnectivityService.checkConnectivity();
      if (!isOnline) {
        lastError = 'Internet baglantisi yok.';
        isLoading = false;
        progressMessage = null;
        notifyListeners();
        return;
      }

      final stocksToAnalyze = <Stock>{...activeStocks, ...portfolioStocks};
      // Emtialari da ekle
      final cStocks = await _stockRepo.getCommodityStocks();
      stocksToAnalyze.addAll(cStocks);

      if (stocksToAnalyze.isEmpty) {
        lastError = 'Analiz edilecek hisse yok.';
        isLoading = false;
        progressMessage = null;
        notifyListeners();
        return;
      }

      // Saatlik veri cek (fiyat guncelle)
      final api = YahooFinanceApi();
      int i = 0;
      progressTotal = stocksToAnalyze.length;
      for (final stock in stocksToAnalyze) {
        progressCurrent = ++i;
        progressMessage =
            '${stock.ticker} saatlik veri... ($i/${stocksToAnalyze.length})';
        notifyListeners();
        try {
          // Gunluk veriyi guncelle
          if (AppConfig.isCommodityTicker(stock.ticker)) {
            await _priceRepo.fetchAndSaveCommodityPrices(stock.ticker, stock.id!);
          } else {
            await _priceRepo.fetchAndSaveDailyPrices(stock.ticker, stock.id!);
          }
          // Saatlik veriyi de cek (AI icin daha taze veri)
          await api.fetchPrices(stock.ticker, stock.id!, interval: '60m');
        } catch (_) {}
      }

      // AI analizi
      progressMessage = 'AI analizi yapiliyor...';
      notifyListeners();

      final swi = await _buildStockWithIndicators(stocksToAnalyze);
      if (swi.isNotEmpty) {
        await _runGeminiAnalysis(swi, analysisType: 'SAATLIK');
      }

      await refreshStocks();
      await loadRecentAnalyses();
      await _updatePortfolioFromAnalysis();
      lastUpdatedTime = DateFormat('HH:mm').format(DateTime.now());
      _persistState();
    } catch (e) {
      lastError = 'AI analizi hatasi: $e';
    } finally {
      isLoading = false;
      progressMessage = null;
      notifyListeners();
    }
  }

  // ==================== DETAIL SCREEN ====================

  Future<void> loadStockDetail(int stockId) async {
    isLoading = true;
    selectedInterval = '1d';
    notifyListeners();

    try {
      selectedStock = await _stockRepo.getById(stockId);
      selectedStockPrices = await _priceRepo.getDailyPrices(stockId);
      chartPrices = selectedStockPrices;
      selectedStockIndicators =
          await _analysisRepo.getIndicatorsForStock(stockId);
      selectedStockAnalyses =
          await _analysisRepo.getAiAnalysesForStock(stockId);
      selectedStockTransactions =
          await _analysisRepo.getTransactionsForStock(stockId);
      selectedStockFibonacci = await _analysisRepo.getFibonacci(stockId);
    } catch (e) {
      lastError = 'Detay yuklenirken hata: $e';
    }

    isLoading = false;
    notifyListeners();
  }

  Future<void> changeInterval(String interval) async {
    if (selectedStock == null || isLoadingChart) return;
    selectedInterval = interval;

    if (interval == '1d') {
      chartPrices = selectedStockPrices;
      notifyListeners();
      return;
    }

    isLoadingChart = true;
    notifyListeners();

    try {
      final api = YahooFinanceApi();
      final prices = await api.fetchPrices(
        selectedStock!.ticker,
        selectedStock!.id!,
        interval: interval,
      );
      chartPrices = prices;
    } catch (e) {
      lastError = 'Grafik verisi alinamadi: $e';
      chartPrices = [];
    }

    isLoadingChart = false;
    notifyListeners();
  }

  // ==================== PORTFOLIO (AI-MANAGED) ====================

  /// AI analiz sonuclarina gore portfoyu otomatik gunceller.
  /// - Max 3 hisse
  /// - T+1: Bugun alinan hisse bugun satilamaz
  /// - SAT/ACIL_SAT/GUCLU_SAT sinyali olan hisseler cikarilir (T+1 degilse)
  /// - En yuksek guvenli 3 hisse (SAT sinyalleri haric) portfoye alinir
  Future<void> _updatePortfolioFromAnalysis() async {
    // 1. Bugunun tum analizlerini al
    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day);
    final todayMs = todayStart.millisecondsSinceEpoch;

    final todayAnalyses = recentAnalyses
        .where((a) => a.datetime >= todayMs)
        .toList();

    if (todayAnalyses.isEmpty) {
      debugPrint('[PORTFOY] Bugun analiz yok, portfoy guncellenmedi');
      return;
    }

    // Her hisse icin en son analizi bul
    final latestByStock = <int, AiAnalysis>{};
    for (final a in todayAnalyses) {
      final existing = latestByStock[a.stockId];
      if (existing == null || a.datetime > existing.datetime) {
        latestByStock[a.stockId] = a;
      }
    }
    debugPrint('[PORTFOY] Bugun ${latestByStock.length} hisse analiz edildi');

    const sellSignals = {'SAT', 'ACIL_SAT', 'GUCLU_SAT'};

    // 2. Mevcut portfoy: T+1 kilitli olanlari koru
    final currentPortfolio = await _stockRepo.getPortfolioStocks();
    final lockedStockIds = <int>{};

    for (final stock in currentPortfolio) {
      if (stock.isT1Locked) {
        lockedStockIds.add(stock.id!);
        debugPrint('[PORTFOY] ${stock.ticker} T+1 kilitli, korunuyor');
      }
    }

    // 3. Tum analizleri guven sirasina gore sirala (SAT sinyalleri ve emtialar haric)
    final commodityIds = (await _stockRepo.getCommodityStocks()).map((s) => s.id!).toSet();
    final candidates = latestByStock.entries
        .where((e) => !sellSignals.contains(e.value.signal) && !commodityIds.contains(e.key))
        .toList()
      ..sort((a, b) => b.value.confidence.compareTo(a.value.confidence));

    debugPrint('[PORTFOY] ${candidates.length} aday (SAT haric), '
        '${lockedStockIds.length} T+1 kilitli');

    // 4. Yeni portfoyu olustur: T+1 kilitli + en iyi adaylar = max 3
    final newPortfolioIds = <int>{...lockedStockIds};

    for (final entry in candidates) {
      if (newPortfolioIds.length >= AppConfig.maxPortfolioStocks) break;
      newPortfolioIds.add(entry.key); // Set oldugu icin duplicate eklenmez
    }

    // 5. DB guncelle: cikanlari cikar
    for (final stock in currentPortfolio) {
      if (!newPortfolioIds.contains(stock.id)) {
        await _stockRepo.setInPortfolioWithDate(stock.id!, false, null);
        debugPrint('[PORTFOY] ${stock.ticker} portfoyden cikarildi');
      }
    }

    // Yeni eklenenler (bugunun tarihiyle - T+1 icin)
    final currentIds = currentPortfolio.map((s) => s.id).toSet();
    for (final stockId in newPortfolioIds) {
      if (!currentIds.contains(stockId)) {
        await _stockRepo.setInPortfolioWithDate(
            stockId, true, now.millisecondsSinceEpoch);
        final ticker = getTickerForStockId(stockId);
        debugPrint('[PORTFOY] $ticker portfoye eklendi');
      }
    }

    debugPrint('[PORTFOY] Portfoy guncellendi: ${newPortfolioIds.length} hisse');
    await refreshStocks();
  }

  // ==================== TRANSACTIONS ====================

  Future<void> addTransaction({
    required int stockId,
    required String type,
    required double price,
    required int quantity,
    String? triggerSource,
  }) async {
    final tx = StockTransaction(
      stockId: stockId,
      datetime: DateTime.now().millisecondsSinceEpoch,
      type: type,
      price: price,
      quantity: quantity,
      triggerSource: triggerSource ?? 'MANUAL',
    );
    await _analysisRepo.saveTransaction(tx);
    if (selectedStock?.id == stockId) {
      selectedStockTransactions =
          await _analysisRepo.getTransactionsForStock(stockId);
      notifyListeners();
    }
  }

  Future<void> deleteTransaction(int txId) async {
    await _analysisRepo.deleteTransaction(txId);
    if (selectedStock != null) {
      selectedStockTransactions =
          await _analysisRepo.getTransactionsForStock(selectedStock!.id!);
      notifyListeners();
    }
  }

  // ==================== AI ANALYSES ====================

  Future<void> loadRecentAnalyses() async {
    await _analysisRepo.cleanupOldAnalyses();
    recentAnalyses = await _analysisRepo.getAllRecentAnalyses();
    recentSessions = await _analysisRepo.getRecentSessions();
    sessionAnalysesCache.clear(); // Cache'i temizle, lazy load edilecek
    notifyListeners();
  }

  /// Bir session'a ait analizleri getirir (cache'li)
  Future<List<AiAnalysis>> getAnalysesForSession(int sessionId) async {
    if (sessionAnalysesCache.containsKey(sessionId)) {
      return sessionAnalysesCache[sessionId]!;
    }
    final analyses = await _analysisRepo.getAnalysesForSession(sessionId);
    sessionAnalysesCache[sessionId] = analyses;
    return analyses;
  }

  /// Bir session'i getirir (prompt/response icin)
  Future<AnalysisSession?> getSession(int sessionId) async {
    return _analysisRepo.getSession(sessionId);
  }

  /// Session ve iliskili analizleri siler
  Future<void> deleteSession(int sessionId) async {
    await _analysisRepo.deleteSession(sessionId);
    sessionAnalysesCache.remove(sessionId);
    await loadRecentAnalyses();
  }

  Future<void> deleteAnalysis(int analysisId) async {
    await _analysisRepo.deleteAiAnalysis(analysisId);
    recentAnalyses.removeWhere((a) => a.id == analysisId);
    notifyListeners();
  }

  /// Bugunun gunluk analizleri haric tum analizleri siler
  Future<int> clearOldAnalyses() async {
    final deleted = await _analysisRepo.deleteAllSessionsExceptTodayDaily();
    await _analysisRepo.deleteAllExceptTodayDaily();
    await loadRecentAnalyses();
    return deleted;
  }

  String getTickerForStockId(int stockId) {
    final stock = allStocks.where((s) => s.id == stockId).firstOrNull;
    return stock?.ticker ?? '?';
  }

  /// Emtialar icin isim, hisseler icin ticker doner
  String getDisplayName(int stockId) {
    final stock = allStocks.where((s) => s.id == stockId).firstOrNull;
    if (stock == null) return '?';
    if (stock.sector == AppConfig.commoditySector) return stock.name;
    return stock.ticker;
  }

  // ==================== HELPERS ====================

  /// Verilen hisseler icin StockWithIndicators listesi olusturur
  Future<List<StockWithIndicators>> _buildStockWithIndicators(
      Iterable<Stock> stocks) async {
    final result = <StockWithIndicators>[];
    final seenIds = <int>{};
    debugPrint('[SWI] Giris: ${stocks.length} hisse');
    for (final stock in stocks) {
      // ID bazli dedup
      if (!seenIds.add(stock.id!)) {
        debugPrint('[SWI] ${stock.ticker}: ATLANDI (duplike)');
        continue;
      }
      try {
        final prices = await _priceRepo.getDailyPrices(stock.id!);
        if (prices.length < 50) {
          debugPrint('[SWI] ${stock.ticker}: ATLANDI (${prices.length} fiyat < 50)');
          continue;
        }

        final latestIndicator =
            await _analysisRepo.getLatestIndicator(stock.id!);
        final latestPrice = prices.isNotEmpty ? prices.first : null;
        if (latestIndicator != null && latestPrice != null) {
          result.add(StockWithIndicators(
            stock: stock,
            indicator: latestIndicator,
            latestPrice: latestPrice,
          ));
        } else {
          debugPrint('[SWI] ${stock.ticker}: ATLANDI (indicator=${latestIndicator != null}, price=${latestPrice != null})');
        }
      } catch (e) {
        debugPrint('[SWI] ${stock.ticker}: HATA $e');
      }
    }
    debugPrint('[SWI] Cikis: ${result.length}/${stocks.length} hisse');
    return result;
  }

  Future<void> _runGeminiAnalysis(List<StockWithIndicators> filtered,
      {Set<int>? filteredStockIds, String analysisType = 'GUNLUK', bool useMorningPrompt = false}) async {
    try {
      debugPrint('[AI] _runGeminiAnalysis: ${filtered.length} hisse + emtialar eklenecek');
      debugPrint('[AI] Hisseler: ${filtered.map((f) => f.stock.ticker).join(", ")}');
      final client = GeminiClient(apiKey!);
      final analysisDataList = <StockAnalysisData>[];
      final allSignals = <AnalysisSignalInfo>[];
      final portfolioIds = portfolioStocks.map((s) => s.id).toSet();

      // Session olustur
      final sessionId = await _analysisRepo.createSession(AnalysisSession(
        datetime: DateTime.now().millisecondsSinceEpoch,
        analysisType: analysisType,
        stockCount: filtered.length,
      ));
      final allPrompts = StringBuffer();
      final allResponses = StringBuffer();

      // BIST-100 endeks degisimi
      double? bist100Change;
      try {
        final yahooApi = YahooFinanceApi();
        final bist100Prices = await yahooApi.fetchPrices(
            AppConfig.bist100Ticker, 0, range: '5d');
        if (bist100Prices.length >= 2) {
          final last = bist100Prices.last;
          final prev = bist100Prices[bist100Prices.length - 2];
          bist100Change = ((last.close - prev.close) / prev.close) * 100;
          debugPrint('[AI] BIST-100 degisim: ${bist100Change.toStringAsFixed(2)}%');
        }
      } catch (e) {
        debugPrint('[AI] BIST-100 endeks verisi alinamadi: $e');
      }

      // Sektor ortalama degisimleri hesapla
      final sectorChanges = <String, List<double>>{};
      for (final item in filtered) {
        final sector = item.stock.sector;
        if (sector == null) continue;
        final recentPrices = await _priceRepo.getDailyPrices(item.stock.id!, limit: 2);
        if (recentPrices.length >= 2) {
          final change = ((recentPrices[0].close - recentPrices[1].close) / recentPrices[1].close) * 100;
          sectorChanges.putIfAbsent(sector, () => []).add(change);
        }
      }
      final sectorAvgChange = <String, double>{};
      for (final entry in sectorChanges.entries) {
        sectorAvgChange[entry.key] = entry.value.reduce((a, b) => a + b) / entry.value.length;
      }

      // v4: Haber/gundem cek ve ozetle
      MarketAgenda? agenda = AgendaCache.get();
      if (agenda == null) {
        try {
          progressMessage = 'Haberler aliniyor...';
          notifyListeners();
          final rssService = RssNewsService();
          final newsItems = await rssService.fetchAll();
          final kapService = KapService();
          final watchlistTickers = filtered.map((f) => f.stock.ticker).toList();
          final kapDisclosures = await kapService.fetchDisclosures(
            tickers: watchlistTickers,
            maxAgeHours: AppConfig.newsMaxAgeHours,
          );
          if (newsItems.isNotEmpty || kapDisclosures.isNotEmpty) {
            progressMessage = 'Haberler ozetleniyor...';
            notifyListeners();
            final translationService = NewsTranslationService(client);
            agenda = await translationService.translateAndSummarize(
              newsItems: newsItems,
              kapDisclosures: kapDisclosures,
              watchlistTickers: watchlistTickers,
            );
            AgendaCache.set(agenda);
            debugPrint('[AI] Gundem hazir: ${agenda.formattedAgenda.length} karakter (KAP:${agenda.kapCount}, RSS:${agenda.rssCount})');
          }
        } catch (e) {
          debugPrint('[AI] Haber cekme/ozetleme hatasi: $e');
          // agenda null kalir, analiz habersiz devam eder
        }
      }

      // v4: KAP disclosures — hisse bazli eslestirme icin
      List<KapDisclosure> allKapDisclosures = [];
      try {
        if (agenda != null && agenda.kapCount > 0) {
          final kapService = KapService();
          final watchlistTickers = filtered.map((f) => f.stock.ticker).toList();
          allKapDisclosures = await kapService.fetchDisclosures(
            tickers: watchlistTickers,
          );
        }
      } catch (_) {}

      for (final item in filtered) {
        final prices = await _priceRepo.getDailyPrices(item.stock.id!);
        // Saatlik analizde o gunun gunluk analizini onceki olarak gonder
        final AiAnalysis? prevAnalysis;
        if (analysisType == 'SAATLIK') {
          prevAnalysis = await _analysisRepo.getTodayDailyAnalysis(item.stock.id!);
        } else {
          prevAnalysis = await _analysisRepo.getLatestAiAnalysis(item.stock.id!);
        }
        final fib = await _analysisRepo.getFibonacci(item.stock.id!);

        // Son 10 gunluk indikator ve fiyat verisi
        final recentIndicators = await _analysisRepo.getIndicatorsForStock(item.stock.id!);
        final recent10Ind = recentIndicators.take(10).toList(); // DESC order
        final recent10Prices = prices.take(10).toList();

        final isInPortfolio = portfolioIds.contains(item.stock.id);
        final passedFilter = filteredStockIds?.contains(item.stock.id) ?? true;

        // v3: Previous day ADX for direction
        final adxPrev = recent10Ind.length > 1 ? recent10Ind[1].adx : null;

        // v3: Weekly indicators from daily data
        final weeklyData = _computeWeeklyIndicators(prices);

        // v3: Derived fields
        final derived = _computeDerivedFields(recentIndicators, prices);

        // Saatlik mumlar (gun ici analiz icin)
        List<HourlyCandle>? hourlyCandles;
        if (analysisType == 'SAATLIK') {
          try {
            final yahooApi = YahooFinanceApi();
            final hourlyPrices = await yahooApi.fetchPrices(
                item.stock.ticker, item.stock.id!, interval: '60m', range: '1d');
            if (hourlyPrices.isNotEmpty) {
              hourlyCandles = hourlyPrices.map((p) => HourlyCandle(
                timestamp: p.date,
                open: p.open,
                high: p.high,
                low: p.low,
                close: p.close,
                volume: p.volume,
              )).toList();
            }
          } catch (e) {
            debugPrint('[AI] ${item.stock.ticker} saatlik mum hatasi: $e');
          }
        }

        // Sabah notlari (gun ici analizde AI'in kendi notlari)
        String? morningPlan;
        if (analysisType == 'SAATLIK') {
          morningPlan = await _analysisRepo.getMorningNotes(item.stock.id!);
        }

        // v3: Entry price for portfolio stocks
        double? entryPrice;
        if (isInPortfolio) {
          final txs = await _analysisRepo.getTransactionsForStock(item.stock.id!);
          final buyTxs = txs.where((t) => t.type == 'BUY').toList();
          if (buyTxs.isNotEmpty) {
            entryPrice = buyTxs.first.price; // Most recent buy
          }
        }

        analysisDataList.add(StockAnalysisData(
          ticker: item.stock.ticker,
          name: item.stock.name,
          sector: item.stock.sector,
          close: item.latestPrice.close,
          changePercent: prices.length > 1
              ? ((prices[0].close - prices[1].close) / prices[1].close) * 100
              : 0,
          volume: item.latestPrice.volume,
          avgVolume20: prices.take(AppConfig.avgVolumePeriod).isEmpty
              ? 0
              : (prices
                      .take(AppConfig.avgVolumePeriod)
                      .map((p) => p.volume)
                      .reduce((a, b) => a + b) ~/
                  prices.take(AppConfig.avgVolumePeriod).length),
          rsi: item.indicator.rsi,
          macd: item.indicator.macd,
          macdSignal: item.indicator.macdSignal,
          macdHistogram: item.indicator.macdHistogram,
          bbUpper: item.indicator.bbUpper,
          bbMiddle: item.indicator.bbMiddle,
          bbLower: item.indicator.bbLower,
          bbPercentB: item.indicator.bbPercentB,
          obv: item.indicator.obv,
          sma20: item.indicator.sma20,
          sma50: item.indicator.sma50,
          sma200: item.indicator.sma200,
          atr: item.indicator.atr,
          technicalScore: item.indicator.technicalScore,
          fibHigh: fib?.swingHighPrice,
          fibLow: fib?.swingLowPrice,
          fib236: fib?.level236,
          fib382: fib?.level382,
          fib500: fib?.level500,
          fib618: fib?.level618,
          previousSummary: prevAnalysis?.summary,
          previousSignal: prevAnalysis?.signal,
          isInPortfolio: isInPortfolio,
          passedFilter: passedFilter,
          recentCloses: recent10Prices.map((p) => p.close).toList(),
          recentRsi: recent10Ind.map((i) => i.rsi).toList(),
          recentMacdHist: recent10Ind.map((i) => i.macdHistogram).toList(),
          recentVolumes: recent10Prices.map((p) => p.volume).toList(),
          // v3: ADX
          adx: item.indicator.adx,
          adxPrev: adxPrev,
          plusDi: item.indicator.plusDi,
          minusDi: item.indicator.minusDi,
          // v3: Weekly
          weeklySma20: weeklyData['sma20'] as double?,
          weeklySma50: weeklyData['sma50'] as double?,
          weeklyRsi: weeklyData['rsi'] as double?,
          weeklyTrend: weeklyData['trend'] as String?,
          // v3: Entry price
          entryPrice: entryPrice,
          // v3: Derived fields
          obvMa20: derived['obvMa20'] as double?,
          obvTrend: derived['obvTrend'] as String?,
          obvDivergence: derived['obvDivergence'] as bool?,
          obvDivergenceType: derived['obvDivergenceType'] as String?,
          bbWidth: derived['bbWidth'] as double?,
          bbWidthTrend: derived['bbWidthTrend'] as String?,
          bbSqueeze: derived['bbSqueeze'] as bool?,
          ema9: derived['ema9'] as double?,
          ema21: derived['ema21'] as double?,
          swingHigh20: derived['swingHigh20'] as double?,
          swingLow20: derived['swingLow20'] as double?,
          bist100Change: bist100Change,
          sectorChange: item.stock.sector != null ? sectorAvgChange[item.stock.sector!] : null,
          hourlyCandles: hourlyCandles,
          morningPlan: morningPlan,
          // v4: KAP haberler
          recentKapHeadlines: KapService.filterByTicker(allKapDisclosures, item.stock.ticker)
              .map((d) => d.titleEn ?? d.title)
              .toList(),
          hasKapNews: KapService.filterByTicker(allKapDisclosures, item.stock.ticker).isNotEmpty,
        ));
      }

      // v4: Emtialari (altin, gumus) her zaman ekle — filtreden bagimsiz
      final commodityStocks = await _stockRepo.getCommodityStocks();
      final commodityStocksList = <Stock>[]; // result parsing icin
      for (final cStock in commodityStocks) {
        // Zaten filtered'da varsa tekrar ekleme
        if (analysisDataList.any((d) => d.ticker == cStock.ticker)) continue;
        try {
          // Fiyatlari guncelle (TL/gram cevirimi ile)
          await _priceRepo.fetchAndSaveCommodityPrices(cStock.ticker, cStock.id!, force: true);
          final prices = await _priceRepo.getDailyPrices(cStock.id!);
          debugPrint('[AI] Emtia ${cStock.ticker}: ${prices.length} fiyat');
          if (prices.length < 10) {
            debugPrint('[AI] Emtia ${cStock.ticker}: yetersiz fiyat, atlaniyor');
            continue;
          }

          // Indikator hesapla (emtia icin 201 fiyat gerekebilir)
          final indicators = _indicatorCalc.calculate(prices, cStock.id!);
          if (indicators.isNotEmpty) {
            await _analysisRepo.saveIndicators(indicators);
          }

          final latestIndicator = await _analysisRepo.getLatestIndicator(cStock.id!);
          final latestPrice = prices.isNotEmpty ? prices.first : null;
          if (latestIndicator == null || latestPrice == null) {
            // Indikator yoksa bile temel fiyat verisiyle ekle
            debugPrint('[AI] Emtia ${cStock.ticker}: indikator yok, temel veriyle ekleniyor');
            commodityStocksList.add(cStock);
            analysisDataList.add(StockAnalysisData(
              ticker: cStock.ticker,
              name: cStock.name,
              sector: cStock.sector,
              close: prices.first.close,
              changePercent: prices.length > 1
                  ? ((prices[0].close - prices[1].close) / prices[1].close) * 100
                  : 0,
              volume: prices.first.volume,
              avgVolume20: 0,
              isInPortfolio: false,
              passedFilter: false,
              isCommodity: true,
              recentCloses: prices.take(10).map((p) => p.close).toList(),
              recentVolumes: prices.take(10).map((p) => p.volume).toList(),
            ));
            debugPrint('[AI] Emtia eklendi (temel): ${cStock.ticker}');
            continue;
          }

          final recentIndicators = await _analysisRepo.getIndicatorsForStock(cStock.id!);
          final recent10Ind = recentIndicators.take(10).toList();
          final recent10Prices = prices.take(10).toList();
          final adxPrev = recent10Ind.length > 1 ? recent10Ind[1].adx : null;
          final weeklyData = _computeWeeklyIndicators(prices);
          final derived = _computeDerivedFields(recentIndicators, prices);
          final fib = await _analysisRepo.getFibonacci(cStock.id!);

          // Onceki analiz
          final AiAnalysis? prevAnalysis;
          if (analysisType == 'SAATLIK') {
            prevAnalysis = await _analysisRepo.getTodayDailyAnalysis(cStock.id!);
          } else {
            prevAnalysis = await _analysisRepo.getLatestAiAnalysis(cStock.id!);
          }

          // Saatlik mumlar
          List<HourlyCandle>? hourlyCandles;
          if (analysisType == 'SAATLIK') {
            try {
              final yahooApi = YahooFinanceApi();
              final hourlyPrices = await yahooApi.fetchPrices(
                  cStock.ticker, cStock.id!, interval: '60m', range: '1d');
              if (hourlyPrices.isNotEmpty) {
                hourlyCandles = hourlyPrices.map((p) => HourlyCandle(
                  timestamp: p.date, open: p.open, high: p.high,
                  low: p.low, close: p.close, volume: p.volume,
                )).toList();
              }
            } catch (_) {}
          }

          commodityStocksList.add(cStock);
          analysisDataList.add(StockAnalysisData(
            ticker: cStock.ticker,
            name: cStock.name,
            sector: cStock.sector,
            close: latestPrice.close,
            changePercent: prices.length > 1
                ? ((prices[0].close - prices[1].close) / prices[1].close) * 100
                : 0,
            volume: latestPrice.volume,
            avgVolume20: prices.take(AppConfig.avgVolumePeriod).isEmpty ? 0
                : (prices.take(AppConfig.avgVolumePeriod).map((p) => p.volume).reduce((a, b) => a + b) ~/
                    prices.take(AppConfig.avgVolumePeriod).length),
            rsi: latestIndicator.rsi,
            macd: latestIndicator.macd,
            macdSignal: latestIndicator.macdSignal,
            macdHistogram: latestIndicator.macdHistogram,
            bbUpper: latestIndicator.bbUpper,
            bbMiddle: latestIndicator.bbMiddle,
            bbLower: latestIndicator.bbLower,
            bbPercentB: latestIndicator.bbPercentB,
            obv: latestIndicator.obv,
            sma20: latestIndicator.sma20,
            sma50: latestIndicator.sma50,
            sma200: latestIndicator.sma200,
            atr: latestIndicator.atr,
            technicalScore: latestIndicator.technicalScore,
            fibHigh: fib?.swingHighPrice,
            fibLow: fib?.swingLowPrice,
            fib236: fib?.level236,
            fib382: fib?.level382,
            fib500: fib?.level500,
            fib618: fib?.level618,
            previousSummary: prevAnalysis?.summary,
            previousSignal: prevAnalysis?.signal,
            isInPortfolio: false,
            passedFilter: false,
            isCommodity: true,
            recentCloses: recent10Prices.map((p) => p.close).toList(),
            recentRsi: recent10Ind.map((i) => i.rsi).toList(),
            recentMacdHist: recent10Ind.map((i) => i.macdHistogram).toList(),
            recentVolumes: recent10Prices.map((p) => p.volume).toList(),
            adx: latestIndicator.adx,
            adxPrev: adxPrev,
            plusDi: latestIndicator.plusDi,
            minusDi: latestIndicator.minusDi,
            weeklySma20: weeklyData['sma20'] as double?,
            weeklySma50: weeklyData['sma50'] as double?,
            weeklyRsi: weeklyData['rsi'] as double?,
            weeklyTrend: weeklyData['trend'] as String?,
            obvMa20: derived['obvMa20'] as double?,
            obvTrend: derived['obvTrend'] as String?,
            obvDivergence: derived['obvDivergence'] as bool?,
            obvDivergenceType: derived['obvDivergenceType'] as String?,
            bbWidth: derived['bbWidth'] as double?,
            bbWidthTrend: derived['bbWidthTrend'] as String?,
            bbSqueeze: derived['bbSqueeze'] as bool?,
            ema9: derived['ema9'] as double?,
            ema21: derived['ema21'] as double?,
            swingHigh20: derived['swingHigh20'] as double?,
            swingLow20: derived['swingLow20'] as double?,
            bist100Change: bist100Change,
            hourlyCandles: hourlyCandles,
          ));
          debugPrint('[AI] Emtia eklendi: ${cStock.ticker}');
        } catch (e) {
          debugPrint('[AI] Emtia veri hatasi (${cStock.ticker}): $e');
        }
      }

      // Batch halinde gonder - token limiti asmamak icin
      debugPrint('[AI] Toplam analysisDataList: ${analysisDataList.length} (${analysisDataList.map((d) => d.ticker).join(", ")})');
      const batchSize = AppConfig.geminiBatchSize;
      int savedCount = 0;
      for (int batchStart = 0; batchStart < analysisDataList.length; batchStart += batchSize) {
        // Batch arasi bekleme (rate limit koruması - ilk batch haric)
        if (batchStart > 0) {
          debugPrint('[AI] Rate limit koruması: 15 saniye bekleniyor...');
          progressMessage = 'Rate limit bekleniyor...';
          notifyListeners();
          await Future.delayed(const Duration(seconds: 15));
        }

        final batchEnd = min(batchStart + batchSize, analysisDataList.length);
        final batch = analysisDataList.sublist(batchStart, batchEnd);

        final userPrompt = useMorningPrompt
            ? _promptBuilder.buildMorningPrompt(batch, agenda: agenda)
            : _promptBuilder.buildIntradayPrompt(batch, agenda: agenda);
        debugPrint('[AI] Batch ${batchStart ~/ batchSize + 1}: ${batch.length} hisse gonderiliyor...');
        progressMessage = 'AI analizi ${batchStart + 1}-$batchEnd / ${analysisDataList.length}...';
        notifyListeners();

        // Prompt'u kaydet
        if (allPrompts.isNotEmpty) allPrompts.write('\n\n--- BATCH ${batchStart ~/ batchSize + 1} ---\n\n');
        allPrompts.write(userPrompt);

        final responseText =
            await client.generate(PromptBuilder.systemPrompt, userPrompt);

        if (responseText == null || responseText.isEmpty) {
          debugPrint('[AI] HATA: Gemini bos yanit dondurdu (batch ${batchStart ~/ batchSize + 1})');
          if (allResponses.isNotEmpty) allResponses.write('\n\n');
          allResponses.write('[BATCH ${batchStart ~/ batchSize + 1}: BOS YANIT]');
          continue;
        }

        // Response'u kaydet
        if (allResponses.isNotEmpty) allResponses.write('\n\n--- BATCH ${batchStart ~/ batchSize + 1} ---\n\n');
        allResponses.write(responseText);

        debugPrint('[AI] Gemini yanit: ${responseText.length} karakter');
        final results = _responseParser.parse(responseText);
        debugPrint('[AI] Parse: ${results.length} hisse');

        for (final result in results) {
          var stock = filtered
              .where((f) => f.stock.ticker == result.ticker)
              .firstOrNull
              ?.stock;
          // Emtia ticker'i olabilir
          stock ??= commodityStocksList
              .where((s) => s.ticker == result.ticker)
              .firstOrNull;
          if (stock == null) {
            debugPrint('[AI] UYARI: ${result.ticker} ticker eslesmedi');
            continue;
          }

          await _analysisRepo.saveAiAnalysis(AiAnalysis(
            stockId: stock.id!,
            datetime: DateTime.now().millisecondsSinceEpoch,
            analysisType: analysisType,
            summary: result.summary,
            signal: result.signal,
            confidence: result.confidence,
            riskReward: result.riskReward,
            scenarioStatus: result.scenarioStatus,
            sessionId: sessionId,
            intradayNotes: result.intradayPlan,
          ));
          savedCount++;
          allSignals.add(AnalysisSignalInfo(
            ticker: result.ticker,
            signal: result.signal,
            confidence: result.confidence,
          ));
        }
      }
      debugPrint('[AI] Toplam $savedCount analiz kaydedildi');

      // Session'a prompt/response ve gercek stock count kaydet
      await _analysisRepo.updateSessionTexts(
          sessionId, allPrompts.toString(), allResponses.toString());
      await _analysisRepo.updateSessionStockCount(sessionId, savedCount);

      // Bildirim: GUNLUK her zaman, SAATLIK her 2'de 1
      if (allSignals.isNotEmpty) {
        if (analysisType == 'GUNLUK') {
          await NotificationService.instance.showDailyAnalysisNotification(
            signals: allSignals,
          );
        } else {
          await NotificationService.instance.showHourlyAnalysisNotification(
            signals: allSignals,
          );
        }
      }

      if (savedCount == 0) {
        lastError = 'AI analizi sonuc vermedi.';
        notifyListeners();
      }
    } catch (e) {
      debugPrint('[AI] HATA: $e');
      lastError = 'AI analizi hatasi: $e';
      notifyListeners();
    }
  }

  // ==================== v3: WEEKLY INDICATORS ====================

  Map<String, dynamic> _computeWeeklyIndicators(List<DailyPrice> dailyPrices) {
    // dailyPrices is sorted DESC (newest first)
    if (dailyPrices.length < 60) {
      return {'sma20': null, 'sma50': null, 'rsi': null, 'trend': null};
    }

    // Group daily prices into weekly candles
    final reversed = dailyPrices.reversed.toList(); // oldest first
    final weeklyCloses = <double>[];

    // Group by ISO week
    int? currentWeek;
    int? currentYear;
    double? lastClose;

    for (final p in reversed) {
      final date = DateTime.fromMillisecondsSinceEpoch(p.date);
      final week = _isoWeekNumber(date);
      final year = date.year;

      if (currentWeek != week || currentYear != year) {
        if (lastClose != null) weeklyCloses.add(lastClose);
        currentWeek = week;
        currentYear = year;
      }
      lastClose = p.close;
    }
    if (lastClose != null) weeklyCloses.add(lastClose);

    if (weeklyCloses.length < 50) {
      return {'sma20': null, 'sma50': null, 'rsi': null, 'trend': null};
    }

    // Compute weekly SMA20 and SMA50
    final sma20 = _computeSma(weeklyCloses, 20);
    final sma50 = _computeSma(weeklyCloses, 50);

    // Compute weekly RSI14
    final rsi = _computeRsi(weeklyCloses, 14);

    // Determine trend
    String? trend;
    final price = weeklyCloses.last;
    if (sma20 != null && sma50 != null) {
      if (price > sma20 && sma20 > sma50) {
        trend = 'UPTREND';
      } else if (price < sma20 && sma20 < sma50) {
        trend = 'DOWNTREND';
      } else if (price > sma20 && sma20 < sma50) {
        trend = 'EARLY_RECOVERY';
      } else if (price < sma20 && sma20 > sma50) {
        trend = 'EARLY_WEAKNESS';
      } else {
        trend = 'SIDEWAYS';
      }
    }

    return {
      'sma20': sma20,
      'sma50': sma50,
      'rsi': rsi,
      'trend': trend,
    };
  }

  int _isoWeekNumber(DateTime date) {
    final dayOfYear = date.difference(DateTime(date.year, 1, 1)).inDays;
    final weekday = date.weekday; // 1=Mon, 7=Sun
    return ((dayOfYear - weekday + 10) / 7).floor();
  }

  double? _computeSma(List<double> values, int period) {
    if (values.length < period) return null;
    double sum = 0;
    for (int i = values.length - period; i < values.length; i++) {
      sum += values[i];
    }
    return sum / period;
  }

  double? _computeRsi(List<double> values, int period) {
    if (values.length <= period) return null;
    double gainSum = 0, lossSum = 0;
    for (int i = values.length - period; i < values.length; i++) {
      final change = values[i] - values[i - 1];
      if (change > 0) {
        gainSum += change;
      } else {
        lossSum += change.abs();
      }
    }
    final avgGain = gainSum / period;
    final avgLoss = lossSum / period;
    if (avgLoss == 0) return 100.0;
    return 100.0 - (100.0 / (1.0 + avgGain / avgLoss));
  }

  // ==================== v3: DERIVED FIELDS ====================

  Map<String, dynamic> _computeDerivedFields(
      List<Indicator> indicators, List<DailyPrice> prices) {
    final result = <String, dynamic>{
      'obvMa20': null,
      'obvTrend': null,
      'obvDivergence': null,
      'obvDivergenceType': null,
      'bbWidth': null,
      'bbWidthTrend': null,
      'bbSqueeze': null,
      'ema9': null,
      'ema21': null,
      'swingHigh20': null,
      'swingLow20': null,
    };

    if (indicators.isEmpty) return result;

    // OBV MA20 + Trend
    if (indicators.length >= 20) {
      final obvValues = indicators.take(20).map((i) => i.obv).toList();
      if (obvValues.every((v) => v != null)) {
        final obvSum = obvValues.fold<double>(0, (sum, v) => sum + v!);
        result['obvMa20'] = obvSum / 20;
      }
    }

    final latestObv = indicators.first.obv;
    final prev5Obv = indicators.length > 5 ? indicators[5].obv : null;
    if (latestObv != null && prev5Obv != null) {
      result['obvTrend'] = latestObv > prev5Obv ? 'RISING' : 'FALLING';
    }

    // OBV Divergence
    if (prices.length >= 5 && indicators.length >= 5) {
      final priceRising = prices[0].close > prices[4].close;
      final obvRising = latestObv != null && prev5Obv != null && latestObv > prev5Obv;
      if (priceRising && !obvRising) {
        result['obvDivergence'] = true;
        result['obvDivergenceType'] = 'NEGATIVE';
      } else if (!priceRising && obvRising) {
        result['obvDivergence'] = true;
        result['obvDivergenceType'] = 'POSITIVE';
      } else {
        result['obvDivergence'] = false;
      }
    }

    // BB Width + Trend + Squeeze
    final latestInd = indicators.first;
    if (latestInd.bbUpper != null && latestInd.bbLower != null && latestInd.bbMiddle != null) {
      final width = (latestInd.bbUpper! - latestInd.bbLower!) / latestInd.bbMiddle!;
      result['bbWidth'] = width;

      if (indicators.length >= 20) {
        final prevWidth = indicators.length > 5 &&
                indicators[5].bbUpper != null &&
                indicators[5].bbLower != null &&
                indicators[5].bbMiddle != null &&
                indicators[5].bbMiddle! > 0
            ? (indicators[5].bbUpper! - indicators[5].bbLower!) / indicators[5].bbMiddle!
            : null;
        if (prevWidth != null) {
          if (width < prevWidth * 0.85) {
            result['bbWidthTrend'] = 'NARROWING';
          } else if (width > prevWidth * 1.15) {
            result['bbWidthTrend'] = 'WIDENING';
          } else {
            result['bbWidthTrend'] = 'STABLE';
          }
        }

        // Squeeze: BB width in bottom 20% of last 20 periods
        final widths = <double>[];
        for (int i = 0; i < 20 && i < indicators.length; i++) {
          final ind = indicators[i];
          if (ind.bbUpper != null && ind.bbLower != null && ind.bbMiddle != null && ind.bbMiddle! > 0) {
            widths.add((ind.bbUpper! - ind.bbLower!) / ind.bbMiddle!);
          }
        }
        if (widths.length >= 10) {
          final sortedWidths = List.of(widths)..sort();
          final p20 = sortedWidths[(sortedWidths.length * 0.2).floor()];
          result['bbSqueeze'] = width <= p20;
        }
      }
    }

    // EMA 9 and 21 from recent closes
    if (prices.length >= 21) {
      final closes = prices.reversed.map((p) => p.close).toList(); // oldest first
      result['ema9'] = _computeEma(closes, 9);
      result['ema21'] = _computeEma(closes, 21);
    }

    // Swing High/Low 20
    if (prices.length >= 20) {
      final recent20 = prices.take(20);
      result['swingHigh20'] = recent20.map((p) => p.high).reduce(max);
      result['swingLow20'] = recent20.map((p) => p.low).reduce(min);
    }

    return result;
  }

  double? _computeEma(List<double> values, int period) {
    if (values.length < period) return null;
    double sum = 0;
    for (int i = 0; i < period; i++) {
      sum += values[i];
    }
    double ema = sum / period;
    final multiplier = 2.0 / (period + 1);
    for (int i = period; i < values.length; i++) {
      ema = (values[i] - ema) * multiplier + ema;
    }
    return ema;
  }

  /// Load summary data for active + portfolio stocks
  Future<void> _loadStockSummaries() async {
    final summaries = <int, StockSummary>{};

    final stocksToLoad = <Stock>{};
    stocksToLoad.addAll(activeStocks);
    stocksToLoad.addAll(portfolioStocks);

    for (final stock in stocksToLoad) {
      try {
        final prices = await _priceRepo.getDailyPrices(stock.id!, limit: AppConfig.summaryPriceLimit);
        if (prices.isEmpty) continue;

        final latest = prices.first;
        final prev = prices.length > 1 ? prices[1] : null;
        final changePercent = (prev != null && prev.close != 0)
            ? ((latest.close - prev.close) / prev.close) * 100
            : 0.0;

        final sparkline = prices
            .take(AppConfig.sparklinePoints)
            .toList()
            .reversed
            .map((p) => p.close)
            .toList();

        final analysis =
            await _analysisRepo.getLatestAiAnalysis(stock.id!);
        final indicator =
            await _analysisRepo.getLatestIndicator(stock.id!);

        summaries[stock.id!] = StockSummary(
          price: latest.close,
          changePercent: changePercent,
          volume: latest.volume,
          sparkline: sparkline,
          signal: analysis?.signal,
          confidence: analysis?.confidence,
          technicalScore: indicator?.technicalScore,
        );
      } catch (_) {}
    }

    stockSummaries = summaries;
  }

}

class StockSummary {
  final double price;
  final double changePercent;
  final int volume;
  final List<double> sparkline;
  final String? signal;
  final double? confidence;
  final double? technicalScore;

  StockSummary({
    required this.price,
    required this.changePercent,
    required this.volume,
    required this.sparkline,
    this.signal,
    this.confidence,
    this.technicalScore,
  });
}
