class AppConfig {
  static const int windowDays = 250; // SMA200 icin yeterli (~1 yil islem gunu)
  static const int marketOpenHour = 9;
  static const int marketOpenMinute = 50;
  static const int marketCloseHour = 18;
  static const int marketCloseMinute = 10;
  static const int intradayIntervalMinutes = 15;
  static const int maxActiveStocks = 50;
  static const int maxCommentsPerStock = 10; // 15 -> 10 (disk tasarrufu)

  // Data retention
  static const int analysisRetentionDays = 14; // AI analiz saklama suresi
  static const int transactionRetentionDays = 365; // Islem gecmisi
  static const int sparklinePoints = 7; // Liste gorunumundeki mini grafik
  static const int summaryPriceLimit = 10; // Summary icin cekilecek fiyat
  static const int minPricesForIndicator = 50; // Indikator hesaplama icin min fiyat
  static const int avgVolumePeriod = 20; // Ortalama hacim penceresi
  static const int geminiBatchSize = 10; // Gemini API batch boyutu
  static const int maxPortfolioStocks = 3; // AI portfoy max hisse sayisi
  static const int morningAnalysisHour = 9;
  static const int morningAnalysisMinute = 30;

  // Technical analysis
  static const int rsiPeriod = 14;
  static const double rsiOversold = 30.0;
  static const double rsiOverbought = 70.0;
  static const int bollingerPeriod = 20;
  static const double bollingerStdDev = 2.0;
  static const int macdFast = 12;
  static const int macdSlow = 26;
  static const int macdSignalPeriod = 9;
  static const int atrPeriod = 14;
  static const int adxPeriod = 14;
  static const double fibonacciAtrMultiplier = 2.0;
  static const int smaShort = 5;
  static const int smaMedium = 20;
  static const int smaLong = 50;
  static const int smaVeryLong = 200;

  // Filter thresholds
  static const double technicalScoreThreshold = 65.0;
  static const int minDailyVolumeTl = 10000000;
  static const double rsiFilterMin = 40.0;
  static const double rsiFilterMax = 65.0;
  static const double bollingerPercentBEntry = 0.3;

  // Score weights
  static const double weightRsi = 0.20;
  static const double weightMacd = 0.20;
  static const double weightBollinger = 0.15;
  static const double weightVolume = 0.15;
  static const double weightTrend = 0.20;
  static const double weightCandle = 0.10;

  // Gemini AI
  static const String geminiModel = 'gemini-3-flash-preview';
  static const double geminiTemperature = 0.3;
  static const int geminiMaxOutputTokens = 16384;

  // Notifications
  static const double minConfidenceForNotification = 0.6;
  static const double minConfidenceForStrongSignal = 0.3;

  // Commodities (emtialar)
  static const String commoditySector = 'Emtia';
  static const Map<String, String> commodityTickers = {
    'GC=F': 'Gram Altin',
    'SI=F': 'Gram Gumus',
  };
  static const String usdTryTicker = 'USDTRY=X';
  static const double troyOunceToGram = 31.1035;
  static bool isCommodityTicker(String ticker) =>
      commodityTickers.containsKey(ticker);

  // News / Agenda
  static const int newsMaxItems = 10;
  static const int newsMaxAgeHours = 24;
  static const int agendaCacheMinutes = 60;
  static const int newsTranslationMaxTokens = 4096;
  static const int newsMaxRssItems = 30;
  static const int newsSourceDelayMs = 300;

  // Network
  static const String yahooBaseUrl = 'https://query1.finance.yahoo.com';
  static const String yahooTickerSuffix = '.IS';
  static const String bist100Ticker = 'XU100';
  static const String twelveDataBaseUrl = 'https://api.twelvedata.com';
  static const Duration connectTimeout = Duration(seconds: 10);
  static const Duration readTimeout = Duration(seconds: 15);
}
