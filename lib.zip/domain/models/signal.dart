enum Signal {
  gucluAl('GUCLU_AL', 'Guclu Al', true),
  al('AL', 'Al', true),
  izle('IZLE', 'Izle', false),
  tut('TUT', 'Tut', false),
  kismiSat('KISMI_SAT', 'Kismi Sat', true),
  sat('SAT', 'Sat', true),
  acilSat('ACIL_SAT', 'Acil Sat', true);

  final String code;
  final String label;
  final bool triggersNotification;

  const Signal(this.code, this.label, this.triggersNotification);

  static Signal? fromString(String value) {
    final upper = value.toUpperCase().trim();
    return Signal.values
        .cast<Signal?>()
        .firstWhere((s) => s?.code == upper, orElse: () => null);
  }

  static const validSignals = {
    'GUCLU_AL',
    'AL',
    'IZLE',
    'TUT',
    'KISMI_SAT',
    'SAT',
    'ACIL_SAT',
  };

  static const buySignals = {'GUCLU_AL', 'AL'};

  static const sellSignals = {'KISMI_SAT', 'SAT', 'ACIL_SAT'};

  static bool isValid(String signal) =>
      validSignals.contains(signal.toUpperCase().trim());

  static bool isBuy(String signal) =>
      buySignals.contains(signal.toUpperCase().trim());
}

enum PromptType {
  sabahAnalizi('low'),
  gunIci('minimal'),
  portfoy('low'),
  gunSonu('minimal');

  final String thinkingLevel;

  const PromptType(this.thinkingLevel);
}
