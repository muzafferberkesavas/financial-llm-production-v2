import '../../config/app_config.dart';
import '../../data/models/stock.dart';
import '../../data/models/daily_price.dart';
import '../../data/models/indicator.dart';

class StockWithIndicators {
  final Stock stock;
  final Indicator indicator;
  final DailyPrice latestPrice;

  StockWithIndicators({
    required this.stock,
    required this.indicator,
    required this.latestPrice,
  });
}

class FilterPipeline {
  List<StockWithIndicators> execute(List<StockWithIndicators> stocks) {
    var result = stocks;
    result = _liquidityFilter(result);
    result = _trendFilter(result);
    result = _momentumFilter(result);
    result = _entryPointFilter(result);
    return result;
  }

  List<StockWithIndicators> _liquidityFilter(
      List<StockWithIndicators> stocks) {
    return stocks.where((item) {
      final dailyVolumeTl = item.latestPrice.volume * item.latestPrice.close;
      return dailyVolumeTl >= AppConfig.minDailyVolumeTl;
    }).toList();
  }

  List<StockWithIndicators> _trendFilter(
      List<StockWithIndicators> stocks) {
    return stocks.where((item) {
      final sma50 = item.indicator.sma50;
      final sma200 = item.indicator.sma200;
      final price = item.latestPrice.close;
      return sma50 != null &&
          sma200 != null &&
          price > sma200 &&
          sma50 > sma200;
    }).toList();
  }

  List<StockWithIndicators> _momentumFilter(
      List<StockWithIndicators> stocks) {
    return stocks.where((item) {
      final rsi = item.indicator.rsi;
      final hist = item.indicator.macdHistogram;
      return rsi != null &&
          hist != null &&
          rsi >= AppConfig.rsiFilterMin &&
          rsi <= AppConfig.rsiFilterMax &&
          hist > 0;
    }).toList();
  }

  List<StockWithIndicators> _entryPointFilter(
      List<StockWithIndicators> stocks) {
    return stocks.where((item) {
      final bbPB = item.indicator.bbPercentB;
      final score = item.indicator.technicalScore ?? 0;
      final bollingerEntry =
          bbPB != null && bbPB < AppConfig.bollingerPercentBEntry;
      final scoreEntry = score >= AppConfig.technicalScoreThreshold;
      return bollingerEntry || scoreEntry;
    }).toList();
  }
}
