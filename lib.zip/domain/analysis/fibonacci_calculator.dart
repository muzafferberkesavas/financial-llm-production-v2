import '../../config/app_config.dart';
import '../../data/models/daily_price.dart';
import '../../data/models/fibonacci.dart';

class FibonacciCalculator {
  FibonacciData? calculate(
      List<DailyPrice> prices, List<double?> atrValues, int stockId) {
    if (prices.length < AppConfig.windowDays) return null;

    // prices ve atrValues giriş sırası: yeni→eski (DB'den DESC gelir)
    // Swing detection eski→yeni sırada çalışmalı, ikisini de reverse et
    final sortedPrices = prices.reversed.toList();
    final sortedAtr = atrValues.reversed.toList();

    // Son windowDays kadar veriyi al (en güncel pencere)
    final windowPrices = sortedPrices.length > AppConfig.windowDays
        ? sortedPrices.sublist(sortedPrices.length - AppConfig.windowDays)
        : sortedPrices;
    final windowAtr = sortedAtr.length > AppConfig.windowDays
        ? sortedAtr.sublist(sortedAtr.length - AppConfig.windowDays)
        : sortedAtr;

    final swings = _detectSwings(windowPrices, windowAtr);
    if (swings.length < 2) return null;

    final highs = swings.where((s) => s.isHigh).toList();
    final lows = swings.where((s) => !s.isHigh).toList();
    if (highs.isEmpty || lows.isEmpty) return null;

    final highSwing = highs.reduce((a, b) => a.price > b.price ? a : b);
    final lowSwing = lows.reduce((a, b) => a.price < b.price ? a : b);
    final diff = highSwing.price - lowSwing.price;
    if (diff <= 0) return null;

    // Trend yönü: high tarihi low tarihinden önceyse düşüş trendi
    final isDowntrend = highSwing.date < lowSwing.date;

    // Düşüş trendi (high önce → low sonra): bounce seviyeleri low'dan yukarı
    // Yükseliş trendi (low önce → high sonra): pullback seviyeleri high'dan aşağı
    final double l236, l382, l500, l618, l786;
    if (isDowntrend) {
      l236 = lowSwing.price + diff * 0.236;
      l382 = lowSwing.price + diff * 0.382;
      l500 = lowSwing.price + diff * 0.500;
      l618 = lowSwing.price + diff * 0.618;
      l786 = lowSwing.price + diff * 0.786;
    } else {
      l236 = highSwing.price - diff * 0.236;
      l382 = highSwing.price - diff * 0.382;
      l500 = highSwing.price - diff * 0.500;
      l618 = highSwing.price - diff * 0.618;
      l786 = highSwing.price - diff * 0.786;
    }

    return FibonacciData(
      stockId: stockId,
      swingHighPrice: highSwing.price,
      swingHighDate: highSwing.date,
      swingLowPrice: lowSwing.price,
      swingLowDate: lowSwing.date,
      level236: l236,
      level382: l382,
      level500: l500,
      level618: l618,
      level786: l786,
      renewalCountdown: 30,
      lastCalculated: DateTime.now().millisecondsSinceEpoch,
      isDowntrend: isDowntrend,
    );
  }

  List<_SwingPoint> _detectSwings(
      List<DailyPrice> prices, List<double?> atr) {
    if (prices.length < 3) return [];
    final swings = <_SwingPoint>[];
    _SwingPoint? lastSwing;

    for (int i = 1; i < prices.length - 1; i++) {
      final threshold = (atr.length > i ? atr[i] : (atr.isNotEmpty ? atr.last : null)) ?? 0;
      final atrThreshold = threshold * AppConfig.fibonacciAtrMultiplier;

      if (prices[i].high > prices[i - 1].high &&
          prices[i].high > prices[i + 1].high) {
        final isSignificant = lastSwing == null ||
            (prices[i].high - lastSwing.price).abs() >= atrThreshold;
        if (isSignificant) {
          final point = _SwingPoint(prices[i].high, prices[i].date, true);
          if (lastSwing == null || !lastSwing.isHigh) {
            swings.add(point);
            lastSwing = point;
          } else if (prices[i].high > lastSwing.price) {
            swings[swings.length - 1] = point;
            lastSwing = point;
          }
        }
      }

      if (prices[i].low < prices[i - 1].low &&
          prices[i].low < prices[i + 1].low) {
        final isSignificant = lastSwing == null ||
            (prices[i].low - lastSwing.price).abs() >= atrThreshold;
        if (isSignificant) {
          final point = _SwingPoint(prices[i].low, prices[i].date, false);
          if (lastSwing == null || lastSwing.isHigh) {
            swings.add(point);
            lastSwing = point;
          } else if (prices[i].low < lastSwing.price) {
            swings[swings.length - 1] = point;
            lastSwing = point;
          }
        }
      }
    }
    return swings;
  }
}

class _SwingPoint {
  final double price;
  final int date;
  final bool isHigh;

  _SwingPoint(this.price, this.date, this.isHigh);
}
