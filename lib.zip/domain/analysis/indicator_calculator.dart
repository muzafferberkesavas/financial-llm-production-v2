import 'dart:math';

import '../../config/app_config.dart';
import '../../data/models/daily_price.dart';
import '../../data/models/indicator.dart';

class IndicatorCalculator {
  List<Indicator> calculate(List<DailyPrice> prices, int stockId) {
    if (prices.length < AppConfig.smaVeryLong + 1) return [];

    final sorted = prices.reversed.toList();
    final closes = sorted.map((p) => p.close).toList();
    final highs = sorted.map((p) => p.high).toList();
    final lows = sorted.map((p) => p.low).toList();
    final volumes = sorted.map((p) => p.volume.toDouble()).toList();

    final rsiValues = _calculateRSI(closes, AppConfig.rsiPeriod);
    final macdResult = _calculateMACD(
        closes, AppConfig.macdFast, AppConfig.macdSlow, AppConfig.macdSignalPeriod);
    final bbResult = _calculateBollinger(
        closes, AppConfig.bollingerPeriod, AppConfig.bollingerStdDev);
    final obvValues = _calculateOBV(closes, volumes);
    final sma5 = _calculateSMA(closes, AppConfig.smaShort);
    final sma20 = _calculateSMA(closes, AppConfig.smaMedium);
    final sma50 = _calculateSMA(closes, AppConfig.smaLong);
    final sma200 = _calculateSMA(closes, AppConfig.smaVeryLong);
    final ema12 = _calculateEMA(closes, 12);
    final ema26 = _calculateEMA(closes, 26);
    final atrValues =
        _calculateATR(highs, lows, closes, AppConfig.atrPeriod);
    final adxResult = _calculateADX(highs, lows, closes, AppConfig.adxPeriod);

    final indicators = <Indicator>[];
    final startIndex = AppConfig.smaVeryLong;

    for (int i = startIndex; i < sorted.length; i++) {
      final technicalScore = _calculateTechnicalScore(
        rsi: rsiValues[i],
        macdHistogram: macdResult.histogram[i],
        macd: macdResult.macd[i],
        macdSignal: macdResult.signal[i],
        bbPercentB: bbResult.percentB[i],
        sma20: sma20[i],
        sma50: sma50[i],
        sma200: sma200[i],
        ema12: ema12[i],
        ema26: ema26[i],
        close: closes[i],
      );

      indicators.add(Indicator(
        stockId: stockId,
        date: sorted[i].date,
        rsi: rsiValues[i],
        macd: macdResult.macd[i],
        macdSignal: macdResult.signal[i],
        macdHistogram: macdResult.histogram[i],
        bbUpper: bbResult.upper[i],
        bbMiddle: bbResult.middle[i],
        bbLower: bbResult.lower[i],
        bbPercentB: bbResult.percentB[i],
        obv: obvValues[i],
        sma5: sma5[i],
        sma20: sma20[i],
        sma50: sma50[i],
        sma200: sma200[i],
        ema12: ema12[i],
        ema26: ema26[i],
        atr: atrValues[i],
        adx: adxResult.adx[i],
        plusDi: adxResult.plusDi[i],
        minusDi: adxResult.minusDi[i],
        technicalScore: technicalScore,
      ));
    }

    return indicators;
  }

  List<double?> _calculateRSI(List<double> closes, int period) {
    final result = List<double?>.filled(closes.length, null);
    if (closes.length <= period) return result;

    double gainSum = 0, lossSum = 0;
    for (int i = 1; i <= period; i++) {
      final change = closes[i] - closes[i - 1];
      if (change > 0) {
        gainSum += change;
      } else {
        lossSum += change.abs();
      }
    }

    double avgGain = gainSum / period;
    double avgLoss = lossSum / period;
    result[period] = avgLoss == 0
        ? 100.0
        : 100.0 - (100.0 / (1.0 + avgGain / avgLoss));

    for (int i = period + 1; i < closes.length; i++) {
      final change = closes[i] - closes[i - 1];
      final gain = change > 0 ? change : 0.0;
      final loss = change < 0 ? change.abs() : 0.0;
      avgGain = (avgGain * (period - 1) + gain) / period;
      avgLoss = (avgLoss * (period - 1) + loss) / period;
      result[i] = avgLoss == 0
          ? 100.0
          : 100.0 - (100.0 / (1.0 + avgGain / avgLoss));
    }
    return result;
  }

  _MACDResult _calculateMACD(
      List<double> closes, int fast, int slow, int signalPeriod) {
    final emaFast = _calculateEMA(closes, fast);
    final emaSlow = _calculateEMA(closes, slow);

    final macdLine = List<double?>.filled(closes.length, null);
    for (int i = 0; i < closes.length; i++) {
      if (emaFast[i] != null && emaSlow[i] != null) {
        macdLine[i] = emaFast[i]! - emaSlow[i]!;
      }
    }

    // Signal line = EMA of MACD line
    final signalLine = List<double?>.filled(closes.length, null);
    final histogram = List<double?>.filled(closes.length, null);
    double? prevSignal;
    final multiplier = 2.0 / (signalPeriod + 1);
    int count = 0;
    double sum = 0;

    for (int i = 0; i < closes.length; i++) {
      if (macdLine[i] == null) continue;
      if (prevSignal == null) {
        count++;
        sum += macdLine[i]!;
        if (count == signalPeriod) {
          prevSignal = sum / signalPeriod;
          signalLine[i] = prevSignal;
          histogram[i] = macdLine[i]! - prevSignal;
        }
      } else {
        prevSignal =
            (macdLine[i]! - prevSignal) * multiplier + prevSignal;
        signalLine[i] = prevSignal;
        histogram[i] = macdLine[i]! - prevSignal;
      }
    }

    return _MACDResult(
        macd: macdLine, signal: signalLine, histogram: histogram);
  }

  _BollingerResult _calculateBollinger(
      List<double> closes, int period, double stdDevMultiplier) {
    final upper = List<double?>.filled(closes.length, null);
    final middle = List<double?>.filled(closes.length, null);
    final lower = List<double?>.filled(closes.length, null);
    final percentB = List<double?>.filled(closes.length, null);

    for (int i = period - 1; i < closes.length; i++) {
      final window = closes.sublist(i - period + 1, i + 1);
      final mean = window.reduce((a, b) => a + b) / period;
      final variance =
          window.map((v) => pow(v - mean, 2)).reduce((a, b) => a + b) /
              period;
      final stdDev = sqrt(variance);

      middle[i] = mean;
      upper[i] = mean + stdDevMultiplier * stdDev;
      lower[i] = mean - stdDevMultiplier * stdDev;

      final bandwidth = upper[i]! - lower[i]!;
      percentB[i] =
          bandwidth > 0 ? (closes[i] - lower[i]!) / bandwidth : 0.5;
    }

    return _BollingerResult(
        upper: upper, middle: middle, lower: lower, percentB: percentB);
  }

  List<double?> _calculateOBV(List<double> closes, List<double> volumes) {
    final result = List<double?>.filled(closes.length, null);
    if (closes.isEmpty) return result;
    result[0] = volumes[0];
    for (int i = 1; i < closes.length; i++) {
      final prev = result[i - 1] ?? 0;
      if (closes[i] > closes[i - 1]) {
        result[i] = prev + volumes[i];
      } else if (closes[i] < closes[i - 1]) {
        result[i] = prev - volumes[i];
      } else {
        result[i] = prev;
      }
    }
    return result;
  }

  List<double?> _calculateSMA(List<double> values, int period) {
    final result = List<double?>.filled(values.length, null);
    for (int i = period - 1; i < values.length; i++) {
      final window = values.sublist(i - period + 1, i + 1);
      result[i] = window.reduce((a, b) => a + b) / period;
    }
    return result;
  }

  List<double?> _calculateEMA(List<double> values, int period) {
    final result = List<double?>.filled(values.length, null);
    if (values.length < period) return result;

    // First EMA = SMA of first `period` values
    double sum = 0;
    for (int i = 0; i < period; i++) {
      sum += values[i];
    }
    double ema = sum / period;
    result[period - 1] = ema;

    final multiplier = 2.0 / (period + 1);
    for (int i = period; i < values.length; i++) {
      ema = (values[i] - ema) * multiplier + ema;
      result[i] = ema;
    }
    return result;
  }

  List<double?> _calculateATR(
      List<double> highs, List<double> lows, List<double> closes, int period) {
    final result = List<double?>.filled(closes.length, null);
    if (closes.length < 2) return result;

    final trueRanges = <double>[0]; // first has no previous close
    for (int i = 1; i < closes.length; i++) {
      final tr = [
        highs[i] - lows[i],
        (highs[i] - closes[i - 1]).abs(),
        (lows[i] - closes[i - 1]).abs(),
      ].reduce(max);
      trueRanges.add(tr);
    }

    if (trueRanges.length < period + 1) return result;

    double atrSum = 0;
    for (int i = 1; i <= period; i++) {
      atrSum += trueRanges[i];
    }
    double atr = atrSum / period;
    result[period] = atr;

    for (int i = period + 1; i < closes.length; i++) {
      atr = (atr * (period - 1) + trueRanges[i]) / period;
      result[i] = atr;
    }
    return result;
  }

  _ADXResult _calculateADX(
      List<double> highs, List<double> lows, List<double> closes, int period) {
    final length = closes.length;
    final adx = List<double?>.filled(length, null);
    final plusDi = List<double?>.filled(length, null);
    final minusDi = List<double?>.filled(length, null);

    if (length < period * 2 + 1) {
      return _ADXResult(adx: adx, plusDi: plusDi, minusDi: minusDi);
    }

    // Step 1: Calculate +DM and -DM
    final plusDm = List<double>.filled(length, 0);
    final minusDm = List<double>.filled(length, 0);
    final tr = List<double>.filled(length, 0);

    for (int i = 1; i < length; i++) {
      final upMove = highs[i] - highs[i - 1];
      final downMove = lows[i - 1] - lows[i];

      plusDm[i] = (upMove > downMove && upMove > 0) ? upMove : 0;
      minusDm[i] = (downMove > upMove && downMove > 0) ? downMove : 0;

      tr[i] = [
        highs[i] - lows[i],
        (highs[i] - closes[i - 1]).abs(),
        (lows[i] - closes[i - 1]).abs(),
      ].reduce(max);
    }

    // Step 2: Smooth with Wilder's smoothing (period-based)
    double smoothPlusDm = 0, smoothMinusDm = 0, smoothTr = 0;
    for (int i = 1; i <= period; i++) {
      smoothPlusDm += plusDm[i];
      smoothMinusDm += minusDm[i];
      smoothTr += tr[i];
    }

    // Step 3: Calculate +DI, -DI, DX
    final dx = <double>[];

    for (int i = period; i < length; i++) {
      if (i > period) {
        smoothPlusDm = smoothPlusDm - smoothPlusDm / period + plusDm[i];
        smoothMinusDm = smoothMinusDm - smoothMinusDm / period + minusDm[i];
        smoothTr = smoothTr - smoothTr / period + tr[i];
      }

      if (smoothTr > 0) {
        final pdi = (smoothPlusDm / smoothTr) * 100;
        final mdi = (smoothMinusDm / smoothTr) * 100;
        plusDi[i] = pdi;
        minusDi[i] = mdi;

        final diSum = pdi + mdi;
        if (diSum > 0) {
          dx.add(((pdi - mdi).abs() / diSum) * 100);
        } else {
          dx.add(0);
        }
      } else {
        plusDi[i] = 0;
        minusDi[i] = 0;
        dx.add(0);
      }
    }

    // Step 4: ADX = smoothed DX (Wilder's EMA of DX)
    if (dx.length >= period) {
      // First ADX = average of first `period` DX values
      double adxSum = 0;
      for (int i = 0; i < period; i++) {
        adxSum += dx[i];
      }
      double adxVal = adxSum / period;
      adx[period * 2 - 1] = adxVal;

      for (int i = period; i < dx.length; i++) {
        adxVal = (adxVal * (period - 1) + dx[i]) / period;
        final priceIdx = period + i;
        if (priceIdx < length) {
          adx[priceIdx] = adxVal;
        }
      }
    }

    return _ADXResult(adx: adx, plusDi: plusDi, minusDi: minusDi);
  }

  double _calculateTechnicalScore({
    double? rsi,
    double? macdHistogram,
    double? macd,
    double? macdSignal,
    double? bbPercentB,
    double? sma20,
    double? sma50,
    double? sma200,
    double? ema12,
    double? ema26,
    required double close,
  }) {
    double rsiScore = 50;
    if (rsi != null) {
      if (rsi >= 40 && rsi <= 65) {
        rsiScore = 70 + 30 * (1.0 - ((rsi - 52.5) / 12.5).abs());
      } else if (rsi < 30) {
        rsiScore = 30 + (rsi / 30) * 20;
      } else if (rsi > 70) {
        rsiScore = max(0, 50 - (rsi - 70) * 1.67);
      } else if (rsi >= 30 && rsi < 40) {
        rsiScore = 50 + (rsi - 30) / 10 * 20;
      } else {
        rsiScore = 70 - (rsi - 65) / 5 * 20;
      }
    }

    double macdScore = 50;
    if (macdHistogram != null && macd != null && macdSignal != null) {
      macdScore = 50 +
          (macdHistogram > 0 ? 25 : -15) +
          (macd > macdSignal ? 15 : -10) +
          (macd > 0 ? 10 : 0);
    }

    double bbScore = 50;
    if (bbPercentB != null) {
      if (bbPercentB < 0) {
        bbScore = 60;
      } else if (bbPercentB < 0.2) {
        bbScore = 70 + (0.2 - bbPercentB) / 0.2 * 15;
      } else if (bbPercentB <= 0.8) {
        bbScore = 50 + (0.5 - (bbPercentB - 0.5).abs()) * 40;
      } else if (bbPercentB > 1.0) {
        bbScore = 20;
      } else {
        bbScore = 40 - (bbPercentB - 0.8) / 0.2 * 20;
      }
    }

    double trendScore = 0;
    if (sma20 != null && close > sma20) trendScore += 20;
    if (sma50 != null && close > sma50) trendScore += 25;
    if (sma200 != null && close > sma200) trendScore += 25;
    if (sma50 != null && sma200 != null && sma50 > sma200) {
      trendScore += 20;
    }
    if (ema12 != null && ema26 != null && ema12 > ema26) trendScore += 10;

    final score = rsiScore * AppConfig.weightRsi +
        macdScore.clamp(0, 100) * AppConfig.weightMacd +
        bbScore * AppConfig.weightBollinger +
        50 * AppConfig.weightVolume +
        trendScore.clamp(0, 100) * AppConfig.weightTrend +
        50 * AppConfig.weightCandle;

    return score.clamp(0, 100);
  }
}

class _MACDResult {
  final List<double?> macd;
  final List<double?> signal;
  final List<double?> histogram;

  _MACDResult({
    required this.macd,
    required this.signal,
    required this.histogram,
  });
}

class _BollingerResult {
  final List<double?> upper;
  final List<double?> middle;
  final List<double?> lower;
  final List<double?> percentB;

  _BollingerResult({
    required this.upper,
    required this.middle,
    required this.lower,
    required this.percentB,
  });
}

class _ADXResult {
  final List<double?> adx;
  final List<double?> plusDi;
  final List<double?> minusDi;

  _ADXResult({
    required this.adx,
    required this.plusDi,
    required this.minusDi,
  });
}
