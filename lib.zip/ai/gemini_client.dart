import 'package:flutter/foundation.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../config/app_config.dart';

class GeminiClient {
  final String apiKey;
  GenerativeModel? _model;
  String? _cachedSystemPrompt;

  GeminiClient(this.apiKey);

  GenerativeModel _getModel(String systemPrompt) {
    if (_model == null || _cachedSystemPrompt != systemPrompt) {
      _cachedSystemPrompt = systemPrompt;
      _model = GenerativeModel(
        model: AppConfig.geminiModel,
        apiKey: apiKey,
        systemInstruction: Content.text(systemPrompt),
        generationConfig: GenerationConfig(
          temperature: AppConfig.geminiTemperature,
          maxOutputTokens: AppConfig.geminiMaxOutputTokens,
          responseMimeType: 'application/json',
        ),
      );
    }
    return _model!;
  }

  Future<String?> generate(String systemPrompt, String userPrompt) async {
    const maxRetries = 3;
    for (int attempt = 0; attempt < maxRetries; attempt++) {
      try {
        final model = _getModel(systemPrompt);
        final response = await model.generateContent([
          Content.text(userPrompt),
        ]);
        return response.text;
      } catch (e) {
        final isRateLimit = e.toString().contains('429') ||
            e.toString().toLowerCase().contains('resource') ||
            e.toString().toLowerCase().contains('quota');
        if (isRateLimit && attempt < maxRetries - 1) {
          final waitSec = (attempt + 1) * 15;
          debugPrint('[GeminiClient] Rate limit, $waitSec sn bekleniyor... (deneme ${attempt + 1}/$maxRetries)');
          await Future.delayed(Duration(seconds: waitSec));
          continue;
        }
        debugPrint('[GeminiClient] HATA (deneme ${attempt + 1}/$maxRetries): $e');
        if (attempt == maxRetries - 1) return null;
      }
    }
    return null;
  }

  /// Plain text Gemini cagrisi (JSON formati zorlanmaz).
  /// Haber ceviri/ozetleme icin kullanilir.
  Future<String?> generateText(String systemPrompt, String userPrompt) async {
    try {
      final model = GenerativeModel(
        model: AppConfig.geminiModel,
        apiKey: apiKey,
        systemInstruction: Content.text(systemPrompt),
        generationConfig: GenerationConfig(
          temperature: AppConfig.geminiTemperature,
          maxOutputTokens: AppConfig.newsTranslationMaxTokens,
        ),
      );
      final response = await model.generateContent([
        Content.text(userPrompt),
      ]);
      return response.text;
    } catch (e) {
      debugPrint('[GeminiClient] generateText HATA: $e');
      return null;
    }
  }
}
