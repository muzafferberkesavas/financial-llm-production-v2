import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../config/app_config.dart';
import '../domain/models/signal.dart';

class StockAnalysisResult {
  final String ticker;
  final String signal;
  final double confidence;
  final String summary;
  final String? riskReward;
  final String? scenarioStatus;
  final String? bullishScenario;
  final String? bearishScenario;
  final int? confluenceScore;
  final Map<String, dynamic>? confluenceDetail;
  final String? weeklyTrend;
  final String? timeframeAlignment;
  final String? marketRegime;
  final Map<String, dynamic>? stopLoss;
  final Map<String, dynamic>? trailingStop;
  final Map<String, dynamic>? targetPrice;
  final String? positionSize;
  final List<String>? warningFlags;
  final String? intradayPlan;

  StockAnalysisResult({
    required this.ticker,
    required this.signal,
    required this.confidence,
    required this.summary,
    this.riskReward,
    this.scenarioStatus,
    this.bullishScenario,
    this.bearishScenario,
    this.confluenceScore,
    this.confluenceDetail,
    this.weeklyTrend,
    this.timeframeAlignment,
    this.marketRegime,
    this.stopLoss,
    this.trailingStop,
    this.targetPrice,
    this.positionSize,
    this.warningFlags,
    this.intradayPlan,
  });
}

class ResponseParser {
  List<StockAnalysisResult> parse(String? jsonText) {
    if (jsonText == null || jsonText.trim().isEmpty) return [];

    try {
      // Gemini bazen ```json ... ``` ile sarar, temizle
      var cleaned = jsonText.trim();
      if (cleaned.contains('```')) {
        final regex = RegExp(r'```(?:json)?\s*([\s\S]*?)```');
        final match = regex.firstMatch(cleaned);
        if (match != null) {
          cleaned = match.group(1)!.trim();
        }
      }

      debugPrint('[AI PARSER] JSON decode basliyor, ilk 100 char: ${cleaned.substring(0, cleaned.length < 100 ? cleaned.length : 100)}');

      dynamic decoded;
      try {
        decoded = jsonDecode(cleaned);
      } catch (e) {
        // Truncated JSON recovery: try to repair by closing open structures
        debugPrint('[AI PARSER] jsonDecode HATASI: $e — truncated JSON onarimi deneniyor');
        decoded = _tryRepairJson(cleaned);
        if (decoded == null) return [];
      }

      debugPrint('[AI PARSER] decoded type: ${decoded.runtimeType}');

      List<dynamic> hisseler;
      String? topLevelRegime;

      if (decoded is Map<String, dynamic>) {
        debugPrint('[AI PARSER] Top-level keys: ${decoded.keys.toList()}');
        hisseler = decoded['hisseler'] as List<dynamic>? ?? [];
        topLevelRegime = decoded['piyasa_rejimi'] as String?;
      } else if (decoded is List<dynamic>) {
        // Gemini bazen dogrudan List doner: [{...}, {...}] veya [{"hisseler":[...]}]
        debugPrint('[AI PARSER] Top-level List, ${decoded.length} eleman');
        if (decoded.isNotEmpty && decoded.first is Map<String, dynamic>) {
          final first = decoded.first as Map<String, dynamic>;
          if (first.containsKey('hisseler')) {
            // [{"hisseler": [...], "piyasa_rejimi": "..."}]
            hisseler = first['hisseler'] as List<dynamic>? ?? [];
            topLevelRegime = first['piyasa_rejimi'] as String?;
          } else if (first.containsKey('sembol') || first.containsKey('sinyal')) {
            // Dogrudan hisse listesi: [{"sembol":"X","sinyal":"AL",...}, ...]
            hisseler = decoded;
          } else {
            hisseler = [];
          }
        } else {
          hisseler = [];
        }
      } else {
        debugPrint('[AI PARSER] Beklenmeyen tip: ${decoded.runtimeType}');
        return [];
      }

      if (hisseler.isEmpty) {
        debugPrint('[AI PARSER] hisseler bos');
        return [];
      }

      debugPrint('[AI PARSER] hisseler count: ${hisseler.length}');

      final results = <StockAnalysisResult>[];
      for (final h in hisseler) {
        final map = h as Map<String, dynamic>;
        final sinyal = (map['sinyal'] as String? ?? '').toUpperCase().trim();
        final sembol = (map['sembol'] as String? ?? '').toUpperCase().trim();
        if (!Signal.isValid(sinyal)) {
          // ignore: avoid_print
          print('[AI PARSER] Gecersiz sinyal: "$sinyal" (hisse: $sembol)');
          continue;
        }

        final confidence =
            (map['guven'] as num? ?? 0).toDouble().clamp(0.0, 1.0);

        results.add(StockAnalysisResult(
          ticker: sembol,
          signal: sinyal,
          confidence: confidence,
          summary: map['yorum'] as String? ?? '',
          riskReward: map['risk_odul'] as String?,
          scenarioStatus: map['senaryo_durum'] as String?,
          bullishScenario: map['yukselis_senaryo'] as String?,
          bearishScenario: map['dusus_senaryo'] as String?,
          confluenceScore: (map['confluence_puan'] as num?)?.toInt(),
          confluenceDetail: map['confluence_detay'] as Map<String, dynamic>?,
          weeklyTrend: map['haftalik_trend'] as String?,
          timeframeAlignment: map['zaman_dilimi_uyumu'] as String?,
          marketRegime: topLevelRegime,
          stopLoss: map['stop_loss'] as Map<String, dynamic>?,
          trailingStop: map['trailing_stop'] as Map<String, dynamic>?,
          targetPrice: map['hedef_fiyat'] as Map<String, dynamic>?,
          positionSize: map['pozisyon_boyutu'] as String?,
          warningFlags: (map['uyari_bayraklari'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList(),
          intradayPlan: map['gun_ici_plani'] as String?,
        ));
      }

      debugPrint('[AI PARSER] Basarili parse: ${results.length} hisse');
      return results;
    } catch (e, st) {
      debugPrint('[AI PARSER] GENEL HATA: $e');
      debugPrint('[AI PARSER] Stack: $st');
      return [];
    }
  }

  /// Truncated JSON onarimi: acik parantez/bracket'leri kapatarak parse etmeye calisir
  static dynamic _tryRepairJson(String broken) {
    // Son tamamlanmamis elemani at, geri kalanini kapat
    var s = broken.trim();

    // Trailing comma temizle
    s = s.replaceAll(RegExp(r',\s*$'), '');

    // Acik yapilar icin kapama karakterleri ekle
    int openBraces = 0, openBrackets = 0;
    bool inString = false;
    for (int i = 0; i < s.length; i++) {
      final c = s[i];
      if (c == '"' && (i == 0 || s[i - 1] != '\\')) {
        inString = !inString;
      }
      if (!inString) {
        if (c == '{') openBraces++;
        if (c == '}') openBraces--;
        if (c == '[') openBrackets++;
        if (c == ']') openBrackets--;
      }
    }

    // Acik string'i kapat
    if (inString) s += '"';

    // Son tamamlanmamis objeyi/array elemanini temizle
    // Son virgulden sonraki tamamlanmamis elemani sil
    final lastCompleteComma = s.lastIndexOf(RegExp(r'},\s*\{'));
    if (lastCompleteComma > 0 && openBraces > 0) {
      // Son tamamlanmamis objeyi at
      s = s.substring(0, lastCompleteComma + 1);
      // Yeniden say
      openBraces = 0;
      openBrackets = 0;
      inString = false;
      for (int i = 0; i < s.length; i++) {
        final c = s[i];
        if (c == '"' && (i == 0 || s[i - 1] != '\\')) inString = !inString;
        if (!inString) {
          if (c == '{') openBraces++;
          if (c == '}') openBraces--;
          if (c == '[') openBrackets++;
          if (c == ']') openBrackets--;
        }
      }
    }

    // Kapama karakterleri ekle
    for (int i = 0; i < openBraces; i++) s += '}';
    for (int i = 0; i < openBrackets; i++) s += ']';

    try {
      final result = jsonDecode(s);
      debugPrint('[AI PARSER] Truncated JSON onarildi!');
      return result;
    } catch (e) {
      debugPrint('[AI PARSER] JSON onarimi basarisiz: $e');
      return null;
    }
  }

  static bool shouldNotify(String signal, double confidence) {
    final s = signal.toUpperCase().trim();
    if (!Signal.isValid(s)) return false;
    if (s == 'GUCLU_AL' || s == 'ACIL_SAT') {
      return confidence >= AppConfig.minConfidenceForStrongSignal;
    }
    if (s == 'AL' || s == 'SAT' || s == 'KISMI_SAT') {
      return confidence >= AppConfig.minConfidenceForNotification;
    }
    return false;
  }
}
