import 'package:flutter/foundation.dart';
import '../config/app_config.dart';
import '../data/models/kap_disclosure.dart';
import '../data/models/market_agenda.dart';
import '../data/models/news_item.dart';
import 'gemini_client.dart';

class AgendaCache {
  static MarketAgenda? _cached;

  static MarketAgenda? get() {
    if (_cached == null || _cached!.isStale) return null;
    return _cached;
  }

  static void set(MarketAgenda agenda) {
    _cached = agenda;
  }

  static void clear() {
    _cached = null;
  }
}

class NewsTranslationService {
  final GeminiClient _client;

  NewsTranslationService(this._client);

  /// System prompt for translation — exposed for testing
  static const systemPromptText =
      '''You are a financial news analyst specializing in Borsa Istanbul (BIST) and Turkish markets.

TASK: Translate and summarize market news into a concise English market agenda.

RULES:
1. Output a numbered list of MINIMUM 5 and MAXIMUM ${AppConfig.newsMaxItems} items. If fewer than 5 distinct topics exist, group related news or add broader context items.
2. Each item must be ONE complete sentence, maximum 25 words. NEVER leave a sentence unfinished.
3. Include specific numbers: prices, percentages, amounts. Example: "Brent oil fell 2.4% to \$111.25" NOT just "oil prices changed".
4. Categorize each item with ONE tag:
   - [MACRO] for central bank, inflation, GDP, economic policy, currency
   - [SECTOR:name] for sector-wide news (e.g., [SECTOR:BANKING], [SECTOR:ENERGY])
   - [STOCK:TICKER] for company-specific news (use BIST ticker)
   - [GEOPOLITICAL] for international relations, trade, conflicts, commodity supply
5. End each item with: (positive), (negative), or (neutral) AND time hint like [today], [yesterday], [2d ago].
   Example: "1. [MACRO] TCMB held policy rate at 42.5%, in line with expectations. (neutral) [today]"
6. PRIORITY ORDER:
   a. FIRST: News about PRIORITY STOCKS listed below (if any exist)
   b. SECOND: Sector news affecting those stocks (energy, banking, defense, retail, metals)
   c. THIRD: Macro/economic news (rates, inflation, FX)
   d. FOURTH: Geopolitical news (trade wars, sanctions, oil supply)
7. If news is already in English, summarize without re-translating.
8. Respond ONLY with the numbered list. No introduction, no explanation, no extra text.
9. If no meaningful news is available, respond with: "No significant market news in last 24h."
10. CRITICAL: Every sentence must be COMPLETE. Do not cut off mid-sentence.''';

  String buildTranslationPrompt({
    required List<NewsItem> newsItems,
    List<KapDisclosure> kapDisclosures = const [],
    List<String> watchlistTickers = const [],
  }) {
    final buf = StringBuffer();

    if (watchlistTickers.isNotEmpty) {
      buf.writeln(
          'PRIORITY STOCKS (mention these first if relevant): ${watchlistTickers.join(", ")}');
      buf.writeln('');
    }

    if (kapDisclosures.isNotEmpty) {
      buf.writeln('=== KAP DISCLOSURES (Official Company Announcements) ===');
      for (final d in kapDisclosures) {
        buf.writeln(
            '[${d.ticker}] ${d.type}: ${d.titleEn ?? d.title}');
        if (d.summary != null && d.summary!.isNotEmpty) {
          final summary = d.summary!.length > 200
              ? '${d.summary!.substring(0, 200)}...'
              : d.summary!;
          buf.writeln('  Summary: $summary');
        }
      }
      buf.writeln('');
    }

    if (newsItems.isNotEmpty) {
      buf.writeln('=== MARKET NEWS (RSS) ===');
      for (final n in newsItems.take(AppConfig.newsMaxRssItems)) {
        final age = _formatAge(n.pubDate);
        buf.writeln('[${n.source}] [$age] ${n.title}');
        if (n.description != null && n.description!.isNotEmpty) {
          final desc = n.description!.length > 300
              ? '${n.description!.substring(0, 300)}...'
              : n.description!;
          buf.writeln('  $desc');
        }
      }
    }

    if (kapDisclosures.isEmpty && newsItems.isEmpty) {
      buf.writeln('No news items available.');
    }

    return buf.toString();
  }

  Future<MarketAgenda> translateAndSummarize({
    required List<NewsItem> newsItems,
    List<KapDisclosure> kapDisclosures = const [],
    List<String> watchlistTickers = const [],
  }) async {
    if (newsItems.isEmpty && kapDisclosures.isEmpty) {
      return MarketAgenda(
        formattedAgenda: '',
        fetchTime: DateTime.now(),
      );
    }

    final userPrompt = buildTranslationPrompt(
      newsItems: newsItems,
      kapDisclosures: kapDisclosures,
      watchlistTickers: watchlistTickers,
    );

    try {
      final result = await _client.generateText(systemPromptText, userPrompt);

      if (result != null && result.isNotEmpty) {
        final cleaned = _fixTruncation(result.trim());
        return MarketAgenda(
          formattedAgenda: cleaned,
          fetchTime: DateTime.now(),
          kapCount: kapDisclosures.length,
          rssCount: newsItems.length,
        );
      }
    } catch (e) {
      debugPrint('[NewsTranslation] Gemini hatasi: $e');
    }

    // Fallback: Gemini basarisizsa ham basliklardan basit agenda olustur
    return _buildFallbackAgenda(newsItems, kapDisclosures);
  }

  /// Haberin ne kadar once yayinlandigini formatlayan helper
  String _formatAge(DateTime pubDate) {
    final diff = DateTime.now().difference(pubDate);
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  /// Kesilmis cumleleri temizler — son satirda nokta/parantez ile bitmiyorsa
  /// o satiri kaldirir
  String _fixTruncation(String text) {
    final lines = text.split('\n').where((l) => l.trim().isNotEmpty).toList();
    if (lines.isEmpty) return text;

    // Son satir tamamlanmis bir cumle mi kontrol et
    final lastLine = lines.last.trim();
    // Tamamlanmis cumle: nokta, parantez kapama, veya ] ile biter
    if (!lastLine.endsWith('.') &&
        !lastLine.endsWith(')') &&
        !lastLine.endsWith(']')) {
      debugPrint('[NewsTranslation] Kesilmis son satir kaldirildi: $lastLine');
      lines.removeLast();
    }

    return lines.join('\n');
  }

  MarketAgenda _buildFallbackAgenda(
    List<NewsItem> newsItems,
    List<KapDisclosure> kapDisclosures,
  ) {
    final buf = StringBuffer();
    var count = 0;

    for (final d in kapDisclosures) {
      if (count >= AppConfig.newsMaxItems) break;
      count++;
      final title = d.titleEn ?? d.title;
      final age = _formatAge(d.publishDate);
      buf.writeln('$count. [STOCK:${d.ticker}] $title (neutral) [$age]');
    }

    for (final n in newsItems) {
      if (count >= AppConfig.newsMaxItems) break;
      count++;
      final age = _formatAge(n.pubDate);
      buf.writeln('$count. [${n.category ?? "MACRO"}] ${n.title} (neutral) [$age]');
    }

    return MarketAgenda(
      formattedAgenda: buf.toString().trim(),
      fetchTime: DateTime.now(),
      kapCount: kapDisclosures.length,
      rssCount: newsItems.length,
    );
  }
}

/// Izolat uyumlu top-level fonksiyon (background service icin)
Future<MarketAgenda?> fetchMarketAgenda({
  required String apiKey,
  required List<NewsItem> newsItems,
  List<KapDisclosure> kapDisclosures = const [],
  List<String> watchlistTickers = const [],
}) async {
  try {
    final client = GeminiClient(apiKey);
    final service = NewsTranslationService(client);
    return await service.translateAndSummarize(
      newsItems: newsItems,
      kapDisclosures: kapDisclosures,
      watchlistTickers: watchlistTickers,
    );
  } catch (e) {
    debugPrint('[fetchMarketAgenda] Hata: $e');
    return null;
  }
}
