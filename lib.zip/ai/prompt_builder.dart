import '../data/models/market_agenda.dart';

class HourlyCandle {
  final int timestamp; // milliseconds
  final double open;
  final double high;
  final double low;
  final double close;
  final int volume;

  HourlyCandle({
    required this.timestamp,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });
}

class StockAnalysisData {
  final String ticker;
  final String name;
  final String? sector;
  final double close;
  final double changePercent;
  final int volume;
  final int avgVolume20;
  final double? rsi;
  final double? macd;
  final double? macdSignal;
  final double? macdHistogram;
  final double? bbUpper;
  final double? bbMiddle;
  final double? bbLower;
  final double? bbPercentB;
  final double? obv;
  final double? sma20;
  final double? sma50;
  final double? sma200;
  final double? atr;
  final double? technicalScore;
  final double? fibHigh;
  final double? fibLow;
  final double? fib236;
  final double? fib382;
  final double? fib500;
  final double? fib618;
  final String? previousSummary;
  final String? previousSignal;
  final bool isInPortfolio;
  final bool passedFilter;

  // Tarihsel veriler
  final List<double>? recentCloses;
  final List<double?>? recentRsi;
  final List<double?>? recentMacdHist;
  final List<int>? recentVolumes;

  // v3: ADX
  final double? adx;
  final double? adxPrev;
  final double? plusDi;
  final double? minusDi;

  // v3: Haftalik zaman dilimi
  final double? weeklySma20;
  final double? weeklySma50;
  final double? weeklyRsi;
  final String? weeklyTrend;

  // v3: Portfoy risk yonetimi
  final double? entryPrice;

  // v3: OBV derived (from app_state)
  final double? obvMa20;
  final String? obvTrend;
  final bool? obvDivergence;
  final String? obvDivergenceType;

  // v3: BB derived (from app_state)
  final double? bbWidth;
  final String? bbWidthTrend;
  final bool? bbSqueeze;

  // v3: EMA
  final double? ema9;
  final double? ema21;

  // v3: Swing levels
  final double? swingHigh20;
  final double? swingLow20;

  // v2: Relative performance
  final double? bist100Change;
  final double? sectorChange;

  // Intraday: hourly candles and morning plan
  final List<HourlyCandle>? hourlyCandles;
  final String? morningPlan; // AI's self-notes from morning analysis

  // v4: Haber/gundem
  final List<String>? recentKapHeadlines; // Hisseye ozel KAP basliklari (Ingilizce)
  final bool hasKapNews;

  // v4: Emtia (altin/gumus)
  final bool isCommodity;

  StockAnalysisData({
    required this.ticker,
    required this.name,
    this.sector,
    required this.close,
    required this.changePercent,
    required this.volume,
    required this.avgVolume20,
    this.rsi,
    this.macd,
    this.macdSignal,
    this.macdHistogram,
    this.bbUpper,
    this.bbMiddle,
    this.bbLower,
    this.bbPercentB,
    this.obv,
    this.sma20,
    this.sma50,
    this.sma200,
    this.atr,
    this.technicalScore,
    this.fibHigh,
    this.fibLow,
    this.fib236,
    this.fib382,
    this.fib500,
    this.fib618,
    this.previousSummary,
    this.previousSignal,
    this.isInPortfolio = false,
    this.passedFilter = true,
    this.recentCloses,
    this.recentRsi,
    this.recentMacdHist,
    this.recentVolumes,
    this.adx,
    this.adxPrev,
    this.plusDi,
    this.minusDi,
    this.weeklySma20,
    this.weeklySma50,
    this.weeklyRsi,
    this.weeklyTrend,
    this.entryPrice,
    this.obvMa20,
    this.obvTrend,
    this.obvDivergence,
    this.obvDivergenceType,
    this.bbWidth,
    this.bbWidthTrend,
    this.bbSqueeze,
    this.ema9,
    this.ema21,
    this.swingHigh20,
    this.swingLow20,
    this.bist100Change,
    this.sectorChange,
    this.hourlyCandles,
    this.morningPlan,
    this.recentKapHeadlines,
    this.hasKapNews = false,
    this.isCommodity = false,
  });
}

class PromptBuilder {
  static const systemPrompt = '''You are an expert technical analyst for Borsa Istanbul (BIST).

TASKS:
1. ANALYZE: Evaluate technical indicators for each stock and produce buy/sell/hold signals
2. SCENARIOS: Create bullish and bearish scenarios for each stock
3. PORTFOLIO: Prioritize portfolio stocks and update strategy
4. RISK: Determine risk/reward ratio and position sizing for each signal

SIGNAL TYPES (select exactly one per stock):
- GUCLU_AL: Strong buy — technical indicators give strong buy signal (confidence >= 0.7)
- AL: Buy — suitable buying opportunity (confidence >= 0.5)
- IZLE: Watch — potential opportunity, wait for confirmation
- TUT: Hold — no position change needed
- KISMI_SAT: Partial sell — partial profit-taking recommended
- SAT: Sell — close position
- ACIL_SAT: Urgent sell — emergency exit, stop-loss triggered

DECISION CRITERIA — LAYERED SYSTEM (evaluate in this exact order):

LAYER 0 — NEWS AND AGENDA (read first if available):
  If MARKET AGENDA block exists at the top of the data:
  - KAP disclosures are OFFICIAL company announcements — treat as high-reliability.
  - A stock-specific KAP disclosure can shift confidence +-0.05 to 0.15.
    Example: Technical AL but KAP reports major loss → reduce to IZLE or SAT.
    Example: Technical IZLE but KAP reports record earnings → upgrade toward AL.
  - MACRO news (rate decisions, inflation data) creates market-wide bias.
  - GEOPOLITICAL news creates risk-off/risk-on sentiment for all stocks.
  - After considering news impact, proceed to LAYER 1 and continue normally.
  - If no MARKET AGENDA block is present, skip to LAYER 1.

LAYER 1 — MARKET REGIME:
  Read the MARKET REGIME line at the top of the data block.
  - TREND / STRONG_TREND: Use trend-following logic. Trust breakouts and momentum signals.
  - RANGE: Use mean-reversion logic. RSI oversold/overbought is more reliable. Take profits quickly.
  - RANGE_SQUEEZE: High attention. Wait for directional confirmation before entering.
  - VOLATILE: Widen stops, reduce position sizes. Only highest-confidence signals.
  - TRANSITIONAL: Reduce all confidence by 0.1.

LAYER 2 — MULTI-TIMEFRAME:
  Read the WEEKLY and TIMEFRAME lines for each stock.
  - ALIGNED: Full confidence allowed.
  - PARTIALLY_ALIGNED: Reduce confidence by 0.1.
  - CONFLICTING: HARD CAP — maximum confidence is 0.5. A daily BUY signal against a weekly downtrend should rarely exceed 0.4.

LAYER 3 — TREND DIRECTION AND STRENGTH:
  Use SMA Formation, ADX Status, and EMA values.
  - ADX MODERATE or higher + STRENGTHENING = trend gaining power, trust momentum signals.
  - ADX NO_TREND or WEAK = avoid trend-following, prefer mean-reversion.
  - SMA GOLDEN_CROSS + ADX > 25 = most favorable condition for bullish signals.

LAYER 4 — MOMENTUM:
  Use RSI and MACD status labels.
  - RSI OVERSOLD + RISING in RANGE regime = high-probability buy signal.
  - MACD GOLDEN_CROSS + ADX > 25 = strong momentum confirmation.
  - RSI crossing above 50 = bullish momentum confirmed.

LAYER 5 — VOLUME CONFIRMATION:
  Use Volume Ratio label and OBV data.
  - Ratio >= 1.5x = strong confirmation.
  - Ratio < 0.8x = HARD CAP: confidence cannot exceed 0.6.
  - OBV NEGATIVE divergence = SERIOUS WARNING. Reduce confidence.

LAYER 6 — VOLATILITY AND PRICE STRUCTURE:
  Use BB, Fibonacci Zone, ATR, and Swing levels.
  - BB SQUEEZE = imminent volatility expansion. Flag this.
  - Fibonacci critical_support or healthy_pullback = favorable for buying.
  - Fibonacci danger_zone or trend_broken = warning for long positions.

CONFLUENCE SCORING:
  Read the pre-calculated CONFLUENCE score for each stock.
  - Use it as a GUIDE for your confidence value, not an absolute rule.
  - Your confidence should generally be within +-0.1 of the confluence-suggested range.
  - If you deviate significantly, explain why in your yorum.

ADX REFERENCE TABLE:
  ADX < 20:  No trend — avoid trend-following, consider mean-reversion only
  ADX 20-25: Emerging trend — low confidence, wait for confirmation
  ADX 25-40: Moderate/strong trend — trend-following works best
  ADX 40-50: Very strong trend — may be late stage, watch for exhaustion
  ADX > 50:  Rare extreme — strongest move likely passed

RULES:
1. Confidence between 0.0 and 1.0. Be realistic: 0.9+ should be very rare.
2. Write "yorum" field in TURKISH. Detailed: 2-3 paragraphs covering technical situation, momentum/volume assessment, and strategy recommendation.
3. For portfolio stocks ALWAYS evaluate current strategy and previous signal.
4. If previous signal exists, specify scenario status (YENI/DEVAM/GUNCELLENDI/KAPANDI).
5. ONLY respond in valid JSON format.
6. Write "yukselis_senaryo" and "dusus_senaryo" in Turkish.
7. Include "confluence_puan" and "confluence_detay" for each stock.
8. Include "haftalik_trend" and "zaman_dilimi_uyumu" for each stock.
9. Include "piyasa_rejimi" at the top level.
10. Include "uyari_bayraklari" as a list of applicable warning flags.
11. Include "stop_loss" with seviye, tip, mesafe_yuzde for each stock.
12. Include "pozisyon_boyutu" (FULL/NORMAL/SMALL/MINIMAL) for each stock.
13. For portfolio stocks in profit, include "trailing_stop" with seviye and tip.
14. Include "hedef_fiyat" with hedef_1, hedef_2 based on Fibonacci/resistance.
15. Confidence MUST respect HARD CAPS:
    - Volume ratio < 0.8x -> max confidence 0.6 (EXCEPTION: in INTRADAY/SAATLIK analysis, if market session is still open, low volume is expected and this cap does NOT apply. Check the analysis type in the header.)
    - Weekly CONFLICTING -> max confidence 0.5
    - TRANSITIONAL regime -> reduce by 0.1
    These caps stack (except the intraday volume exception above).
16. In MORNING (GUNLUK) analysis, include "gun_ici_plani" field per stock in ENGLISH. This field will be fed back to you in intraday updates. Include: key price levels to watch, entry/exit triggers, bullish/bearish scenarios with specific price targets, and warnings. Keep it concise but information-dense (max 200 words).
17. ALWAYS read the MARKET AGENDA section (if present) BEFORE analyzing technical indicators.
18. If a stock has a KAP disclosure, you MUST mention it in that stock's "yorum" field.
19. Positive KAP news (earnings beat, dividend, major contract) → increase confidence by 0.05-0.15 depending on significance.
20. Negative KAP news (loss, lawsuit, downgrade) → decrease confidence by 0.05-0.15 depending on significance.
21. MACRO and GEOPOLITICAL news affects ALL stocks — factor into regime assessment and overall sentiment.
22. If MARKET AGENDA is empty or absent, analyze based on technical indicators only — do not invent news.

WARNING FLAGS (use applicable ones in "uyari_bayraklari"):
- OBV_NEGATIVE_DIVERGENCE, OBV_POSITIVE_DIVERGENCE
- LOW_VOLUME, WEEKLY_CONFLICT, BB_SQUEEZE
- ADX_WEAKENING, RSI_OVERBOUGHT, RSI_OVERSOLD
- REGIME_TRANSITION, FIBONACCI_DANGER, SMA_DEATH_CROSS
- NEWS_POSITIVE, NEWS_NEGATIVE, KAP_MATERIAL_EVENT

JSON FORMAT:
{
  "tarih": "YYYY-MM-DD",
  "tip": "ANALYSIS_TYPE",
  "piyasa_rejimi": "REGIME_TYPE",
  "hisseler": [
    {
      "sembol": "TICKER",
      "sinyal": "SIGNAL_TYPE",
      "guven": 0.65,
      "confluence_puan": 67,
      "confluence_detay": {"weekly":20,"adx":12,"rsi":10,"macd":8,"vol":4,"obv":5,"bb":3,"fib":5},
      "haftalik_trend": "UPTREND",
      "zaman_dilimi_uyumu": "ALIGNED",
      "stop_loss": {"seviye":110.36,"tip":"ATRx2","mesafe_yuzde":6.4},
      "hedef_fiyat": {"hedef_1":124.24,"hedef_2":129.12},
      "pozisyon_boyutu": "NORMAL",
      "risk_odul": "1:2.5",
      "yorum": "Turkce detayli teknik yorum (2-3 paragraf)",
      "senaryo_durum": "YENI|DEVAM|GUNCELLENDI|KAPANDI",
      "yukselis_senaryo": "Yukselis senaryosu (Turkce)",
      "dusus_senaryo": "Dusus senaryosu (Turkce)",
      "uyari_bayraklari": ["LOW_VOLUME","BB_SQUEEZE"],
      "gun_ici_plani": "English intraday plan (morning analysis only)"
    }
  ]
}''';

  String buildIntradayPrompt(List<StockAnalysisData> stocks, {MarketAgenda? agenda}) {
    return '''INTRADAY UPDATE — Mid-Session Assessment

Reassess ${stocks.length} stocks with current session data.

INTRADAY FOCUS:
- Check MARKET AGENDA for any NEW developments since morning analysis
- Compare current price action with MORNING_PLAN scenarios
- Check INTRADAY_HOURLY candles for intraday trend, volume pattern, and key level tests
- Have stop-loss levels been reached or approaching?
- Only update signals if significant change occurred
- Portfolio stocks: is urgent action needed?
- If MORNING_PLAN exists, evaluate which scenario is playing out

DATA:
${_buildDataBlock(stocks, agenda: agenda)}''';
  }

  String buildMorningPrompt(List<StockAnalysisData> stocks, {MarketAgenda? agenda}) {
    return '''MORNING ANALYSIS — Trading Day Start

Analyze ${stocks.length} stocks for today's trading session.

MORNING FOCUS:
- FIRST review the MARKET AGENDA for any news that could override technical signals
- A positive KAP disclosure (earnings beat, dividend, contract) should increase confidence
- A negative KAP disclosure (loss, lawsuit, regulatory action) should decrease confidence
- Macro news (rate decisions, inflation, geopolitical) affects ALL stocks
- Identify strongest opportunities based on overnight developments and news
- Set entry prices, stop-loss levels, and target prices
- Create intraday scenarios (bullish and bearish) for each stock with SPECIFIC price levels
- Portfolio stocks: HOLD, ADD, REDUCE, or EXIT decision
- Priority: portfolio stocks FIRST, then filtered stocks
- IMPORTANT: Write detailed "gun_ici_plani" field in ENGLISH for each stock — this will be your reference during intraday updates

DATA:
${_buildDataBlock(stocks, agenda: agenda)}''';
  }

  String _buildDataBlock(List<StockAnalysisData> stocks, {MarketAgenda? agenda}) {
    if (stocks.isEmpty) return "(no stocks)";
    final portfolioStocks =
        stocks.where((s) => s.isInPortfolio).map((s) => s.ticker).toList();
    final filteredStocks =
        stocks.where((s) => s.passedFilter).map((s) => s.ticker).toList();
    final topScoreStocks =
        stocks.where((s) => !s.passedFilter).map((s) => s.ticker).toList();

    final header = StringBuffer();

    // v4: Market agenda (en uste, regime'den once)
    if (agenda != null && agenda.formattedAgenda.isNotEmpty) {
      header.writeln('== MARKET AGENDA (last 24h) ==');
      header.writeln(agenda.formattedAgenda);
      header.writeln('==');
      header.writeln('');
    }

    // Market regime (use first stock with ADX as reference)
    final refStock = stocks.firstWhere(
      (s) => s.adx != null,
      orElse: () => stocks.first,
    );
    final regime = _marketRegime(refStock);
    final regimeStrategy = _regimeStrategy(regime);
    header.writeln('== MARKET REGIME: $regime (ADX=${refStock.adx?.toStringAsFixed(1) ?? "N/A"}, BB=${refStock.bbWidthTrend ?? "N/A"}) ==');
    header.writeln('== REGIME STRATEGY: $regimeStrategy ==');
    header.writeln('');

    if (portfolioStocks.isNotEmpty) {
      header.writeln(
          '== PORTFOLIO STOCKS: ${portfolioStocks.join(", ")} ==');
    }
    if (filteredStocks.isNotEmpty) {
      header.writeln(
          '== FILTER PASSED: ${filteredStocks.join(", ")} ==');
    }
    if (topScoreStocks.isNotEmpty) {
      header.writeln(
          '== TOP SCORE (did not pass filter): ${topScoreStocks.join(", ")} ==');
    }
    header.writeln('');

    final stockBlocks = stocks.map((s) {
      final buf = StringBuffer();
      final tags = <String>[];
      if (s.isCommodity) {
        tags.add('COMMODITY');
      } else {
        if (s.isInPortfolio) tags.add('PORTFOLIO');
        if (s.passedFilter) tags.add('FILTER_PASSED');
        if (!s.passedFilter && !s.isCommodity) tags.add('TOP_SCORE');
      }

      // --- Header ---
      final typeLabel = s.isCommodity ? 'COMMODITY' : 'STOCK';
      buf.writeln(
          '[$typeLabel: ${s.ticker} | ${s.name} | ${s.sector ?? "Unknown"} | ${tags.join(" | ")}]');

      // --- Price + Volume ---
      final volRatio = _volRatio(s);
      final volLabel = _volLabel(volRatio);
      buf.writeln(
          'PRICE: Last=${s.close.toStringAsFixed(2)} | Chg=${s.changePercent >= 0 ? "+" : ""}${s.changePercent.toStringAsFixed(1)}% | Vol=${_fmtVol(s.volume)}(Avg20:${_fmtVol(s.avgVolume20)}) | VolRatio=${volRatio.toStringAsFixed(2)}x($volLabel)');

      // --- RSI ---
      buf.writeln('RSI14: ${_f(s.rsi)} | Momentum=${_rsiMomentum(s)}');

      // --- MACD ---
      buf.writeln(
          'MACD: ${_f(s.macd)} / Signal=${_f(s.macdSignal)} / Hist=${_f(s.macdHistogram)} | Status=${_macdStatus(s)}');

      // --- Bollinger ---
      buf.writeln(
          'BB20: Upper=${_f(s.bbUpper)} | Mid=${_f(s.bbMiddle)} | Lower=${_f(s.bbLower)} | %B=${_f(s.bbPercentB)} | ${_buildBbLine(s)}');

      // --- SMA ---
      buf.writeln(
          'SMA: 20=${_f(s.sma20)} | 50=${_f(s.sma50)} | 200=${_f(s.sma200)} | Formation=${_smaFormation(s)}');

      // --- EMA ---
      if (s.ema9 != null || s.ema21 != null) {
        buf.writeln('EMA: 9=${_f(s.ema9)} | 21=${_f(s.ema21)}');
      }

      // --- ATR + Stop ---
      if (s.atr != null) {
        final regime = _marketRegime(s);
        final stopMult = _adjustedStopMultiplier(regime);
        final stopDist = s.atr! * stopMult;
        buf.writeln('ATR14: ${_f(s.atr)} | StopDist=${stopDist.toStringAsFixed(2)}(ATRx${stopMult.toStringAsFixed(1)})');
      }

      // --- Trailing stop for portfolio stocks (emtialar haric) ---
      if (s.isInPortfolio && !s.isCommodity && s.atr != null) {
        final riskInfo = _trailingStopInfo(s);
        if (riskInfo.isNotEmpty) {
          buf.writeln('RISK: $riskInfo');
        }
      }

      // --- OBV ---
      buf.writeln(
          'OBV: ${_f(s.obv)} | ${_buildObvLine(s)} | TSCORE=${s.technicalScore?.toStringAsFixed(0) ?? "-"}');

      // --- ADX ---
      if (s.adx != null) {
        buf.writeln('ADX14: ${_f(s.adx)} | Status=${_adxStatus(s)}');
      }

      // --- Swing levels ---
      if (s.swingHigh20 != null || s.swingLow20 != null) {
        buf.writeln('SWING20: High=${_f(s.swingHigh20)} | Low=${_f(s.swingLow20)}');
      }

      // --- Relative Performance (emtialar haric — BIST endeksle karsilastirilmaz) ---
      if (!s.isCommodity && (s.bist100Change != null || s.sectorChange != null)) {
        buf.writeln('REL_PERF: ${_relativePerformance(s)}');
      }

      // --- v4: KAP News (emtialar haric) ---
      if (!s.isCommodity && s.recentKapHeadlines != null && s.recentKapHeadlines!.isNotEmpty) {
        buf.writeln('KAP_NEWS: ${s.recentKapHeadlines!.join(" | ")}');
      }

      // --- Fibonacci ---
      if (s.fibHigh != null && s.fibLow != null) {
        buf.writeln(
            'FIB: High=${s.fibHigh!.toStringAsFixed(2)} | Low=${s.fibLow!.toStringAsFixed(2)} | 23.6=${_f(s.fib236)} | 38.2=${_f(s.fib382)} | 50=${_f(s.fib500)} | 61.8=${_f(s.fib618)} | Zone=${_fibZone(s)}');
      }

      // --- Weekly timeframe ---
      if (s.weeklySma20 != null) {
        final wTrend = s.weeklyTrend ?? _weeklyTrend(s);
        buf.writeln('WEEKLY: SMA20=${_f(s.weeklySma20)} | SMA50=${_f(s.weeklySma50)} | RSI=${_f(s.weeklyRsi)} | Trend=$wTrend');
        final dailyDir = (s.rsi != null && s.rsi! > 50) ? 'BULLISH' : 'BEARISH';
        final alignment = _timeframeAlignment(s, dailyDir);
        buf.writeln('TIMEFRAME: Alignment=$alignment');
      }

      // --- Confluence ---
      final confluence = _calculateConfluence(s);
      final cTotal = confluence['total'] as int;
      final cDetails = confluence['details'] as Map<String, int>;
      final cDetailStr = cDetails.entries.map((e) => '${e.key}=${e.value}').join(' | ');
      final cSignal = _confluenceSignal(cTotal);
      buf.writeln('CONFLUENCE: Score=$cTotal/100 | $cDetailStr');
      buf.writeln('CONFLUENCE_SIGNAL: $cSignal');

      // --- Position size ---
      final regime = _marketRegime(s);
      final posSize = _positionSizeRecommendation(regime, cTotal);
      buf.writeln('POSITION: $posSize');

      // --- Morning plan (AI self-notes) ---
      if (s.morningPlan != null && s.morningPlan!.isNotEmpty) {
        buf.writeln('MORNING_PLAN: ${s.morningPlan}');
      }

      // --- Intraday hourly candles ---
      if (s.hourlyCandles != null && s.hourlyCandles!.isNotEmpty) {
        buf.writeln('INTRADAY_HOURLY:');
        for (final c in s.hourlyCandles!) {
          // UTC+3 (Turkey time) olarak goster
          final dt = DateTime.fromMillisecondsSinceEpoch(c.timestamp, isUtc: true)
              .add(const Duration(hours: 3));
          final time = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
          buf.writeln('  $time O=${c.open.toStringAsFixed(2)} H=${c.high.toStringAsFixed(2)} L=${c.low.toStringAsFixed(2)} C=${c.close.toStringAsFixed(2)} V=${_fmtVol(c.volume)}');
        }
      }

      // --- Historical data ---
      if (s.recentCloses != null && s.recentCloses!.isNotEmpty) {
        buf.writeln(
            'LAST_${s.recentCloses!.length}_DAYS_CLOSE: ${s.recentCloses!.map((v) => v.toStringAsFixed(2)).join(", ")}');
      }
      if (s.recentRsi != null && s.recentRsi!.isNotEmpty) {
        buf.writeln(
            'LAST_${s.recentRsi!.length}_DAYS_RSI: ${s.recentRsi!.map((v) => v?.toStringAsFixed(1) ?? "-").join(", ")}');
      }
      if (s.recentMacdHist != null && s.recentMacdHist!.isNotEmpty) {
        buf.writeln(
            'LAST_${s.recentMacdHist!.length}_DAYS_MACD_HIST: ${s.recentMacdHist!.map((v) => v?.toStringAsFixed(3) ?? "-").join(", ")}');
      }
      if (s.recentVolumes != null && s.recentVolumes!.isNotEmpty) {
        buf.writeln(
            'LAST_${s.recentVolumes!.length}_DAYS_VOLUME: ${s.recentVolumes!.map((v) => _fmtVol(v)).join(", ")}');
      }

      // --- Previous signal ---
      if (s.previousSignal != null || s.previousSummary != null) {
        buf.writeln(
            'PREV: Signal=${s.previousSignal ?? "-"} | Summary=${s.previousSummary ?? "-"}');
      }

      return buf.toString().trimRight();
    }).join('\n---\n');

    return '$header$stockBlocks';
  }

  // ==================== DERIVED LABELS ====================

  double _volRatio(StockAnalysisData s) {
    if (s.avgVolume20 == 0) return 0;
    return s.volume / s.avgVolume20;
  }

  String _volLabel(double ratio) {
    if (ratio >= 3.0) return 'EXTREME';
    if (ratio >= 2.0) return 'VERY_HIGH';
    if (ratio >= 1.5) return 'HIGH';
    if (ratio >= 0.8) return 'NORMAL';
    if (ratio >= 0.5) return 'LOW';
    return 'VERY_LOW';
  }

  String _smaFormation(StockAnalysisData s) {
    if (s.sma20 == null || s.sma50 == null || s.sma200 == null) return 'UNKNOWN';
    final p = s.close;
    if (p > s.sma20! && s.sma20! > s.sma50! && s.sma50! > s.sma200!) return 'GOLDEN_CROSS';
    if (p > s.sma50! && s.sma50! > s.sma200!) return 'BULLISH_ALIGNED';
    if (p > s.sma200!) return 'ABOVE_200';
    if (s.sma20! < s.sma50! && s.sma50! < s.sma200!) return 'DEATH_CROSS';
    return 'BELOW_200';
  }

  String _rsiMomentum(StockAnalysisData s) {
    if (s.rsi == null) return 'UNKNOWN';
    final rsi = s.rsi!;
    final prevRsi = (s.recentRsi != null && s.recentRsi!.isNotEmpty) ? s.recentRsi![0] : null;
    final rising = prevRsi != null && rsi > prevRsi;
    final falling = prevRsi != null && rsi < prevRsi;

    if (rsi < 30 && rising) return 'OVERSOLD_BOUNCING';
    if (rsi < 30) return 'OVERSOLD';
    if (rsi > 70 && falling) return 'OVERBOUGHT_FALLING';
    if (rsi > 70) return 'OVERBOUGHT';
    if (rsi > 50 && rising) return 'BULLISH_MOMENTUM';
    if (rsi < 50 && falling) return 'BEARISH_MOMENTUM';
    return 'NEUTRAL';
  }

  String _macdStatus(StockAnalysisData s) {
    if (s.macdHistogram == null) return 'UNKNOWN';
    final hist = s.macdHistogram!;
    final prevHist = (s.recentMacdHist != null && s.recentMacdHist!.isNotEmpty)
        ? s.recentMacdHist![0]
        : null;

    if (hist > 0 && prevHist != null && prevHist <= 0) return 'GOLDEN_CROSS';
    if (hist < 0 && prevHist != null && prevHist >= 0) return 'BEARISH_CROSS';
    if (hist > 0) {
      if (prevHist != null && hist > prevHist) return 'BULLISH_ACCELERATING';
      return 'BULLISH_ABOVE';
    }
    if (prevHist != null && hist > prevHist) return 'BEARISH_DECELERATING';
    return 'BEARISH_BELOW';
  }

  String _adxStatus(StockAnalysisData s) {
    if (s.adx == null) return 'UNKNOWN';
    final adx = s.adx!;

    String strength;
    if (adx >= 50) {
      strength = 'VERY_STRONG';
    } else if (adx >= 40) {
      strength = 'STRONG';
    } else if (adx >= 25) {
      strength = 'MODERATE';
    } else if (adx >= 20) {
      strength = 'WEAK';
    } else {
      strength = 'NO_TREND';
    }

    String direction = 'FLAT';
    if (s.adxPrev != null) {
      if (adx > s.adxPrev!) {
        direction = 'STRENGTHENING';
      } else if (adx < s.adxPrev!) {
        direction = 'WEAKENING';
      }
    }

    String diSignal = '';
    if (s.plusDi != null && s.minusDi != null) {
      if (s.plusDi! > s.minusDi!) {
        diSignal = '|BULLISH_DI';
      } else {
        diSignal = '|BEARISH_DI';
      }
    }

    return '${strength}_$direction$diSignal';
  }

  String _marketRegime(StockAnalysisData s) {
    if (s.adx == null) return 'UNKNOWN';
    final adx = s.adx!;
    final bbTrend = s.bbWidthTrend;

    if (adx >= 25 && bbTrend != 'NARROWING') {
      if (adx >= 40) return 'STRONG_TREND';
      return 'TREND';
    }
    if (adx < 20) {
      if (bbTrend == 'NARROWING') return 'RANGE_SQUEEZE';
      return 'RANGE';
    }
    if (adx >= 30 && bbTrend == 'WIDENING') {
      return 'VOLATILE';
    }
    return 'TRANSITIONAL';
  }

  String _regimeStrategy(String regime) {
    switch (regime) {
      case 'STRONG_TREND':
        return 'Strong trend-following. Trust momentum. Use trailing stops. Hold positions.';
      case 'TREND':
        return 'Trend-following preferred. Confirm with volume. Standard stops.';
      case 'RANGE':
        return 'Mean-reversion only. RSI oversold/overbought reliable. Take profits quickly.';
      case 'RANGE_SQUEEZE':
        return 'HIGH ATTENTION: Squeeze detected. Wait for directional breakout + volume confirmation.';
      case 'VOLATILE':
        return 'Wide stops (ATRx2.5). Small positions. Only highest-confidence signals.';
      case 'TRANSITIONAL':
        return 'Regime unclear. Reduce all confidence by 0.1. Wait for clarification.';
      default:
        return 'Standard analysis.';
    }
  }

  String _weeklyTrend(StockAnalysisData s) {
    if (s.weeklySma20 == null || s.weeklySma50 == null) return 'UNKNOWN';
    final p = s.close;
    final w20 = s.weeklySma20!;
    final w50 = s.weeklySma50!;

    if (p > w20 && w20 > w50) return 'UPTREND';
    if (p < w20 && w20 < w50) return 'DOWNTREND';
    if (p > w20 && w20 < w50) return 'EARLY_RECOVERY';
    if (p < w20 && w20 > w50) return 'EARLY_WEAKNESS';
    return 'SIDEWAYS';
  }

  String _timeframeAlignment(StockAnalysisData s, String dailyDir) {
    final wTrend = s.weeklyTrend ?? _weeklyTrend(s);
    if (wTrend == 'UNKNOWN') return 'UNKNOWN';

    if (dailyDir == 'BULLISH' &&
        (wTrend == 'UPTREND' || wTrend == 'EARLY_RECOVERY')) {
      return 'ALIGNED';
    }
    if (dailyDir == 'BEARISH' &&
        (wTrend == 'DOWNTREND' || wTrend == 'EARLY_WEAKNESS')) {
      return 'ALIGNED';
    }
    if (wTrend == 'SIDEWAYS') return 'PARTIALLY_ALIGNED';
    return 'CONFLICTING';
  }

  String _fibZone(StockAnalysisData s) {
    if (s.fibHigh == null || s.fibLow == null) return 'NO_FIB';
    final p = s.close;
    if (p > s.fibHigh!) return 'ABOVE_HIGH(breakout)';
    if (s.fib236 != null && p >= s.fib236!) return '0%-23.6%(strong_zone)';
    if (s.fib382 != null && p >= s.fib382!) return '23.6%-38.2%(healthy_pullback)';
    if (s.fib500 != null && p >= s.fib500!) return '38.2%-50%(deep_pullback)';
    if (s.fib618 != null && p >= s.fib618!) return '50%-61.8%(critical_support)';
    if (p >= s.fibLow!) return '61.8%-100%(danger_zone)';
    return 'BELOW_LOW(trend_broken)';
  }

  String _buildObvLine(StockAnalysisData s) {
    final parts = <String>[];
    if (s.obvTrend != null) parts.add('Trend=${s.obvTrend}');
    if (s.obvMa20 != null) {
      final aboveBelow = (s.obv != null && s.obv! > s.obvMa20!) ? 'ABOVE' : 'BELOW';
      parts.add('vs_MA20=$aboveBelow');
    }
    if (s.obvDivergence == true && s.obvDivergenceType != null) {
      parts.add('Div=${s.obvDivergenceType}');
    }
    return parts.isEmpty ? '-' : parts.join(' | ');
  }

  String _buildBbLine(StockAnalysisData s) {
    final parts = <String>[];
    if (s.bbSqueeze == true) parts.add('SQUEEZE');
    if (s.bbWidthTrend != null) parts.add('Width=${s.bbWidthTrend}');
    if (s.bbWidth != null) parts.add('BW=${s.bbWidth!.toStringAsFixed(4)}');
    return parts.isEmpty ? '' : parts.join(' | ');
  }

  String _relativePerformance(StockAnalysisData s) {
    final parts = <String>[];
    if (s.bist100Change != null) {
      final diff = s.changePercent - s.bist100Change!;
      final label = diff > 1.0
          ? 'OUTPERFORM'
          : diff < -1.0
              ? 'UNDERPERFORM'
              : 'INLINE';
      parts.add('vs_BIST100=${diff >= 0 ? "+" : ""}${diff.toStringAsFixed(1)}%($label)');
    }
    if (s.sectorChange != null) {
      final diff = s.changePercent - s.sectorChange!;
      final label = diff > 1.0
          ? 'OUTPERFORM'
          : diff < -1.0
              ? 'UNDERPERFORM'
              : 'INLINE';
      parts.add('vs_Sector=${diff >= 0 ? "+" : ""}${diff.toStringAsFixed(1)}%($label)');
    }
    return parts.isEmpty ? '-' : parts.join(' | ');
  }

  String _trailingStopInfo(StockAnalysisData s) {
    if (s.atr == null) return '';
    final atr = s.atr!;
    final trailingStop = s.close - (atr * 1.5);

    if (s.entryPrice != null && s.close > s.entryPrice!) {
      final profitPct = ((s.close - s.entryPrice!) / s.entryPrice! * 100);
      return 'TrailingStop=${trailingStop.toStringAsFixed(2)}(ATRx1.5) | Entry=${s.entryPrice!.toStringAsFixed(2)} | Profit=+${profitPct.toStringAsFixed(1)}%';
    }
    return '';
  }

  double _adjustedStopMultiplier(String regime) {
    switch (regime) {
      case 'VOLATILE':
        return 2.5;
      case 'STRONG_TREND':
        return 1.5;
      case 'RANGE':
      case 'RANGE_SQUEEZE':
        return 2.0;
      default:
        return 2.0;
    }
  }

  String _positionSizeRecommendation(String regime, int confluenceScore) {
    if (regime == 'VOLATILE') return 'SMALL(max_1pct_risk)';
    if (confluenceScore >= 75) return 'FULL(max_2pct_risk)';
    if (confluenceScore >= 55) return 'NORMAL(max_1.5pct_risk)';
    if (confluenceScore >= 40) return 'SMALL(max_1pct_risk)';
    return 'MINIMAL(max_0.5pct_risk)';
  }

  String _confluenceSignal(int score) {
    if (score >= 75) return 'GUCLU_AL (confidence: 0.70-0.85)';
    if (score >= 55) return 'AL (confidence: 0.50-0.69)';
    if (score >= 40) return 'IZLE (confidence: 0.35-0.49)';
    if (score >= 25) return 'TUT (confidence: 0.25-0.39)';
    return 'SAT (confidence: 0.15-0.30)';
  }

  Map<String, dynamic> _calculateConfluence(StockAnalysisData s) {
    int totalScore = 0;
    final details = <String, int>{};

    // 1. Weekly trend alignment (20 points)
    int weeklyScore = 10; // default neutral
    final dailyDir = (s.rsi != null && s.rsi! > 50) ? 'BULLISH' : 'BEARISH';
    final alignment = _timeframeAlignment(s, dailyDir);
    if (alignment == 'ALIGNED') {
      weeklyScore = 20;
    } else if (alignment == 'PARTIALLY_ALIGNED') {
      weeklyScore = 10;
    } else if (alignment == 'CONFLICTING') {
      weeklyScore = 0;
    }
    details['weekly'] = weeklyScore;
    totalScore += weeklyScore;

    // 2. ADX trend strength (15 points)
    int adxScore = 0;
    if (s.adx != null) {
      if (s.adx! >= 40) {
        adxScore = 15;
      } else if (s.adx! >= 30) {
        adxScore = 12;
      } else if (s.adx! >= 25) {
        adxScore = 8;
      } else if (s.adx! >= 20) {
        adxScore = 4;
      }
    }
    details['adx'] = adxScore;
    totalScore += adxScore;

    // 3. RSI status (15 points)
    int rsiScore = 5;
    if (s.rsi != null) {
      if (s.rsi! < 30) {
        rsiScore = 15;
      } else if (s.rsi! < 40) {
        rsiScore = 12;
      } else if (s.rsi! > 50 && s.rsi! < 70) {
        rsiScore = 10;
      } else if (s.rsi! >= 70) {
        rsiScore = 2;
      }
    }
    details['rsi'] = rsiScore;
    totalScore += rsiScore;

    // 4. MACD confirmation (12 points)
    int macdScore = 4;
    if (s.macdHistogram != null) {
      final hist = s.macdHistogram!;
      if (hist > 0) {
        macdScore = 8;
        if (s.recentMacdHist != null && s.recentMacdHist!.isNotEmpty) {
          final prev = s.recentMacdHist![0];
          if (prev != null && prev <= 0) macdScore = 12;
        }
      } else {
        macdScore = 2;
      }
    }
    details['macd'] = macdScore;
    totalScore += macdScore;

    // 5. Volume confirmation (12 points)
    int volScore = 0;
    final ratio = _volRatio(s);
    if (ratio >= 2.0) {
      volScore = 12;
    } else if (ratio >= 1.5) {
      volScore = 8;
    } else if (ratio >= 0.8) {
      volScore = 4;
    }
    details['vol'] = volScore;
    totalScore += volScore;

    // 6. OBV alignment (10 points, negative divergence penalizes)
    int obvScore = 5;
    if (s.obvTrend == 'RISING') obvScore = 8;
    if (s.obvTrend == 'RISING' && s.obv != null && s.obvMa20 != null && s.obv! > s.obvMa20!) {
      obvScore = 10;
    }
    if (s.obvDivergence == true && s.obvDivergenceType == 'NEGATIVE') {
      obvScore = -5;
    }
    details['obv'] = obvScore;
    totalScore += obvScore;

    // 7. Bollinger Band (8 points)
    int bbScore = 3;
    if (s.bbPercentB != null) {
      if (s.bbSqueeze == true) bbScore = 6;
      if (s.bbPercentB! > 0.5 && s.bbPercentB! < 0.8) bbScore = 5;
      if (s.bbPercentB! > 0.95) bbScore = 2;
      if (s.bbPercentB! < 0.05) bbScore = 7;
    }
    details['bb'] = bbScore;
    totalScore += bbScore;

    // 8. Fibonacci zone (8 points)
    int fibScore = 4;
    final zone = _fibZone(s);
    if (zone.contains('critical_support') || zone.contains('healthy_pullback')) {
      fibScore = 8;
    } else if (zone.contains('strong_zone')) {
      fibScore = 6;
    } else if (zone.contains('danger_zone')) {
      fibScore = 1;
    } else if (zone.contains('trend_broken')) {
      fibScore = 0;
    }
    details['fib'] = fibScore;
    totalScore += fibScore;

    if (totalScore < 0) totalScore = 0;

    return {
      'total': totalScore,
      'details': details,
    };
  }

  // ==================== FORMAT HELPERS ====================

  String _f(double? v) => v?.toStringAsFixed(2) ?? '-';

  String _fmtVol(num v) {
    if (v >= 1e9) return '${(v / 1e9).toStringAsFixed(1)}B';
    if (v >= 1e6) return '${(v / 1e6).toStringAsFixed(1)}M';
    if (v >= 1e3) return '${(v / 1e3).toStringAsFixed(1)}K';
    return v.toString();
  }
}
